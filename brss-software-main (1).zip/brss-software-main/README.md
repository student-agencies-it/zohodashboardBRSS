# brss-software

A Svelte web app to streamline worker assignment, automate tasks, and more aesthetically present information for the managers of Big Red Shipping and Storage.

## Developing

Once you've created a project and installed dependencies with `npm install` (or `pnpm install` or `yarn`), you must then configure environment variables. Create a `.env` file in the root of the project with contents that match the environment variables on the Cloudflare Pages dashboard (see [Deployment](#deployment)).

You can now start a development server:

```bash
npm run dev

# or start the server and open the app in a new browser tab
npm run dev -- --open
```

## Building

To create a production version of your app:

```bash
npm run build
```

You can preview the production build with `npm run preview`.

## Deployment

The app is deployed to [Cloudflare Pages](https://pages.cloudflare.com/). The deployment is done automatically when a commit is pushed to the `main` branch.

The current production site is located at [brss.pages.dev](https://brss.pages.dev/).

Don't forget to upload / update environment variables when deploying.

## Authentication

You can currently only sign-in if your email is present in a pre-approved list. That list should be set as an environment variable `ALLOWED_EMAILS` in the Cloudflare Pages dashboard. Emails should be comma-separated.

Example:

```
ALLOWED_EMAILS=simon@simonilincev.com,brss@studentagencies.com,your-net-id@cornell.edu
```

## UI

The app uses [Tailwind CSS](https://tailwindcss.com/) for styling. You can find the Tailwind configuration in `tailwind.config.js`. [Shadcn-Svelte](https://shadcn-svelte.com) is used as the component library; components are imported to `src/lib/components/ui` and can be used in the app.

## Further Documentation

### Algorithm

Please see the `README.md` file in the `src/lib/algorithm` folder for a high-level overview of the algorithm used to assign orders to trucks.

### Setup / Maintenance

Dylan Seale has kindly compiled a guide that augments this one [here on Confluence](https://studentagencies.atlassian.net/wiki/spaces/TECH/pages/188940289/BRSS+Admin+Software).

### Drivers

The only people who can be assigned as drivers are those that are present in a set in `src/routes/trucks/allowedDrivers.ts`. This is to prevent unauthorized people from being assigned as drivers. If you need to add a driver, please add their name to the set (check with Julie first) — actually probably just ping Julie at the start of each peak season.

Unauthorized people will still be shown, just be disabled.

# Algorithm

This folder, and in particular its associated files `algorithm.ts` and `variables.ts`, contains the base algorithm + associated constants used on the `/trucks` page to efficiently assign orders to trucks.

## High-level Overview

_Please look at `algorithm.ts` for more specific implementation details and comments._

- Create a map : `generic 'truck' (e.g. truck, High Roof) -> (group, subgroup, map : time -> orders) | null`
- Create a collection : `fulfilledOrderIDs`
- For every timeslot (chronologically from the morning to the evening)
  - While timeslot not empty (calculated _filtered_ subgroup length == 1)
  - Calculate & sort subgroups by size
  - Find the _fittest_ truck that can accomodate (appointment timeslot cap not exceeded, time total to arrive not exceeded, daily cap not exceeded from map) the largest subgroup
  - Fulfill all the orders in that pairing
    - Update fulfilled order IDs
    - Update group & subgroup for that track in the map
    - Update map key in the generic base map
  - Recalculate and resort subgroups
- If in peak mode, merge small, possibly-mergeable truck-timeslot pairs (threshold is `TRUCK_TIMESLOT_MERGE_THRESHOLD`)

> Question: what defines fitness?

> Answer:
>
> - first filter for possible trucks
> - if none, add one & this is our answer
> - if one, this is our answer
> - otherwise, want lowest possible time wastage, which is given as a score
> - this score is essentially how much movement is required (see `variables.ts` and `alphabeticalPairMap.ts` for constants) — we see if the truck would need to move between campuses, subgroups, etc.
> - there are also some multipliers for the score based on location, whether it is peak mode, appointment type, etc.

Problem: if we do this, then we will greedily fill up truck 1, then create truck 2 and greedily fill it up, etc. etc. — so it is essentially random zipping around for each truck!

Solution: there is a score threshold. If the minimum current truck score is greater than that threshold, defined as `MINUTE_COST_OF_NEW_VEHICLE` in `variables.ts`, then we add another truck. This is a heuristic to prevent the above problem. See the `findFittestAvailableOrNewTruck` function in `algorithm.ts`.

If you think about it in depth then the solution does not get implemented _super_ often, however due to the presence of multipliers and the way `MINUTE_COST_OF_NEW_VEHICLE` is defined it does still lead to improvements in the algorithm.

An even better improvement is then later when we do the final high-level step of "merging" small truck-timeslot pairs. We find the smallest truck-timeslot pair (e.g. Truck 9, 9-11 AM), and find the "best" truck to merge it with.

You find the “best” truck how exactly?

- Find all other trucks (no high roof or br van consideration) that would even be able to take it
  - AKA they are not themselves already full appointment-wise for desired timeslot (if this was added on)
    - Note that for that timeslot they could have zero, same logic applies _only_ in the following circumstances:
      - The truck to be merged into has a smaller truck number
      - *Might need to iterate on this, kind of hard to just think through abstractly*
  - …or item-/order-wise for the full day (if this was added on)
- Give a score to each of these trucks (the normal scoring algorithm — based on distance from previous group)
- (If lowest score under threshold?) then reassign (doubly update generic output map) (and flag to not consider again during recalculation of smallest?)

We run through the whole above process a few times. Don't want to do infinitely due to potential for infinite loop.

Note: when timeslot filled for BR Van / or High Roof, flag next timeslot as "to be skipped for X"
Note: if a truck remains empty, it is just a 'lunch break' (i.e. 'back to A Lot').

### Peak Mode vs non-Peak Mode

Peak Mode should be turned on for the 2nd/3rd week of May. It does the following changes, as discussed with Thomas Bailey:

- max 7 normal appts per day of High Roof
- 0.75x travel / fitness multiplier for size-one orders for High Roof
- no reuse of High Roof (can only be filled up once)
- BR Van just awaits manual forced assignment

### `alphabeticalPairMap.ts`

This file contains specific pairwise distances between subgroups on North and CTown. West and South are handled inside of `algorithm.ts`. This allows for more efficient routing.

## Analysis

Please try running on past days to see how the algorithm performs, in particular the 2nd/3rd week of May. This represents BRSS' peak.

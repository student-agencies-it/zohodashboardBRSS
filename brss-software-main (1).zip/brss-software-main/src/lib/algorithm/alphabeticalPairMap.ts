class AlphabeticalPairMap extends Map<string, number> {
	setPair(keyA: string[], keyB: string[], value: number) {
		const sortedKeyA = keyA.sort().join(',');
		const sortedKeyB = keyB.sort().join(',');
		if (sortedKeyA <= sortedKeyB) {
			return super.set(sortedKeyA + '|' + sortedKeyB, value);
		} else {
			return super.set(sortedKeyB + '|' + sortedKeyA, value);
		}
	}

	getPair(keyA: string[], keyB: string[]) {
		const sortedKeyA = keyA.sort().join(',');
		const sortedKeyB = keyB.sort().join(',');
		if (sortedKeyA <= sortedKeyB) {
			return super.get(sortedKeyA + '|' + sortedKeyB);
		} else {
			return super.get(sortedKeyB + '|' + sortedKeyA);
		}
	}

	removePair(keyA: string[], keyB: string[]) {
		const sortedKeyA = keyA.sort().join(',');
		const sortedKeyB = keyB.sort().join(',');
		if (sortedKeyA <= sortedKeyB) {
			return super.delete(sortedKeyA + '|' + sortedKeyB);
		} else {
			return super.delete(sortedKeyB + '|' + sortedKeyA);
		}
	}
}

export const preciseSubgroupDistances: AlphabeticalPairMap = new AlphabeticalPairMap();
// NOTE: if pair not found, use the defaults (5 and 2.5, doubled for north.)

// South...
preciseSubgroupDistances.setPair(
	['151 Dryden', 'Eddygate Apartments'],
	['Collegetown Apartments'],
	8
);

preciseSubgroupDistances.setPair(['The Lofts', 'The Lux'], ['Collegetown Apartments'], 8);

preciseSubgroupDistances.setPair(
	['151 Dryden', 'Eddygate Apartments'],
	['Collegetown Apartments'],
	8
);

// West is checked manually

// North...

// starting group 1...
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Triphammer Cooperative', 'Wan Cooperative'],
	2
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	2
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['308 Wait Terrace', 'Clara Dickson'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	2
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Risley'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Hasbrook Community Center Apartments'],
	8
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Ecology House', 'Pi Phi'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Townhouses'],
	8
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	7
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['High Rise #5', 'Low Rise #6'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Mews', 'RBG Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Court', 'Kay', 'Baur', 'Mews'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Donlon', 'Court'],
	8
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Donlon', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Jameson', 'Donlon'],
	7
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 2...
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	2
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	5
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['308 Wait Terrace', 'Clara Dickson'],
	5
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	5
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	2
);
preciseSubgroupDistances.setPair(['Triphammer Cooperative', 'Wan Cooperative'], ['Risley'], 3);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Hasbrook Community Center Apartments'],
	8
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Ecology House', 'Pi Phi'],
	10
);
preciseSubgroupDistances.setPair(['Triphammer Cooperative', 'Wan Cooperative'], ['Townhouses'], 8);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	5
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	7
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['High Rise #5', 'Low Rise #6'],
	10
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	10
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Mews', 'RBG Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Court', 'Kay', 'Baur', 'Mews'],
	10
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Donlon', 'Court'],
	8
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Donlon', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Jameson', 'Donlon'],
	7
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 3...
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['308 Wait Terrace', 'Clara Dickson'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	2
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Risley'],
	3
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Hasbrook Community Center Apartments'],
	8
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Ecology House', 'Pi Phi'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Townhouses'],
	8
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	7
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['High Rise #5', 'Low Rise #6'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Mews', 'RBG Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Court', 'Kay', 'Baur', 'Mews'],
	10
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Donlon', 'Court'],
	8
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Donlon', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Jameson', 'Donlon'],
	7
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 4...
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['308 Wait Terrace', 'Clara Dickson'],
	5
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	5
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	5
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Risley'],
	2
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Hasbrook Community Center Apartments'],
	8
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Ecology House', 'Pi Phi'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Townhouses'],
	8
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	8
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['High Rise #5', 'Low Rise #6'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Mews', 'RBG Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Court', 'Kay', 'Baur', 'Mews'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Donlon', 'Court'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Donlon', 'Mews'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Jameson', 'Donlon'],
	10
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	8
);
preciseSubgroupDistances.setPair(
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	8
);

// start group 5...
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	2
);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	2
);
preciseSubgroupDistances.setPair(['308 Wait Terrace', 'Clara Dickson'], ['Risley'], 5);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Hasbrook Community Center Apartments'],
	8
);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Ecology House', 'Pi Phi'],
	10
);
preciseSubgroupDistances.setPair(['308 Wait Terrace', 'Clara Dickson'], ['Townhouses'], 8);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	5
);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	7
);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['High Rise #5', 'Low Rise #6'],
	10
);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	10
);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(['308 Wait Terrace', 'Clara Dickson'], ['Mews', 'RBG Hall'], 10);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Court', 'Kay', 'Baur', 'Mews'],
	10
);
preciseSubgroupDistances.setPair(['308 Wait Terrace', 'Clara Dickson'], ['Donlon', 'Court'], 10);
preciseSubgroupDistances.setPair(['308 Wait Terrace', 'Clara Dickson'], ['Donlon', 'Mews'], 10);
preciseSubgroupDistances.setPair(['308 Wait Terrace', 'Clara Dickson'], ['Jameson', 'Donlon'], 8);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	8
);
preciseSubgroupDistances.setPair(
	['308 Wait Terrace', 'Clara Dickson'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	8
);

// start group 6...
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	2
);
preciseSubgroupDistances.setPair(['Clara Dickson / MCLLU', 'Kappa Delta'], ['Risley'], 5);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Hasbrook Community Center Apartments'],
	8
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Ecology House', 'Pi Phi'],
	10
);
preciseSubgroupDistances.setPair(['Clara Dickson / MCLLU', 'Kappa Delta'], ['Townhouses'], 8);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	5
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	7
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['High Rise #5', 'Low Rise #6'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Mews', 'RBG Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Court', 'Kay', 'Baur', 'Mews'],
	10
);
preciseSubgroupDistances.setPair(['Clara Dickson / MCLLU', 'Kappa Delta'], ['Donlon', 'Court'], 10);
preciseSubgroupDistances.setPair(['Clara Dickson / MCLLU', 'Kappa Delta'], ['Donlon', 'Mews'], 10);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Jameson', 'Donlon'],
	8
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	8
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	7
);

// start group 7...
preciseSubgroupDistances.setPair(['Clara Dickson / MCLLU', 'Delta Gamma'], ['Risley'], 5);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Hasbrook Community Center Apartments'],
	8
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Ecology House', 'Pi Phi'],
	10
);
preciseSubgroupDistances.setPair(['Clara Dickson / MCLLU', 'Delta Gamma'], ['Townhouses'], 8);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	5
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	7
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['High Rise #5', 'Low Rise #6'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Mews', 'RBG Hall'],
	10
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Court', 'Kay', 'Baur', 'Mews'],
	10
);
preciseSubgroupDistances.setPair(['Clara Dickson / MCLLU', 'Delta Gamma'], ['Donlon', 'Court'], 8);
preciseSubgroupDistances.setPair(['Clara Dickson / MCLLU', 'Delta Gamma'], ['Donlon', 'Mews'], 8);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Jameson', 'Donlon'],
	7
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 8...
preciseSubgroupDistances.setPair(['Risley'], ['Hasbrook Community Center Apartments'], 12);
preciseSubgroupDistances.setPair(['Risley'], ['Ecology House', 'Pi Phi'], 8);
preciseSubgroupDistances.setPair(['Risley'], ['Townhouses'], 8);
preciseSubgroupDistances.setPair(['Risley'], ['Baur', 'Balch', 'Clara Dickson / MCLLU'], 8);
preciseSubgroupDistances.setPair(['Risley'], ['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'], 10);
preciseSubgroupDistances.setPair(
	['Risley'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(['Risley'], ['High Rise #5', 'Low Rise #6'], 10);
preciseSubgroupDistances.setPair(['Risley'], ['Low Rise #9 / JAM', 'Low Rise #8 / HILC'], 10);
preciseSubgroupDistances.setPair(['Risley'], ['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'], 10);
preciseSubgroupDistances.setPair(
	['Risley'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(['Risley'], ['Mews', 'RBG Hall'], 10);
preciseSubgroupDistances.setPair(['Risley'], ['Court', 'Kay', 'Baur', 'Mews'], 10);
preciseSubgroupDistances.setPair(['Risley'], ['Donlon', 'Court'], 10);
preciseSubgroupDistances.setPair(['Risley'], ['Donlon', 'Mews'], 10);
preciseSubgroupDistances.setPair(['Risley'], ['Jameson', 'Donlon'], 10);
preciseSubgroupDistances.setPair(
	['Risley'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	8
);
preciseSubgroupDistances.setPair(
	['Risley'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	8
);

// start group 9...
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Ecology House', 'Pi Phi'],
	12
);
preciseSubgroupDistances.setPair(['Hasbrook Community Center Apartments'], ['Townhouses'], 5);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	12
);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	10
);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	5
);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['High Rise #5', 'Low Rise #6'],
	5
);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	5
);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	5
);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	5
);
preciseSubgroupDistances.setPair(['Hasbrook Community Center Apartments'], ['Mews', 'RBG Hall'], 8);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Court', 'Kay', 'Baur', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(['Hasbrook Community Center Apartments'], ['Donlon', 'Court'], 8);
preciseSubgroupDistances.setPair(['Hasbrook Community Center Apartments'], ['Donlon', 'Mews'], 8);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Jameson', 'Donlon'],
	8
);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	8
);
preciseSubgroupDistances.setPair(
	['Hasbrook Community Center Apartments'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	8
);

// start group 10...
preciseSubgroupDistances.setPair(['Ecology House', 'Pi Phi'], ['Townhouses'], 8);
preciseSubgroupDistances.setPair(
	['Ecology House', 'Pi Phi'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	10
);
preciseSubgroupDistances.setPair(
	['Ecology House', 'Pi Phi'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	10
);
preciseSubgroupDistances.setPair(
	['Ecology House', 'Pi Phi'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(['Ecology House', 'Pi Phi'], ['High Rise #5', 'Low Rise #6'], 10);
preciseSubgroupDistances.setPair(
	['Ecology House', 'Pi Phi'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	10
);
preciseSubgroupDistances.setPair(
	['Ecology House', 'Pi Phi'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	10
);
preciseSubgroupDistances.setPair(
	['Ecology House', 'Pi Phi'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(['Ecology House', 'Pi Phi'], ['Mews', 'RBG Hall'], 10);
preciseSubgroupDistances.setPair(['Ecology House', 'Pi Phi'], ['Court', 'Kay', 'Baur', 'Mews'], 10);
preciseSubgroupDistances.setPair(['Ecology House', 'Pi Phi'], ['Donlon', 'Court'], 8);
preciseSubgroupDistances.setPair(['Ecology House', 'Pi Phi'], ['Donlon', 'Mews'], 8);
preciseSubgroupDistances.setPair(['Ecology House', 'Pi Phi'], ['Jameson', 'Donlon'], 8);
preciseSubgroupDistances.setPair(
	['Ecology House', 'Pi Phi'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	8
);
preciseSubgroupDistances.setPair(
	['Ecology House', 'Pi Phi'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	8
);

// start group 11...
preciseSubgroupDistances.setPair(['Townhouses'], ['Baur', 'Balch', 'Clara Dickson / MCLLU'], 8);
preciseSubgroupDistances.setPair(
	['Townhouses'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	8
);
preciseSubgroupDistances.setPair(
	['Townhouses'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	8
);
preciseSubgroupDistances.setPair(['Townhouses'], ['High Rise #5', 'Low Rise #6'], 8);
preciseSubgroupDistances.setPair(['Townhouses'], ['Low Rise #9 / JAM', 'Low Rise #8 / HILC'], 8);
preciseSubgroupDistances.setPair(['Townhouses'], ['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'], 8);
preciseSubgroupDistances.setPair(
	['Townhouses'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	10
);
preciseSubgroupDistances.setPair(['Townhouses'], ['Mews', 'RBG Hall'], 10);
preciseSubgroupDistances.setPair(['Townhouses'], ['Court', 'Kay', 'Baur', 'Mews'], 10);
preciseSubgroupDistances.setPair(['Townhouses'], ['Donlon', 'Court'], 5);
preciseSubgroupDistances.setPair(['Townhouses'], ['Donlon', 'Mews'], 5);
preciseSubgroupDistances.setPair(['Townhouses'], ['Jameson', 'Donlon'], 5);
preciseSubgroupDistances.setPair(
	['Townhouses'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Townhouses'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 12...
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	2
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	8
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['High Rise #5', 'Low Rise #6'],
	8
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	8
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	8
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	8
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Mews', 'RBG Hall'],
	5
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Court', 'Kay', 'Baur', 'Mews'],
	5
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Donlon', 'Court'],
	5
);
preciseSubgroupDistances.setPair(['Baur', 'Balch', 'Clara Dickson / MCLLU'], ['Donlon', 'Mews'], 5);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Jameson', 'Donlon'],
	7
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 13...
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	8
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['High Rise #5', 'Low Rise #6'],
	8
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	8
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	8
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	8
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Mews', 'RBG Hall'],
	5
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Court', 'Kay', 'Baur', 'Mews'],
	5
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Donlon', 'Court'],
	5
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Donlon', 'Mews'],
	5
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Jameson', 'Donlon'],
	7
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 14...
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['High Rise #5', 'Low Rise #6'],
	2
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['Mews', 'RBG Hall'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['Court', 'Kay', 'Baur', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['Donlon', 'Court'],
	8
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],

	['Donlon', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['Jameson', 'Donlon'],
	8
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	8
);
preciseSubgroupDistances.setPair(
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	8
);

// start group 15...
preciseSubgroupDistances.setPair(
	['High Rise #5', 'Low Rise #6'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	5
);
preciseSubgroupDistances.setPair(
	['High Rise #5', 'Low Rise #6'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	5
);
preciseSubgroupDistances.setPair(
	['High Rise #5', 'Low Rise #6'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	5
);
preciseSubgroupDistances.setPair(['High Rise #5', 'Low Rise #6'], ['Mews', 'RBG Hall'], 5);
preciseSubgroupDistances.setPair(
	['High Rise #5', 'Low Rise #6'],
	['Court', 'Kay', 'Baur', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(['High Rise #5', 'Low Rise #6'], ['Donlon', 'Court'], 8);
preciseSubgroupDistances.setPair(
	['High Rise #5', 'Low Rise #6'],

	['Donlon', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(['High Rise #5', 'Low Rise #6'], ['Jameson', 'Donlon'], 5);
preciseSubgroupDistances.setPair(
	['High Rise #5', 'Low Rise #6'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['High Rise #5', 'Low Rise #6'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 16...
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	2
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['Mews', 'RBG Hall'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['Court', 'Kay', 'Baur', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['Donlon', 'Court'],
	8
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['Donlon', 'Mews'],
	8
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['Jameson', 'Donlon'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 17...
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	['Mews', 'RBG Hall'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	['Court', 'Kay', 'Baur', 'Mews'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	['Donlon', 'Court'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	['Donlon', 'Mews'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	['Jameson', 'Donlon'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 18...
preciseSubgroupDistances.setPair(
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	['Mews', 'RBG Hall'],
	2
);
preciseSubgroupDistances.setPair(
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	['Court', 'Kay', 'Baur', 'Mews'],
	3
);
preciseSubgroupDistances.setPair(
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	['Donlon', 'Court'],
	5
);
preciseSubgroupDistances.setPair(
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	['Donlon', 'Mews'],
	3
);
preciseSubgroupDistances.setPair(
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	['Jameson', 'Donlon'],
	5
);
preciseSubgroupDistances.setPair(
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 19...
preciseSubgroupDistances.setPair(['Mews', 'RBG Hall'], ['Court', 'Kay', 'Baur', 'Mews'], 2);
preciseSubgroupDistances.setPair(['Mews', 'RBG Hall'], ['Donlon', 'Court'], 2);
preciseSubgroupDistances.setPair(['Mews', 'RBG Hall'], ['Donlon', 'Mews'], 2);
preciseSubgroupDistances.setPair(['Mews', 'RBG Hall'], ['Jameson', 'Donlon'], 2);
preciseSubgroupDistances.setPair(
	['Mews', 'RBG Hall'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Mews', 'RBG Hall'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 20...
preciseSubgroupDistances.setPair(['Court', 'Kay', 'Baur', 'Mews'], ['Donlon', 'Court'], 2);
preciseSubgroupDistances.setPair(['Court', 'Kay', 'Baur', 'Mews'], ['Donlon', 'Mews'], 2);
preciseSubgroupDistances.setPair(['Court', 'Kay', 'Baur', 'Mews'], ['Jameson', 'Donlon'], 2);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Mews'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Court', 'Kay', 'Baur', 'Mews'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 21...
preciseSubgroupDistances.setPair(['Donlon', 'Court'], ['Donlon', 'Mews'], 2);
preciseSubgroupDistances.setPair(['Donlon', 'Court'], ['Jameson', 'Donlon'], 2);
preciseSubgroupDistances.setPair(
	['Donlon', 'Court'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Donlon', 'Court'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 22...
preciseSubgroupDistances.setPair(['Donlon', 'Mews'], ['Jameson', 'Donlon'], 2);
preciseSubgroupDistances.setPair(
	['Donlon', 'Mews'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Donlon', 'Mews'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 23...
preciseSubgroupDistances.setPair(
	['Jameson', 'Donlon'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	5
);
preciseSubgroupDistances.setPair(
	['Jameson', 'Donlon'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	5
);

// start group 24...
preciseSubgroupDistances.setPair(
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	3
);

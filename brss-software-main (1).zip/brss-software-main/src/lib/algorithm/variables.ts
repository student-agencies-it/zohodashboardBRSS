/**
 * This file contains all the variables that are used in the algorithm.
 * It is meant to be a central place to manage all the constants that are
 * used in the algorithm.
 */

export const TRUCK_ITEM_CAPACITY = 110; // not sure how much this will be used honestly
// max # of appointments per day
export const TRUCK_ORDER_CAPACITY = 22;
export const TRUCK_MAX_APPOINTMENTS_PER_TIMESLOT = 12;

export const BR_VAN_MAX_APPOINTMENTS_PER_TIMESLOT = 5; // as long as it can drop off though we can keep reusing
export const BR_VAN_ORDER_CAPACITY = 5;

export const HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT = 10; // can reuse throughout the day though
export const HIGHROOF_ORDER_CAPACITY = 10;

export const BASE_BETWIXT_CAMPUS_MOVE_TIME = 15; // minutes
export const WITHIN_CAMPUS_MOVE_TIME_SHARED_DORM = 2.5; // minutes
export const WITHIN_CAMPUS_MOVE_TIME_NO_SHARED_DORM = 5;
export const NORTH_MULTIPLIER = 2;

// Special constant used for calculating when we need new vehicles.
export const MINUTE_COST_OF_NEW_VEHICLE = BASE_BETWIXT_CAMPUS_MOVE_TIME + 1;

// Special multiplier used for emphasizing the usage of BR Van + High Roof for supplies.
export const BR_VAN_AND_HIGHROOF_SUPPLIES_EMPHASIS_MULTIPLIER = 0.33;

// It is fine to just base this off of trucks since the BR Van and High Roof do not
// have large enough capacity.
export const TIME_TO_FULFILL_APPOINTMENT = 120 / TRUCK_MAX_APPOINTMENTS_PER_TIMESLOT;
export const TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER = 0.25; // literally dropping off boxes

// We may want a bit of a cushion on the backside (set to zero if not desired).
export const MINUTES_PER_TIMESLOT = 120;
export const BACKEND_BUFFER_CUSHION = 10;

// We want to encourage High Roof to take the smallest orders in peak mode.
export const PEAK_MODE_HIGHROOF_SIZE_ONE_ORDER_MULTIPLIER = 0.75;
export const PEAK_MODE_HIGHROOF_CAPACITY_MULTIPLIER = 0.7;

// If truck-timeslot combos have this many appointments or less, try to merge them.
export const TRUCK_TIMESLOT_MERGE_THRESHOLD = 3;

// Want to merge away leftwards zeroes — may take a few tries.
// (I tried console logging and after iterations there is indeed a *sometimes-strictly*
// decreasing number of items considered below the merge threshold.)
export const FINAL_MERGE_ITERATIONS = 3;

// Used for giving an absolute monetary score at the end. (Rough approximation.)
export const VALUE_PER_ORDER = 350;
export const RENT_TRUCK_PER_DAY_COST = 100;
export const USE_TWO_FIELD_REPS_THRESHOLD = 4; // 4+, includes 4, in a timeslot
export const USE_THREE_FIELD_REPS_THRESHOLD = 9; // 9+, includes 9, in a timeslot
export const FIELD_REP_WAGE = 15.5;
export const DRIVER_WAGE = FIELD_REP_WAGE + 1;

// These ones are harder.
export const LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER = 1.5;
export const GOTHIC_LIST = [
	'Boldt Hall',
	'Baker Hall',
	'Baker Hall North',
	'Baker Hall South',
	'North Baker',
	'South Baker',
	'Baker Tower',
	'Founders Hall',
	'Lyon Hall',
	'McFaddin Hall',
	'Boldt Hall',
	'Mennen Hall'
];

export const DISCRETE_TIMESLOTS = [
	'9 AM - 11 AM',
	'11 AM - 1 PM',
	'1 PM - 3 PM',
	'3 PM - 5 PM',
	'5 PM - 7 PM'
];

/**
 * `groups` contains informations about the (currently) three big campus group locations:
 * North Campus, West Campus, and South Campus. Each of these then lists the
 * locations that can be selected from the BRSS dropdown form.
 *
 * Please note that there is also a catch-all group called 'Other Address' which
 * can be used for any location that does not fit into the other categories.
 */
export const groups: Map<
	| 'North Campus'
	| 'West Campus'
	| 'Collegetown Apts / Dorms'
	| 'South Campus'
	| 'Sorority'
	| 'Other Address',
	string[]
> = new Map([
	[
		'North Campus',
		[
			'Awe:kon',
			'Barbara McClintock Hall',
			'Baur',
			'Balch',
			'Clara Dickson / MCLLU',
			'Court',
			'Donlon',
			'Ecology House',
			'Ganędagǫ:',
			'Hasbrook Community Center Apartments',
			'High Rise #5',
			'Hu Shih Hall',
			'Jameson',
			'Kay',
			'Latino Living Center',
			'Low Rise #10 / Ujamaa',
			'Low Rise #6',
			'Low Rise #7',
			'Low Rise #8 / HILC',
			'Low Rise #9 / JAM',
			'Mews',
			'RBG Hall',
			'Risley',
			'Toni Morrison',
			'Toni Morrison Hall',
			'Townhouses'
		]
	],
	[
		'West Campus',
		[
			'118 McGraw',
			'Alice H. Cook House',
			'Baker Tower',
			'Boldt Hall',
			'Boldt Tower',
			'Carl Becker House',
			'Campus Hill Apartments',
			'Ravenwood Apartments',
			'Flora Rose House (Main)',
			'Founders Hall',
			'Hans Bethe',
			'Lyon Hall',
			'McFaddin Hall',
			'North/South Baker',
			'North Baker',
			'South Baker',
			'William Keeton House'
		]
	],
	[
		'South Campus',
		[
			'Cascadilla Hall',
			'Sheldon Court',
			'Schuyler House',
			'The Student Agencies Building',
			'407 College Ave Apartments',
			'Sage House',
			'Sage Place'
		]
	],
	[
		'Collegetown Apts / Dorms',
		[
			'112 Edgemoor',
			'151 Dryden',
			'Eddygate Apartments',
			'Collegetown Crossing',
			'The Lofts',
			'The Lux',
			'Collegetown Townhouses',
			'Collegetown Terrace Apartments',
			'312 College Ave',
			'Collegetown Court Apartments',
			'Fairview Apartments',
			'Maplewood Apartments'
		]
	],
	[
		'Sorority',
		[
			'Delta Gamma',
			'Kappa Delta',
			'Tri Delta',
			'Pi Phi',
			'Alpha Phi',
			'Kappa Kappa Gamma',
			'Alpha Chi Omega',
			'Alpha Xi Delta',
			'Sigma Delta Tau',
			'Alpha Epsilon Phi',
			'Theta',
			'Phi Sigma Sigma'
		]
	],
	[
		'Other Address',
		[
			// NOTE: not written; can be literally anything
		]
	]
]);

/**
 * `namedFixedLocations` is a list of all the locations that are not part of the
 * 'Other Address' group. This is useful for the algorithm to quickly check if
 * a location is a fixed location or not. We would otherwise require a regex.
 */
const namedFixedLocations = groups
	.get('North Campus')!
	.concat(
		groups
			.get('West Campus')!
			.concat(groups.get('Collegetown Apts / Dorms')!.concat(groups.get('Sorority')!))
	);

/**
 * `namedFixedLocationsMap` is a map based off of `namedFixedLocations` to
 * ensure O(1) lookup time.
 */
export const namedFixedLocationsMap = new Map<string, boolean>();

namedFixedLocations.forEach((location) => {
	namedFixedLocationsMap.set(location, true);
});

/**
 * Despite their rather confusing name, `subgroups` are actually meant to
 * represent specific, small chunks of buildings that are so close to
 * each other so as to only require one centralized truck location (i.e. no driving).
 *
 * The subgroups were generated based off of Thomas Bailey's input on [the BRSS Truck
 * List Process Flow doc](https://studentagencies-my.sharepoint.com/:w:/p/md/ESFu_vpH-eBKoQAT-tfkL0cBpZoFHs_F5Hg4ujyJ2htXPg?rtime=E-lh-A5m3Eg).
 */
export const subgroups = [
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Awe:kon'],
	['Toni Morrison', 'Toni Morrison Hall', 'Ganędagǫ:', 'Jameson'],
	['Jameson', 'Donlon'],
	['Donlon', 'Mews'],
	['Donlon', 'Court'],
	['Court', 'Kay', 'Baur', 'Mews'],
	['Mews', 'RBG Hall'],
	['RBG Hall', 'Hu Shih', 'Hu Shih Hall', 'Barbara McClintock Hall'],
	['Low Rise #9 / JAM', 'Low Rise #10 / Ujamaa'],
	['Low Rise #9 / JAM', 'Low Rise #8 / HILC'],
	['High Rise #5', 'Low Rise #6'],
	['Low Rise #6', 'Low Rise #7', 'Low Rise #8 / HILC'],
	['Court', 'Kay', 'Baur', 'Clara Dickson / MCLLU'],
	['Baur', 'Balch', 'Clara Dickson / MCLLU'],
	['Townhouses'],
	['Ecology House', 'Pi Phi'],
	['Hasbrook Community Center Apartments'],
	['Risley'],
	['Clara Dickson / MCLLU', 'Delta Gamma'],
	['Clara Dickson / MCLLU', 'Kappa Delta'],
	// NOTE: (from now on) some of these names / locations
	// do not show up in the previous grouping — requires regex.
	// This is still North though!
	['308 Wait Terrace', 'Clara Dickson'],
	['Kappa Kappa Gamma', 'Latino Living Center', 'Zeta Psi', '307 Wait Avenue', 'Alpha Phi'],
	['Delta Delta Delta', 'Tri Delta', 'Pi Delta Psi', 'Triphammer Cooperative'],
	['Triphammer Cooperative', 'Wan Cooperative'],
	['Delta Gamma', 'Awe:kon', 'Tri Delta', 'Kappa Delta'],
	// **Moving onto the general West area**...
	// NOTE: same issue of missing locations as above,
	// e.g. for 'Equity & Engagement'.
	['William Keeton House', 'Sigma Phi', 'Equity & Engagement', 'Hans Bethe', 'Forest Park Lane'],
	['Boldt Hall', 'North/South Baker', 'North Baker', 'South Baker', 'University Ave'], // last would e.g. be a regex
	['North/South Baker', 'North Baker', 'South Baker', 'Carl Becker House'],
	['Carl Becker House', 'Flora Rose House (Main)', 'Flora Rose House'],
	// NOTE: we cannot differentiate between North & South Baker
	['North/South Baker', 'North Baker', 'South Baker', 'Founders Hall'],
	['Founders Hall', 'Lyon Hall'],
	['Lyon Hall', 'McFaddin Hall'],
	['Alice H. Cook House', 'Boldt Hall'],
	// NOTE: missing Boldt + Baker Towers, Campus Hill Apartments, and Ravenwood Apartments.
	// I guess these are standalone?
	// South Campus
	['The Student Agencies Building', '407 College Ave Apartments', 'Sheldon Court'],
	['Schuyler House', 'Sage House', 'Cascadilla Hall', 'Sage Place'],
	// Sororities
	['Alpha Chi Omega', 'Alpha Xi Delta', 'Sigma Delta Tau', 'Alpha Epsilon Phi', 'Knoll Road'],
	['Theta', '6 South Ave', 'Phi Sigma Sigma', '112 Edgemoor'],
	// Collegetown Apts / Dorms
	['151 Dryden', 'Eddygate Apartments'],
	['Collegetown Apartments'],
	['The Lofts', 'The Lux'],
	// Misc.
	[
		'Collegetown Townhouses',
		'Collegetown Crossings',
		'312 College Ave',
		'Collegetown Court Apartments',
		'Collegetown Terrace Apartments',
		'College Ave'
	],
	['Fairview Apartments', 'Maplewood Apartments', 'Veterans Pl', "Veteran's Pl"],
	['Summit St', 'Blair St', 'E State St', 'East State St'],
	['Eddy Street', 'Eddy St', 'Stewart Ave']
];

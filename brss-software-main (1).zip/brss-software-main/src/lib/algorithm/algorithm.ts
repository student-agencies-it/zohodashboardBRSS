import {
	TRUCK_ITEM_CAPACITY,
	TRUCK_ORDER_CAPACITY,
	TRUCK_MAX_APPOINTMENTS_PER_TIMESLOT,
	BR_VAN_MAX_APPOINTMENTS_PER_TIMESLOT,
	BR_VAN_ORDER_CAPACITY,
	HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT,
	HIGHROOF_ORDER_CAPACITY,
	DISCRETE_TIMESLOTS,
	WITHIN_CAMPUS_MOVE_TIME_SHARED_DORM,
	WITHIN_CAMPUS_MOVE_TIME_NO_SHARED_DORM,
	NORTH_MULTIPLIER,
	MINUTE_COST_OF_NEW_VEHICLE,
	TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER,
	groups,
	subgroups,
	namedFixedLocationsMap,
	MINUTES_PER_TIMESLOT,
	BACKEND_BUFFER_CUSHION,
	TIME_TO_FULFILL_APPOINTMENT,
	BR_VAN_AND_HIGHROOF_SUPPLIES_EMPHASIS_MULTIPLIER,
	LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER,
	GOTHIC_LIST,
	BASE_BETWIXT_CAMPUS_MOVE_TIME,
	PEAK_MODE_HIGHROOF_SIZE_ONE_ORDER_MULTIPLIER,
	PEAK_MODE_HIGHROOF_CAPACITY_MULTIPLIER,
	TRUCK_TIMESLOT_MERGE_THRESHOLD,
	FINAL_MERGE_ITERATIONS,
	VALUE_PER_ORDER,
	USE_THREE_FIELD_REPS_THRESHOLD,
	FIELD_REP_WAGE,
	DRIVER_WAGE,
	RENT_TRUCK_PER_DAY_COST,
	USE_TWO_FIELD_REPS_THRESHOLD
} from './variables';

import { preciseSubgroupDistances } from './alphabeticalPairMap';

import type { Appointment } from '../../types/appointment';
import type { FirebaseOrder } from '../../types/firebaseOrder';

type VehicleType = 'BR Van' | 'High Roof' | string; // string represents e.g. truck 1, ..., truck n
type GenericOutputMap = Map<
	VehicleType,
	{
		lastSeenGroup:
		| 'North Campus'
		| 'West Campus'
		| 'Sorority'
		| 'Collegetown Apts / Dorms'
		| 'South Campus'
		| 'Other Address'
		| null; // e.g. North Campus
		lastSeenSubgroup: string[] | null; // e.g. [Court, Kay, Baur]
		// the number represents the number of minutes used
		timeMap: Map<string, [number, [Appointment & FirebaseOrder, string[]][]]>; // e.g. { '9 AM - 11 AM': [20, [(app1, subgroup), (app2, assoc subgroup), ...]] }
	}
>;

const SORORITY_GROUP_ONE = [
	'Alpha Chi Omega',
	'Alpha Xi Delta',
	'Sigma Delta Tau',
	'Alpha Epsilon Phi',
	'Knoll Road'
];
const SORORITY_GROUP_TWO = ['Theta', '6 South Ave', 'Phi Sigma Sigma', '112 Edgemoor'];

const WEST_GROUP_ONE = [
	'Boldt Hall',
	'North/South Baker',
	'North Baker',
	'South Baker',
	'Baker Tower',
	'Carl Becker House',
	'Flora Rose House (Main)',
	'Flora Rose House',
	'Baker Hall South',
	'Baker Hall',
	'Baker Hall North',
	'Founders Hall',
	'Lyon Hall',
	'McFaddin Hall',
	'Alice H. Cook House',
	'Boldt Hall'
];

const WEST_GROUP_TWO = [
	'William Keeton House',
	'Sigma Phi',
	'Equity & Engagement',
	'Hans Bethe',
	'Forest Park Lane'
];

/**
 * Extracts the estimated # of items from a string. Average if a range, sum if otherwise.
 * @param estimatedString a string representing an estimated # of items, e.g. 4-7 or 15+ boxed, 7 non-boxed
 */
function extractEstimatedItems(estimatedString: string): number {
	const parts = estimatedString.split(', ');
	if (parts.length === 1) {
		// Example: 4-7 => (4 + 7) / 2 = 5.5
		return (parseInt(parts[0].split('-')[0]) + parseInt(parts[0].split('-')[1])) / 2;
	} else {
		// Example: 15+ boxed, 7 non-boxed => 15 + 7 = 22 (can't deal with + super well)
		const boxed = parseInt(parts[0]?.split(' ')[0].replace('+', '') ?? '0');
		const nonBoxed = parseInt(parts[1]?.split(' ')[0].replace('+', '') ?? '0');
		return boxed + nonBoxed;
	}
}

/**
 * Converts a string to proper case. Useful since some people type in all caps all lowercase etc.
 * (So useful for other addresses in particular).
 *
 * We do *not* change the case if the input already appears verbatim in the namedFixedLocationsMap.
 *
 * Additionally, we strip the initial 'Other, ' if present (does not change what is displayed,
 * exclusively used to improve other matching).
 * @param inp the input string
 * @returns the input string in proper case
 */
function toProperFormatting(inp: string): string {
	if (namedFixedLocationsMap.has(inp)) {
		return inp;
	} else {
		const corrected = inp
			.toLowerCase()
			.split(' ')
			.map((word) => word.charAt(0).toUpperCase() + word.slice(1))
			.join(' ')
			.replace('Other, ', '');
		return corrected;
	}
}

/**
 * Constructs a mapping that says, for every subgroup for some time, how many appointments there are.
 * We skip appointments that are in fulfilledOrderNumbers.
 *
 * @param appointments The appointments to calculate the required trucks for.
 * @param desiredTime The timeslot to calculate the required trucks for.
 * @param fulfilledOrderNumbers The set of order numbers that have already been fulfilled.
 * @param onlyNonZero Whether to only include subgroups that have non-zero appointments.
 * @returns a mapping of subgroups to the number of appointments in that subgroup.
 */
function calculateFilteredSubgroups(
	appointments: Record<string, (Appointment & FirebaseOrder)[]>,
	desiredTime: string,
	fulfilledOrderNumbers: Set<string>,
	onlyNonZero: boolean = true
): Map<string[], number> {
	const foundLocations = new Set<string>();
	const viewedLocations = new Set<string>();

	const mapping = new Map<string[], number>();
	for (const subgroup of subgroups) {
		let count = 0;
		for (const app of appointments[desiredTime] ?? []) {
			if (fulfilledOrderNumbers.has(app.orderNumber)) {
				continue;
			}

			viewedLocations.add(toProperFormatting(app.location ?? 'xxxxxxxxxx'));

			if (namedFixedLocationsMap.has(toProperFormatting(app.location ?? 'xxxxxxxxxx'))) {
				if (subgroup.includes(toProperFormatting(app.location ?? 'xxxxxxxxxx'))) {
					count++;
					foundLocations.add(toProperFormatting(app.location ?? 'xxxxxxxxxx'));
				}
			} else {
				const location = toProperFormatting(app.location ?? 'xxxxxxxxxx');
				const found = subgroup.find((loc) => loc.includes(location)); // like regex matching
				if (found) {
					count++;
					foundLocations.add(location);
				}
			}
		}
		if (onlyNonZero && count === 0) {
			continue;
		}
		mapping.set(subgroup, count);
	}

	// We also need to effectively create 'size-one' subgroups for those that
	// were not matched to any subgroup.
	const notFoundLocations = new Set<string>();
	viewedLocations.forEach((location) => {
		if (!foundLocations.has(location)) {
			notFoundLocations.add(location);
		}
	});

	for (const loc of notFoundLocations.values()) {
		mapping.set([loc], 1);
	}

	return mapping;
}

/**
 * isOnNorth checks if a subgroup is on North Campus. Used because this doubles the
 * time moving between subgroups.
 * @param subgroup the list of dorms to check
 * @returns whether the dorm subgroup is on North Campus
 */
const isOnNorth = (subgroup: string[]): boolean => {
	for (const location of subgroup) {
		if (groups.get('North Campus')?.includes(location)) {
			return true;
		}
	}

	return false;
};

/**
 * getGroupFromSubgroup gets the group (campus) from a subgroup.
 * @param subgroup the subgroup to get the group from
 * @returns the group (campus) the subgroup is in
 */
const getGroupFromSubgroup = (
	subgroup: string[]
):
	| 'North Campus'
	| 'West Campus'
	| 'Sorority'
	| 'Collegetown Apts / Dorms'
	| 'South Campus'
	| 'Other Address' => {
	for (const [group, locations] of groups) {
		if (locations.some((loc) => subgroup.includes(loc))) {
			return group;
		}
	}
	return 'Other Address';
};

/**
 * movedCampuses checks if a truck would have to move campuses to fulfill an order.
 * As requested by Thomas Bailey, CTown + South + Other are all effectively in the same campus.
 * @param lastSeenCampus the last seen campus of the truck
 * @param newSubgroup the new subgroup the truck might be going to
 * @returns whether the truck has moved campuses
 */
const movedCampuses = (lastSeenCampus: string | null, newSubgroup: string[]): boolean => {
	const potentialCampuses: (
		| 'North Campus'
		| 'West Campus'
		| 'Collegetown Apts / Dorms'
		| 'South Campus'
		| 'Sorority'
		| 'Other Address'
	)[] = [
			'North Campus',
			'West Campus',
			'Collegetown Apts / Dorms',
			'South Campus',
			'Sorority',
			'Other Address'
		];

	let newSubgroupCampus = 'Other Address';
	for (const campus of potentialCampuses) {
		if (groups.get(campus)?.some((loc) => newSubgroup.includes(loc))) {
			newSubgroupCampus = campus;
			break;
		}
	}

	if (lastSeenCampus === null) {
		return false;
	} else {
		const groupedAsOne = ['Collegetown Apts / Dorms', 'South Campus', 'Other Address'];
		if (groupedAsOne.includes(lastSeenCampus) && groupedAsOne.includes(newSubgroupCampus)) {
			return false;
		} else {
			return lastSeenCampus !== newSubgroupCampus;
		}
	}
};

/**
 * movedSubGroups checks if a truck would have to move between subgroups to fulfill an order.
 * @param lastSeenSubgroup the last seen subgroup of the truck
 * @param newSubgroup the new subgroup the truck might be going to
 * @returns whether the truck has moved subgroups
 */
const movedSubGroups = (lastSeenSubgroup: string[] | null, newSubgroup: string[]): boolean => {
	return lastSeenSubgroup !== null && lastSeenSubgroup !== newSubgroup;
};

/**
 * calculateAppointmentsSinceLastEmpty calculates the number of appointments since the last empty timeslot.
 * Useful for seeing if BR Van or High Roof are already full.
 *
 * @param genericOutputMap the map of trucks and their current assignments
 * @param truck the current truck being asked for
 * @param currentTimeslot the current timeslot being asked for
 * @returns the number of appointments since the last empty timeslot, counts this timeslot's
 */
function calculateAppointmentsSinceLastEmpty(
	genericOutputMap: GenericOutputMap,
	truck: VehicleType,
	currentTimeslot: string
): number {
	const timeMap = genericOutputMap.get(truck)!.timeMap;
	const times = Array.from(timeMap.keys());
	let lastEmpty = 0;
	for (const time of times) {
		if (timeMap.get(time)![1].length === 0) {
			// This is down here bc we want to check the current as well.
			if (time === currentTimeslot) {
				break;
			}
			// Don't reset lastEmpty if it's the current timeslot.
			lastEmpty = 0;
		} else {
			// We are filtering out supplies because that only really just requires the vehicle to move which is not too important.
			lastEmpty += timeMap.get(time)![1].filter((a) => a[0].type !== 'Supplies').length; // only care about this
			// We are not resetting, can go after.
			if (time === currentTimeslot) {
				break;
			}
		}
	}
	return lastEmpty;
}

/**
 * A helper function to calculate the time in minutes to move between two subgroups.
 * @param beforeGroup the group we may be coming from
 * @param beforeSubgroup the subgroup we may be coming from
 * @param afterSubgroup the subgroup we may be going to
 * @returns the time in minutes to move between these subgroups
 */
function calculateMovementTime(
	beforeGroup: string,
	beforeSubgroup: string[] | null,
	afterSubgroup: string[]
) {
	if (movedCampuses(beforeGroup, afterSubgroup)) {
		let delta = 0;
		const newGroup = getGroupFromSubgroup(afterSubgroup);

		if (
			(beforeGroup === 'West Campus' && newGroup === 'South Campus') ||
			(beforeGroup === 'South Campus' && newGroup === 'West Campus')
		) {
			delta += 8;
		} else if (
			(beforeGroup === 'West Campus' && newGroup === 'Collegetown Apts / Dorms') ||
			(beforeGroup === 'Collegetown Apts / Dorms' && newGroup === 'West Campus')
		) {
			delta += 8;
		} else if (
			(beforeGroup === 'West Campus' && newGroup === 'North Campus') ||
			(beforeGroup === 'North Campus' && newGroup === 'West Campus')
		) {
			delta += 8;
		} else if (
			(beforeGroup === 'North Campus' &&
				afterSubgroup.sort().join(',') === SORORITY_GROUP_ONE.sort().join(',')) ||
			(beforeSubgroup?.sort().join(',') === SORORITY_GROUP_ONE.sort().join(',') &&
				newGroup === 'North Campus')
		) {
			delta += 8;
		} else if (
			(beforeGroup === 'South Campus' &&
				afterSubgroup.sort().join(',') === SORORITY_GROUP_TWO.sort().join(',')) ||
			(beforeSubgroup?.sort().join(',') === SORORITY_GROUP_TWO.sort().join(',') &&
				newGroup === 'South Campus')
		) {
			delta += 8;
		} else if (
			(beforeGroup === 'Collegetown Apts / Dorms' &&
				afterSubgroup.sort().join(',') === SORORITY_GROUP_TWO.sort().join(',')) ||
			(beforeSubgroup?.sort().join(',') === SORORITY_GROUP_TWO.sort().join(',') &&
				newGroup === 'Collegetown Apts / Dorms')
		) {
			delta += 8;
		} else if (
			(beforeGroup === 'South Campus' && newGroup === 'Collegetown Apts / Dorms') ||
			(beforeGroup === 'Collegetown Apts / Dorms' && newGroup === 'South Campus')
		) {
			// legacy stuff — should never be shown since we merge south & ctown & other
			delta += 8;
		} else {
			// includes north & collegetown apts/dorms
			delta += BASE_BETWIXT_CAMPUS_MOVE_TIME;
		}

		return delta;
	} else {
		if (movedSubGroups(beforeSubgroup, afterSubgroup)) {
			if (isOnNorth(afterSubgroup)) {
				// Check to see if they share a value in the subgroup
				let delta = 0;
				if (beforeSubgroup === null || beforeSubgroup.some((loc) => afterSubgroup.includes(loc))) {
					delta += WITHIN_CAMPUS_MOVE_TIME_SHARED_DORM * NORTH_MULTIPLIER;
				} else {
					delta += WITHIN_CAMPUS_MOVE_TIME_NO_SHARED_DORM * NORTH_MULTIPLIER;
				}

				// Redo — check directly for a pair in the north precise subgroups.
				const gotten = preciseSubgroupDistances.getPair(beforeSubgroup ?? [], afterSubgroup);
				if (gotten !== undefined) {
					delta = gotten;
				}

				return delta;
			} else {
				let delta = 0;
				if (beforeSubgroup === null || beforeSubgroup.some((loc) => afterSubgroup.includes(loc))) {
					delta += WITHIN_CAMPUS_MOVE_TIME_SHARED_DORM;
				} else {
					delta += WITHIN_CAMPUS_MOVE_TIME_NO_SHARED_DORM;
				}

				// Redo — check directly for a pair in the south precise subgroups.
				const gotten = preciseSubgroupDistances.getPair(beforeSubgroup ?? [], afterSubgroup);
				if (gotten !== undefined) {
					delta = gotten;
				} else {
					// It is still possible that it could be west...
					if (
						beforeSubgroup?.every((loc) => WEST_GROUP_ONE.includes(loc)) &&
						afterSubgroup.every((loc) => WEST_GROUP_ONE.includes(loc))
					) {
						delta = 2.5;
					} else if (
						beforeSubgroup?.every((loc) => WEST_GROUP_TWO.includes(loc)) &&
						afterSubgroup.every((loc) => WEST_GROUP_TWO.includes(loc))
					) {
						delta = 2.5;
					} else if (
						beforeSubgroup?.every((loc) => WEST_GROUP_ONE.includes(loc)) &&
						afterSubgroup.every((loc) => WEST_GROUP_TWO.includes(loc))
					) {
						delta = 5;
					} else if (
						beforeSubgroup?.every((loc) => WEST_GROUP_TWO.includes(loc)) &&
						afterSubgroup.every((loc) => WEST_GROUP_ONE.includes(loc))
					) {
						delta = 5;
					}
				}

				return delta;
			}
		} else {
			// Don't really need this line, just for informational purposes.
			// We stayed on the same campus and subgroup.
			return 0;
		}
	}
}

/**
 * findFittestAvailableOrNewTruck finds the best truck to assign some appointments to.
 * @param genericOutputMap the map of trucks and their current assignments
 * @param askedForTimeslot the timeslot the order is in
 * @param askedForNewSubgroup the subgroup the order is in
 * @param appointsForSubgroup the appointments for the subgroup
 * @param isPeakMode whether the algorithm is running in peak mode (for mid-May, see README)
 * @param isMerge whether the algorithm is running in merge mode (for merging trucks) (note that **merges must be full**)
 * @param tryingToMerge the truck that is trying to merge (if isMerge is true)
 * @returns the best truck to assign the order to, might be new, as well as its minute-fitness
 */
function findFittestAvailableOrNewTruck(
	genericOutputMap: GenericOutputMap,
	askedForTimeslot: string,
	askedForNewSubgroup: string[],
	appointsForSubgroup: (Appointment & FirebaseOrder)[],
	isPeakMode = false,
	isMerge = false,
	tryingToMerge: string | null = null
): [VehicleType | null, number] {
	let bestTruck: string | null = 'High Roof'; // better than BR Van
	let lowestFitness = 999_999_999;

	// Catch the case where we recursed to an empty appointsForSubgroup.
	if (appointsForSubgroup.length === 0) {
		return ['High Roof', 0];
	}

	for (const [key, value] of genericOutputMap) {
		if (isMerge && tryingToMerge === key) {
			// Don't consider it itself as the best truck, obviously.
			continue;
		}

		// ES6 maps preserve order so it will prioritize High Roof etc.
		// NOTE: right now value is never null.
		// Legacy logic where we assign other addresses to BR Van.
		// (The new logic is that it is in the same campus as south + ctown and
		// we try to have the algorithm cover this.)

		/* if (
			isPeakMode &&
			key === 'BR Van' &&
			// new special logic: assign other stuff to br van as possible (i.e. if other)
			getGroupFromSubgroup(askedForNewSubgroup) !== 'Other Address'
		) {
			continue;
		} else if (
			// Also considering pre-emptively assigning to high roof as well.
			isPeakMode &&
			key !== 'BR Van' &&
			getGroupFromSubgroup(askedForNewSubgroup) === 'Other Address'
		) {
			// in peak mode, only br van + high roof can be automatically assigned to other addresses
			if (bestTruck !== 'BR Van') {
				bestTruck = null; // means that it is unassigned
			}
			continue;
		} */

		if (isPeakMode && key === 'BR Van') {
			continue;
		}

		if (value.lastSeenGroup === null) {
			// exit the loop, null from here on anyway
			if (
				lowestFitness === 999_999_999 ||
				isMerge // never add new trucks when merging
			) {
				lowestFitness = 888_888_888;
				bestTruck = key;
				break;
			} else {
				const currentFitness = MINUTE_COST_OF_NEW_VEHICLE; // cost of creating a new truck + moving
				if (currentFitness < lowestFitness) {
					bestTruck = key;
					lowestFitness = currentFitness;
				}
			}
		} else {
			// Don't consider any trucks that are *already* physically full in some way
			// (because we then cannot even add partially to them).
			if (
				key.startsWith('Truck') &&
				(value.timeMap.get(askedForTimeslot)![1].filter((x) => x[0].type !== 'Supplies').length +
					(isMerge
						? appointsForSubgroup.filter((a) => a.type !== 'Supplies').length - 1 // -1 due to legacy >=
						: 0) >=
					TRUCK_MAX_APPOINTMENTS_PER_TIMESLOT ||
					Array.from(value.timeMap.values()).reduce(
						(acc, v) => acc + v[1].filter((e) => e[0].type !== 'Supplies').length,
						0
					) +
					(isMerge ? appointsForSubgroup.filter((a) => a.type !== 'Supplies').length - 1 : 0) >=
					TRUCK_ORDER_CAPACITY ||
					Array.from(value.timeMap.values()).reduce(
						(acc, v) =>
							acc + v[1].reduce((acc2, x) => acc2 + extractEstimatedItems(x[0].estimatedItems), 0),
						0
					) >= TRUCK_ITEM_CAPACITY)
			) {
				continue;
			}

			// Special logic for BR Van & High Roof because they can be refilled throughout the day.
			// Don't bother with this merge mode since not reached.
			if (
				key === 'BR Van' &&
				(value.timeMap.get(askedForTimeslot)![1].filter((x) => x[0].type !== 'Supplies').length >=
					BR_VAN_MAX_APPOINTMENTS_PER_TIMESLOT ||
					calculateAppointmentsSinceLastEmpty(genericOutputMap, 'BR Van', askedForTimeslot) >=
					BR_VAN_ORDER_CAPACITY)
			) {
				continue;
			}

			const CALCULATED_HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT = isPeakMode
				? Math.floor(
					HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT * PEAK_MODE_HIGHROOF_CAPACITY_MULTIPLIER
				)
				: HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT;

			const CALCULATED_HIGHROOF_ORDER_CAPACITY = isPeakMode
				? Math.floor(HIGHROOF_ORDER_CAPACITY * PEAK_MODE_HIGHROOF_CAPACITY_MULTIPLIER)
				: HIGHROOF_ORDER_CAPACITY;

			// NOTE: another exception — High Roof cannot be refilled (algorithmically) if it is peak though.
			// Don't bother with merge mode stuff since not reached.
			if (isPeakMode) {
				if (
					key === 'High Roof' &&
					(value.timeMap.get(askedForTimeslot)![1].filter((x) => x[0].type !== 'Supplies').length >=
						CALCULATED_HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT ||
						Array.from(value.timeMap.values()).reduce(
							(acc, v) => acc + v[1].filter((a) => a[0].type !== 'Supplies').length,
							0
						) >= CALCULATED_HIGHROOF_ORDER_CAPACITY)
				) {
					continue;
				}
			} else {
				if (
					key === 'High Roof' &&
					(value.timeMap.get(askedForTimeslot)![1].filter((x) => x[0].type !== 'Supplies').length >=
						HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT ||
						calculateAppointmentsSinceLastEmpty(genericOutputMap, 'High Roof', askedForTimeslot) >=
						HIGHROOF_ORDER_CAPACITY)
				) {
					continue;
				}
			}

			// Don't consider any new trucks that would not have time to get there
			// and perform load (variable).

			// TODO: we might want to be able to merge *anywhere* into
			// a truck that has space for the timeslot. (Right now, we just merge into the end.)
			// In that case we would find the closest subgroup / group to the new one and merge there,
			// making sure that either the first of the next timeslot or next of the current timeslot
			// has space for the delta.

			// (I have a separate branch where I am testing this out.)

			const moveMinutes = calculateMovementTime(
				value.lastSeenGroup,
				value.lastSeenSubgroup,
				askedForNewSubgroup
			);

			// Need to deal with making sure that the truck being merged into still
			// has time to fulfill its next order too!
			// In order to accomplish this, we compare the initial movement time between 'old end - old next start'
			// with updated movement time 'new end - old next start' and see if next timeslot has space for delta.
			if (isMerge) {
				const updatedMovementTime = calculateMovementTime(
					value.lastSeenGroup,
					value.lastSeenSubgroup,
					askedForNewSubgroup
				);

				// To find the old movement time, we look at the last order for this timeslot
				// and compare it to the first order for the next timeslot.
				let nextTimeslotInfoForThisTruck:
					| [number, [Appointment & FirebaseOrder, string[]][]]
					| null = null;
				let found = false;
				for (const [t, info] of value.timeMap) {
					if (found) {
						nextTimeslotInfoForThisTruck = info;
						break;
					}
					if (t === askedForTimeslot) {
						found = true;
					}
				}

				// means that we are not using the next timeslot — has zero
				if (
					nextTimeslotInfoForThisTruck &&
					(nextTimeslotInfoForThisTruck[0] === 0 || nextTimeslotInfoForThisTruck[1].length === 0)
				) {
					nextTimeslotInfoForThisTruck = null;
				}

				// if null, last one of the day, definitely ok
				if (nextTimeslotInfoForThisTruck) {
					const firstNextTimeslot = nextTimeslotInfoForThisTruck[1][0];
					const originalMoveMinutes = calculateMovementTime(
						value.lastSeenGroup,
						value.lastSeenSubgroup,
						firstNextTimeslot[1]
					);

					// definitely ok if originalMoveMinutes >= updatedMovementTime,
					// but otherwise...
					if (updatedMovementTime > originalMoveMinutes) {
						const delta = updatedMovementTime - originalMoveMinutes;
						if (
							nextTimeslotInfoForThisTruck[0] + delta >
							MINUTES_PER_TIMESLOT - BACKEND_BUFFER_CUSHION
						) {
							continue;
						}
					}
				}
			}

			let totalMultiply = 0;
			for (const app of appointsForSubgroup) {
				if (app.type === 'Supplies' && (key === 'BR Van' || key === 'High Roof')) {
					totalMultiply += 1 * BR_VAN_AND_HIGHROOF_SUPPLIES_EMPHASIS_MULTIPLIER;
				} else {
					totalMultiply += 1;
				}
			}
			// average out total multiply
			totalMultiply /= appointsForSubgroup.length;
			const sizeOneHRPeakMultiply =
				key === 'High Roof' && appointsForSubgroup.length === 1 && isPeakMode
					? PEAK_MODE_HIGHROOF_SIZE_ONE_ORDER_MULTIPLIER
					: 1;

			const multipliedMoveMinutes = moveMinutes * totalMultiply * sizeOneHRPeakMultiply;

			// Another potentialy 'impossibility' is if it cannot fulfill in time.
			if (
				multipliedMoveMinutes + // moving around time
				appointsForSubgroup.filter(
					(x) =>
						x.type !== 'Supplies' &&
						!GOTHIC_LIST.includes(toProperFormatting(x.location ?? 'xxxxxxxxxx')) &&
						!toProperFormatting(x.location ?? 'xxxxxxxxxx').includes('Low Rise') &&
						!toProperFormatting(x.location ?? 'xxxxxxxxxx').includes('Risley')
				).length *
				TIME_TO_FULFILL_APPOINTMENT + // normal appointments in a normal place
				appointsForSubgroup.filter(
					(x) =>
						x.type === 'Supplies' &&
						!GOTHIC_LIST.includes(toProperFormatting(x.location ?? 'xxxxxxxxxx')) &&
						!toProperFormatting(x.location ?? 'xxxxxxxxxx').includes('Low Rise') &&
						!toProperFormatting(x.location ?? 'xxxxxxxxxx').includes('Risley')
				).length *
				TIME_TO_FULFILL_APPOINTMENT *
				TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER + // supplies appointments in a normal place
				appointsForSubgroup.filter(
					(x) =>
						x.type !== 'Supplies' &&
						(GOTHIC_LIST.includes(toProperFormatting(x.location ?? 'xxxxxxxxxx')) ||
							toProperFormatting(x.location ?? 'xxxxxxxxxx').includes('Low Rise') ||
							toProperFormatting(x.location ?? 'xxxxxxxxxx').includes('Risley'))
				).length *
				TIME_TO_FULFILL_APPOINTMENT *
				LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER + // normal appointments in a slow place
				appointsForSubgroup.filter(
					(x) =>
						x.type === 'Supplies' &&
						(GOTHIC_LIST.includes(toProperFormatting(x.location ?? 'xxxxxxxxxx')) ||
							toProperFormatting(x.location ?? 'xxxxxxxxxx').includes('Low Rise') ||
							toProperFormatting(x.location ?? 'xxxxxxxxxx').includes('Risley'))
				).length *
				TIME_TO_FULFILL_APPOINTMENT *
				TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER *
				LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER + // supplies appointments in a slow place
				value.timeMap.get(askedForTimeslot)![0] >
				MINUTES_PER_TIMESLOT - BACKEND_BUFFER_CUSHION
			) {
				continue;
			} else {
				const currentFitness = multipliedMoveMinutes; // multiply by totalMultiply
				if (currentFitness < lowestFitness) {
					bestTruck = key;
					if (!isMerge) {
						lowestFitness = currentFitness;
					} else {
						// We have an exception — don't want to merge into higher-number truck if that truck is empty for the timeslot.
						if (
							value.timeMap.get(askedForTimeslot)![1].length === 0 &&
							key > (tryingToMerge ?? '') // type handling, should never be null if isMerge is true
						) {
							continue;
						} else {
							lowestFitness = currentFitness;
						}
					}
				}
			}
		}
	}

	if (lowestFitness === 888_888_888) {
		// we are going into here for some reason for may 20th
		lowestFitness = 0; // new truck sent, can go early
	} else if (lowestFitness === 999_999_999 && bestTruck !== 'High Roof') {
		lowestFitness = 0; // new truck sent, can go early
	} else if (lowestFitness === 999_999_999 && bestTruck === 'High Roof') {
		// We do not want the best truck to be a high roof because no other truck was available!
		// The issue here is that we have too many appointments that no truck can possibly take them
		// on (e.g. 25). Split this.
		return findFittestAvailableOrNewTruck(
			genericOutputMap,
			askedForTimeslot,
			askedForNewSubgroup,
			appointsForSubgroup.slice(0, Math.floor(appointsForSubgroup.length / 2)),
			isPeakMode,
			isMerge,
			tryingToMerge
		);
	}

	return [bestTruck, lowestFitness];
}

/**
 * Takes a map of the output of the algorithm before merging and performs optimized merges.
 * (Deals with lack of optimality when peak is earlier in the day.)
 * For implementation details, refer to `README.md` in this folder.
 * Only run during peak mode.
 * @param genericOutputMap the output of the algorithm before merging
 */
function performOptimizedMerges(genericOutputMap: GenericOutputMap): GenericOutputMap {
	// We iterate through a few times so that we can merge leftwards with zeroes as much as possible.
	for (let i = 0; i < FINAL_MERGE_ITERATIONS; i++) {
		// Find possibly mergeable truck-timeslot pairs.
		const mergeablePairs: [string, string][] = [];
		for (const [truck, value] of genericOutputMap) {
			if (truck === 'BR Van' || truck === 'High Roof') continue;
			for (const [time, appointmentsContainer] of value.timeMap) {
				if (
					appointmentsContainer[1].length > 0 &&
					appointmentsContainer[1].length <= TRUCK_TIMESLOT_MERGE_THRESHOLD
				) {
					mergeablePairs.push([truck, time]);
				}
			}
		}

		// Perform merges where possible *without* creating new trucks.
		for (const [truck, time] of mergeablePairs) {
			const appointments = genericOutputMap.get(truck)!.timeMap.get(time)![1];
			// It is possible that the # of appointments has grown
			// as we may have e.g. merged small A -> small B => large B.
			if (appointments.length > TRUCK_TIMESLOT_MERGE_THRESHOLD) {
				continue;
			}
			// Safety check — should never happen.
			if (appointments.length === 0) {
				continue;
			}

			const [mergeIntoTruck, mergeIntoTime] = findFittestAvailableOrNewTruck(
				genericOutputMap,
				time,
				appointments.map((a) => toProperFormatting(a[0].location ?? 'xxxxxxxxxx')),
				appointments.map((a) => a[0]),
				true, // it must be peak mode for this function to be called
				true,
				truck
			);

			// check for nulls (should not happen unless every other truck is full)
			if (mergeIntoTruck !== null) {
				const mergeIntoTruckTimeMap = genericOutputMap.get(mergeIntoTruck)!.timeMap;

				// Add the new data to the truck we are merging into.
				const mergeIntoTruckAppointments = mergeIntoTruckTimeMap.get(time)![1];
				const sortedAppointments = appointments.sort((a, b) => {
					if (a[0].location === b[0].location) {
						return 0;
					}
					return (a[0].location ?? '').localeCompare(b[0].location ?? '');
				});

				mergeIntoTruckAppointments.push(...sortedAppointments); // want nice order
				mergeIntoTruckTimeMap.set(time, [
					// Update the timeMap for the truck we are merging into.
					// We don't technically need this but good for consistency or future updates.
					mergeIntoTruckTimeMap.get(time)![0] +
					mergeIntoTime +
					sortedAppointments.filter(
						(app) =>
							app[0].type !== 'Supplies' &&
							!app[0].location?.includes('Low Rise') &&
							!app[0].location?.includes('Risley') &&
							!GOTHIC_LIST.includes(app[0].location ?? 'xxxxxxxxxx')
					).length *
					TIME_TO_FULFILL_APPOINTMENT + // normal appointments in a normal place
					sortedAppointments.filter(
						(app) =>
							app[0].type === 'Supplies' &&
							!app[0].location?.includes('Low Rise') &&
							!app[0].location?.includes('Risley') &&
							!GOTHIC_LIST.includes(app[0].location ?? 'xxxxxxxxxx')
					).length *
					TIME_TO_FULFILL_APPOINTMENT *
					TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER + // supplies appointments in a normal place
					sortedAppointments.filter(
						(app) =>
							app[0].type !== 'Supplies' &&
							(app[0].location?.includes('Low Rise') ||
								app[0].location?.includes('Risley') ||
								GOTHIC_LIST.includes(app[0].location ?? 'xxxxxxxxxx'))
					).length *
					TIME_TO_FULFILL_APPOINTMENT *
					LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER + // normal appointments in a slow place
					sortedAppointments.filter(
						(app) =>
							app[0].type === 'Supplies' &&
							(app[0].location?.includes('Low Rise') ||
								app[0].location?.includes('Risley') ||
								GOTHIC_LIST.includes(app[0].location ?? 'xxxxxxxxxx'))
					).length *
					TIME_TO_FULFILL_APPOINTMENT *
					TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER *
					LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER, // supplies appointments in a slow place,
					mergeIntoTruckAppointments
				]);

				// Remove the appointments from the old truck.
				genericOutputMap.get(truck)!.timeMap.set(time, [0, []]);

				// NOTE: we do not have to deal with the question of 'is there enough time to
				// move between previous and post orders for the truck being merged from'
				// because they can just go leave from the a lot early or whatnot.
				// (They effectively have two hours...)
			} else {
				// If it is null, we skip the merge — not beneficial.
				continue;
			}
		}
	}

	return genericOutputMap;
}

// sleep is a helper function for testing the algorithm.
// const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * Assigns the appointments to the appropriate trucks (optimizing the route and saving time).
 * Speed: takes a trivial amount of time to perform, even for large datasets.
 *
 * @param appointments the appointments to calculate the required trucks for.
 * @param isPeakMode whether to run the algorithm in peak mode (see README, for mid-May).
 * @returns a map of what truck is assigned to what appointment, as well as a boolean
 * indicating whether the algorithm was able to find a solution.
 */
export default function algorithm(
	appointments: Record<string, (Appointment & FirebaseOrder)[]>,
	isPeakMode = false
): [GenericOutputMap, boolean] {
	// A very few appointments are kinda jank (no location, special type, etc.), we need to ignore these.
	appointments = Object.fromEntries(
		Object.entries(appointments).map(([time, apps]) => [
			time,
			apps.filter((app) => app.location !== null && app.location !== '')
		])
	);
	let genericOutputMap: GenericOutputMap = new Map();
	// Add in BR Van, High Roof, and Truck 1, Truck 2, ..., Truck 10 to genericOutputMap
	// with null values.
	const keysToSet = [
		'High Roof', // best to use first as has more capacity
		'BR Van',
		'Truck 1',
		'Truck 2',
		'Truck 3',
		'Truck 4',
		'Truck 5',
		'Truck 6',
		'Truck 7',
		'Truck 8',
		'Truck 9',
		'Truck 10'
	];
	const timesToSet = DISCRETE_TIMESLOTS;
	for (const key of keysToSet) {
		const timeMap = new Map<string, [number, [Appointment & FirebaseOrder, string[]][]]>();
		for (const time of timesToSet) {
			timeMap.set(time, [0, []]);
		}
		genericOutputMap.set(key, {
			lastSeenGroup: null,
			lastSeenSubgroup: null,
			timeMap
		});
	}

	const fulfilledOrderNumbers = new Set<string>();

	// If there are no appointments, return an empty object.
	if (Object.keys(appointments).length === 0) {
		return [genericOutputMap, true];
	}

	// NOTE: deal with forcible orders somehow? or maybe these are just made *after* the algo runs...

	// Maybe give a small bonus for using a truck that has already been used?
	// Right now after we add in the trucks, then it it effectively picks the closest one.
	// However, for every timeslot we want to use as few trucks as possible.
	// Go to OH for linalg for this?
	// Update: asked Thomas and he said to first just make the algorithm integrate with the UI and then we can
	// go over optimization.

	for (const time of DISCRETE_TIMESLOTS) {
		let filteredSize = 999; // non-zero
		let iterations = 0;
		while (filteredSize !== 0) {
			if (iterations > 1_000 && iterations < 3_000 && iterations % 100 === 0) {
				// Try at least to perform some optimized merges.
				// Have confirmed that this leads to improvements.
				iterations++;
				genericOutputMap = performOptimizedMerges(genericOutputMap);
				continue;
			} else if (iterations > 3_000) {
				// We don't want to hang their entire browser, give up.
				return [genericOutputMap, false];
			}

			const calculatedFilteredSubgroups = calculateFilteredSubgroups(
				appointments,
				time,
				fulfilledOrderNumbers
			);
			filteredSize = calculatedFilteredSubgroups.size;

			if (filteredSize === 0) {
				break;
			}

			// Sort the subgroups by the number of appointments in them.
			const sortedSubgroups = Array.from(calculatedFilteredSubgroups.entries()).sort((a, b) => {
				if (b[1] - a[1] !== 0) {
					return b[1] - a[1];
				} else {
					// Randomize the order of those that have a tie in the number of appointments
					// to avoid biasing towards the first one.
					return Math.random() - 0.5;
				}
			});

			// Fulfill all orders in that pairing.
			// First off, update fulfilled order IDs.
			// Find all the appointments for that time with that subgroup.
			const appointmentsForTime = appointments[time];
			const appointmentsForSubgroup = appointmentsForTime.filter(
				(app) =>
					sortedSubgroups[0][0].includes(toProperFormatting(app.location ?? 'xxxxxxxxxx')) ||
					sortedSubgroups[0][0].some((loc) =>
						loc.includes(toProperFormatting(app.location ?? 'zzzzzzzzzz'))
					)
			);

			// Aside: read in best truck & its time for this, we just needed the appointmentsForSubgroup.
			const [fittestTruck, fittestTime] = findFittestAvailableOrNewTruck(
				genericOutputMap,
				time,
				sortedSubgroups[0][0],
				appointmentsForSubgroup,
				isPeakMode
			);

			if (!fittestTruck) {
				// skip — want manual assignment
				for (const app of appointmentsForSubgroup) {
					fulfilledOrderNumbers.add(app.orderNumber);
				}
				continue;
			}

			const CALCULATED_HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT = isPeakMode
				? Math.floor(
					HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT * PEAK_MODE_HIGHROOF_CAPACITY_MULTIPLIER
				)
				: HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT;

			// Reduce subgroups that are simply too huge — only fulfill first n
			let addableCount = 999_999;
			if (fittestTruck === 'BR Van') {
				addableCount = BR_VAN_MAX_APPOINTMENTS_PER_TIMESLOT;
			} else if (fittestTruck === 'High Roof') {
				addableCount = CALCULATED_HIGHROOF_MAX_APPOINTMENTS_PER_TIMESLOT;
			} else if (fittestTruck.startsWith('Truck')) {
				addableCount = TRUCK_MAX_APPOINTMENTS_PER_TIMESLOT;
			}

			// Update group & subgroup for that truck in the generic
			// order map.
			const currentTruck = genericOutputMap.get(fittestTruck);
			if (!currentTruck) {
				genericOutputMap.set(fittestTruck, {
					lastSeenGroup: getGroupFromSubgroup(sortedSubgroups[0][0]),
					lastSeenSubgroup: sortedSubgroups[0][0],
					timeMap: new Map<string, [number, [Appointment & FirebaseOrder, string[]][]]>()
				});
			} else {
				currentTruck.lastSeenGroup = getGroupFromSubgroup(sortedSubgroups[0][0]);
				currentTruck.lastSeenSubgroup = sortedSubgroups[0][0];
			}

			const timeMap = genericOutputMap.get(fittestTruck)!.timeMap;
			const currentAppointments = timeMap.get(time);

			const usedIDs = new Map<string, ['normal' | 'supplies', string]>();

			for (const app of appointmentsForSubgroup) {
				if (
					(currentAppointments ?? [0, []])[1].length +
					Array.from(usedIDs).filter((x) => x[1][0] === 'normal').length >=
					addableCount // don't count supplies dropoff towards capacities
				) {
					break;
				}
				if (!fulfilledOrderNumbers.has(app.orderNumber)) {
					fulfilledOrderNumbers.add(app.orderNumber);
					usedIDs.set(app.orderNumber, [
						app.type === 'Supplies' ? 'supplies' : 'normal',
						toProperFormatting(app.location ?? 'xxxxxxxxxx')
					]);
				}
			}

			// Slice the appointments to only include the relevant values.
			const usedAppointmentsForSubgroup = appointmentsForSubgroup.filter((app) =>
				usedIDs.has(app.orderNumber)
			);

			// Sort usedAppointmentsForSubgroup so that same-names are grouped together.
			// NOTE: it does not matter that we do not maintain the first and last because
			// these are effectively in the same place.
			usedAppointmentsForSubgroup.sort((a, b) => {
				if (a.location === b.location) {
					return 0;
				}
				return (a.location ?? '').localeCompare(b.location ?? '');
			});

			const formattedUsedAppointmentsForSubgroup: [Appointment & FirebaseOrder, string[]][] =
				usedAppointmentsForSubgroup.map((app: Appointment & FirebaseOrder) => [
					app,
					sortedSubgroups[0][0]
				]);

			// Update timemap for that truck in the generic order map.
			// Only thing that really matters is the time for non-supplies appts.
			if (!currentAppointments) {
				timeMap.set(time, [
					fittestTime +
					Array.from(usedIDs.values()).filter(
						(x) =>
							x[0] !== 'supplies' &&
							!x[1].includes('Low Rise') &&
							!x[1].includes('Risley') &&
							!GOTHIC_LIST.includes(x[1])
					).length *
					TIME_TO_FULFILL_APPOINTMENT + // normal appointments in a normal place
					Array.from(usedIDs.values()).filter(
						(x) =>
							x[0] === 'supplies' &&
							!x[1].includes('Low Rise') &&
							!x[1].includes('Risley') &&
							!GOTHIC_LIST.includes(x[1])
					).length *
					TIME_TO_FULFILL_APPOINTMENT *
					TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER + // supplies appointments in a normal place
					Array.from(usedIDs.values()).filter(
						(x) =>
							x[0] !== 'supplies' &&
							(x[1].includes('Low Rise') || x[1].includes('Risley') || GOTHIC_LIST.includes(x[1]))
					).length *
					TIME_TO_FULFILL_APPOINTMENT *
					LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER + // normal appointments in a slow place
					Array.from(usedIDs.values()).filter(
						(x) =>
							x[0] === 'supplies' &&
							(x[1].includes('Low Rise') || x[1].includes('Risley') || GOTHIC_LIST.includes(x[1]))
					).length *
					TIME_TO_FULFILL_APPOINTMENT *
					TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER *
					LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER, // supplies appointments in a slow place
					formattedUsedAppointmentsForSubgroup
				]);
			} else {
				timeMap.set(time, [
					currentAppointments[0] +
					fittestTime +
					Array.from(usedIDs.values()).filter(
						(x) =>
							x[0] !== 'supplies' &&
							!x[1].includes('Low Rise') &&
							!x[1].includes('Risley') &&
							!GOTHIC_LIST.includes(x[1])
					).length *
					TIME_TO_FULFILL_APPOINTMENT + // normal appointments in a normal place
					Array.from(usedIDs.values()).filter(
						(x) =>
							x[0] === 'supplies' &&
							!x[1].includes('Low Rise') &&
							!x[1].includes('Risley') &&
							!GOTHIC_LIST.includes(x[1])
					).length *
					TIME_TO_FULFILL_APPOINTMENT *
					TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER + // supplies appointments in a normal place
					Array.from(usedIDs.values()).filter(
						(x) =>
							x[0] !== 'supplies' &&
							(x[1].includes('Low Rise') || x[1].includes('Risley') || GOTHIC_LIST.includes(x[1]))
					).length *
					TIME_TO_FULFILL_APPOINTMENT *
					LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER + // normal appointments in a slow place
					Array.from(usedIDs.values()).filter(
						(x) =>
							x[0] === 'supplies' &&
							(x[1].includes('Low Rise') || x[1].includes('Risley') || GOTHIC_LIST.includes(x[1]))
					).length *
					TIME_TO_FULFILL_APPOINTMENT *
					TIME_TO_FULFILL_SUPPLIES_APPOINTMENT_MULTIPLIER *
					LOWRISE_RISLEY_AND_GOTHIC_MULTIPLIER, // supplies appointments in a slow place
					currentAppointments[1].concat(formattedUsedAppointmentsForSubgroup)
				]);
			}

			iterations += 1;
		}
	}

	if (isPeakMode) {
		return [performOptimizedMerges(genericOutputMap), true];
	} else {
		return [genericOutputMap, true];
	}
}

/**
 * scoreGenericOutputMap scores the generic output map, for use in comparing different outputs.
 * A lower score is better. This is a function of truck idleness, which is directly related to
 * efficiency.
 * @param genericOutputMap the map of trucks and their current assignments
 * @returns the total score of the generic output map
 */
export function scoreGenericOutputMap(genericOutputMap: GenericOutputMap): number {
	let score = 0;
	for (const value of genericOutputMap.values()) {
		for (const info of value.timeMap.values()) {
			if (info[0] !== 0) {
				score += MINUTES_PER_TIMESLOT - BACKEND_BUFFER_CUSHION - info[0];
			}
		}
	}
	return score;
}

/**
 * getGenericOutputMapProfit calculates the profit of the generic output map.
 * @param genericOutputMap the map of trucks and their current assignments
 * @returns the total profit of the generic output map
 */
export function getGenericOutputMapProfit(genericOutputMap: GenericOutputMap): number {
	let profit = 0;

	for (const [k, v] of genericOutputMap.entries()) {
		if (
			Array.from(v.timeMap.values())
				.map((x) => x[1].length)
				.reduce((a, b) => a + b, 0) !== 0 &&
			(k.includes('Truck') || k.includes('High Roof'))
		) {
			// Renting out a new truck.
			profit -= RENT_TRUCK_PER_DAY_COST;
		}
		for (const timeslot of v.timeMap.values()) {
			profit += timeslot[1].length * VALUE_PER_ORDER;
			if (timeslot[1].length >= USE_THREE_FIELD_REPS_THRESHOLD) {
				profit -= (3 * FIELD_REP_WAGE + 1 * DRIVER_WAGE) * 2; // 2 hours
			} else if (timeslot[1].length >= USE_TWO_FIELD_REPS_THRESHOLD) {
				profit -= (2 * FIELD_REP_WAGE + 1 * DRIVER_WAGE) * 2;
			} else if (timeslot[1].length > 0) {
				profit -= (1 * FIELD_REP_WAGE + 1 * DRIVER_WAGE) * 2;
			}
		}
	}

	return profit;
}

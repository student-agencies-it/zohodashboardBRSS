import {
	PRIVATE_FEDEX_SECRET_KEY,
	PRIVATE_FEDEX_API_KEY,
	PRIVATE_HOMEBASE_API_KEY,
	PRIVATE_SALESFORCE_JWT_TOKEN,
	PRIVATE_FEDEX_API_URL
} from '$env/static/private';

/**
 * Gets an access token from Salesforce using the stored never-expiring JWT token
 * @returns the access token, with an expiry of one hour
 */
async function getAccessToken() {
	const res = await fetch(
		`https://login.salesforce.com/services/oauth2/token?grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${PRIVATE_SALESFORCE_JWT_TOKEN}`,
		{
			method: 'POST'
		}
	);

	return (await res.json()) as { access_token: string; expires_in: number; };
}

/**
 * Gets an access token from FedEx using the stored client ID and secret
 * @returns the access token, with an expiry of one hour
 */
export async function getFedExAccessToken() {
	const body = `grant_type=client_credentials&client_id=${encodeURIComponent(PRIVATE_FEDEX_API_KEY)}&client_secret=${encodeURIComponent(PRIVATE_FEDEX_SECRET_KEY)}`;

	const res = await fetch(`${PRIVATE_FEDEX_API_URL}/oauth/token`, {
		method: 'POST',
		body: body,
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded'
		}
		// NOTE: the below breaks cloudflare.
		// > The 'credentials' field on 'RequestInitializerDict' is not implemented.
		// credentials: 'include'
	});

	return ((await res.json()) as { access_token: string; expires_in: number; }).access_token;
}

/**
 * Fetches from Salesforce using the stored JWT token.
 * @param url the *full* URL to fetch from
 * @param init any additional fetch options
 * @param type the content type of the request
 * @returns the JSON response from the server
 */
export default async function credentialedFetch<T>(
	url: string,
	init?: object,
	type = 'application/json'
): Promise<T> {
	const { access_token } = await getAccessToken();
	const headers: {
		[key: string]: string;
	} = {
		Authorization: `Bearer ${access_token}`
	};

	if (type !== 'multipart/form-data') {
		headers['Content-Type'] = type;
	}

	const options = init ? { ...init, headers } : { headers };
	let res = await fetch(url, options);
	let result = await res.json() as { done: boolean; nextRecordsUrl?: string; records: T[]; };
	let allRecords = result.records;

	while (!result.done && result.nextRecordsUrl) {
		res = await fetch(`https://d61000000jlzveao.my.salesforce.com${result.nextRecordsUrl}`, options);
		result = await res.json() as { done: boolean; nextRecordsUrl?: string; records: T[]; };
		allRecords = allRecords.concat(result.records);
	}

	return { records: allRecords } as T;
}

/**
 * Fetches from Homebase using the stored private API key.
 * @param url the *full* URL to fetch from
 * @param init any additional fetch options
 * @param type the content type of the request
 * @returns the JSON response from the server
 */
export async function credentialedHomebaseFetch<T>(
	url: string,
	init?: object,
	type = 'application/json'
): Promise<T> {
	const headers: {
		[key: string]: string;
	} = {
		Authorization: `Bearer ${PRIVATE_HOMEBASE_API_KEY}`
	};

	if (type !== 'multipart/form-data') {
		headers['Content-Type'] = type;
	}

	const options = init ? { ...init, headers } : { headers };
	// add credentials include to options
	const res = await fetch(url, options);
	return await res.json();
}

/**
 * Fetches from FedEx using the stored client ID and secret.
 * @param url the *full* URL to fetch from
 * @param init any additional fetch options
 * @param type the content type of the request
 * @returns the JSON response from the server
 */
export async function credentialedFedExFetch<T>(
	url: string,
	init?: object,
	type = 'application/json'
): Promise<T> {
	const access_token = await getFedExAccessToken();
	const headers: {
		[key: string]: string;
	} = {
		Authorization: `Bearer ${access_token}`
	};

	if (type !== 'multipart/form-data') {
		headers['Content-Type'] = type;
	}

	const options = init ? { ...init, headers } : { headers };
	// add credentials include to options
	const res = await fetch(PRIVATE_FEDEX_API_URL + url, options);
	return await res.json();
}

import { writable } from 'svelte/store';
import { onAuthStateChanged, type User } from 'firebase/auth';
import { auth } from '../firebase/client';
import { browser } from '$app/environment';
import { PUBLIC_ALLOWED_EMAILS } from '$env/static/public';
import { triggerAlert } from './alert';

// Create a writable store to hold the user info
export const user = writable<User | null | 'anonymous'>(null);

// Set up the auth state listener
onAuthStateChanged(auth, (currentUser) => {
	if (!browser) return; // ssr has no context, user effectively unknown
	if (currentUser) {
		// Only allow the users to sign in if they match a pre-approved email list?
		// I would ordinarily just match against @studentagencies.com but that's Microsoft,
		// not Google — people unlikely to be logged in on Gmail.
		if (!currentUser?.email || !PUBLIC_ALLOWED_EMAILS.includes(currentUser.email)) {
			auth.signOut();
			user.set('anonymous');

			triggerAlert(
				"You're not on the list of approved users. Please contact it@studentagencies.com if you believe this is an error.",
				'red',
				10
			);

			return;
		}
		user.set(currentUser);
	} else {
		// User is signed out, reset the user store
		user.set('anonymous');
	}
});

import { writable } from 'svelte/store';
import type { Writable } from 'svelte/store';

// eslint-disable-next-line prefer-const
export let showAlert = writable(false);
export type ToastColorType =
	| 'red'
	| 'green'
	| undefined;

// eslint-disable-next-line prefer-const
export let alertColor = writable<ToastColorType>('green');

// eslint-disable-next-line prefer-const
export let alertMessage = writable('');

let counter: number;

export const watchMeToReloadCharts: Writable<boolean> = writable(false); // for the stopwatch, since not invalidating

/**
 * Triggers an alert message on the bottom right of the screen.
 * @param message The message to display
 * @param color The color of the toast message
 * @param hideCountdown The number of seconds to display the toast message
 * @param delayShowCountdown The number of seconds to wait before displaying the toast message
 */
export function triggerAlert(
	message: string,
	color: ToastColorType = 'green',
	hideCountdown = 5,
	delayShowCountdown = 0
) {
	if (delayShowCountdown > 0) {
		setTimeout(() => {
			triggerAlert(message, color, hideCountdown);
		}, delayShowCountdown * 1000);
		return;
	} else {
		alertMessage.set(message);
		alertColor.set(color ?? 'green');
		counter = hideCountdown;
		showAlert.set(true);
		timeout();
	}
}

export function timeout(): NodeJS.Timeout | void {
	if (--counter > 0) return setTimeout(timeout, 1000);
	else {
		showAlert.set(false);
		return;
	}
}

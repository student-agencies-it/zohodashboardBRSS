<script lang="ts">
	import Button from '$lib/components/ui/button/button.svelte';
	import { triggerAlert } from '$lib/stores/alert';
	import { db } from '$lib/firebase/client';
	import { doc, getDoc, setDoc } from 'firebase/firestore';
	import { dateToYYYYMMDD } from '../trucks/utils';
	import { onMount } from 'svelte';

	let checkingForNew = false;
	let lastCalendarDate = new Date('1970-01-01');
	let initialLoadComplete = false;

	async function updateCalendar(initialLoad = false) {
		checkingForNew = true;
		const lastCalendarDateRef = doc(db, 'lastCalendarDate', 'lastCalendarDate');
		const lastCalendarDateDocSnap = await getDoc(lastCalendarDateRef);
		if (lastCalendarDateDocSnap.exists()) {
			lastCalendarDate = new Date(lastCalendarDateDocSnap.data().timestamp);
		}
		const response = await fetch(
			'/api/calendar/update?lastCalendarDate=' + dateToYYYYMMDD(lastCalendarDate, false),
			{
				method: 'PUT',
				headers: {
					'Content-Type': 'application/json'
				}
			}
		);
		if (!response.ok) {
			triggerAlert('Failed to check for new data. Please try again later.', 'red');
			checkingForNew = false;
			return;
		}
		checkingForNew = false;
		if (
			(
				(await response.json()) as {
					hasNewData: boolean;
				}
			).hasNewData
		) {
			await setDoc(lastCalendarDateRef, { timestamp: new Date().setUTCHours(0, 0, 0, 0) });
			triggerAlert('Calendar updated!');
			if (!initialLoad) {
				setTimeout(() => {
					window.location.reload();
				}, 2000);
			}
		} else {
			await setDoc(lastCalendarDateRef, { timestamp: new Date().setUTCHours(0, 0, 0, 0) });
			triggerAlert('No new data found — calendar is up-to-date.');
		}
	}

	onMount(async () => {
		await updateCalendar(true);
		initialLoadComplete = true;
	});
</script>

<svelte:head>
	<title>Calendar | BRSS Admin Software</title>
	<meta
		name="description"
		content="View upcoming appointments for Big Red Shipping and Storage. Plan ahead, spot new orders, and maintain operational efficiency."
	/>
</svelte:head>

<!-- NOTE: ok not to use pub/sub api, just update manually clicking each day and checking for new ones not in db -->

<!-- See: https://support.google.com/calendar/answer/41207?hl=en -->
<div class="flex flex-col gap-y-2">
	<div class="flex flex-row">
		<div class="flex-grow" />
		<Button
			class="align-end float-right w-48 place-self-end"
			disabled={checkingForNew || !initialLoadComplete}
			on:click={() => updateCalendar(false)}
			><svg
				xmlns="http://www.w3.org/2000/svg"
				fill="none"
				viewBox="0 0 24 24"
				stroke-width="1.5"
				stroke="currentColor"
				class="mr-2 h-4 w-4 {checkingForNew ? 'animate-spin' : ''}"
			>
				<path
					stroke-linecap="round"
					stroke-linejoin="round"
					d="M16.023 9.348h4.992v-.001M2.985 19.644v-4.992m0 0h4.992m-4.993 0 3.181 3.183a8.25 8.25 0 0 0 13.803-3.7M4.031 9.865a8.25 8.25 0 0 1 13.803-3.7l3.181 3.182m0-4.991v4.99"
				/>
			</svg>
			{checkingForNew ? 'Checking' : 'Check'} for New</Button
		>
	</div>
	<iframe
		src="https://calendar.google.com/calendar/embed?height=600&wkst=1&ctz=America%2FNew_York&bgcolor=%23ffffff&mode=WEEK&title=BRSS%20Admin%20Software&showPrint=0&showCalendars=0&src=NmQ1ODllYmY2MjZkNWQxYWM2OTE3MjA2Nzk5ZDYwYTc2OTMzOWVjMjZjYzM0NDkyZGYwN2RlYjEwZmJiYWM5ZUBncm91cC5jYWxlbmRhci5nb29nbGUuY29t&color=%23A79B8E"
		style="border:solid 1px #777"
		width="800"
		height="600"
		frameborder="0"
		scrolling="no"
		title="BRSS Admin Software Remote Google Calendar"
	></iframe>
</div>

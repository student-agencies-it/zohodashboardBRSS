import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import { credentialedFedExFetch } from '$lib/req';
import type { ShipToHomeAppointmentDetails } from '../../../../types/shipping';
import stateAbbreviations from './stateAbbreviations';

import { PRIVATE_FEDEX_ACCOUNT_NUMBER } from '$env/static/private';

export const POST: RequestHandler = async ({ request }) => {
	const { output, tickedAppointments, subIndividualValues, subIndividualWeights } =
		(await request.json()) as {
			output: ShipToHomeAppointmentDetails[];
			tickedAppointments: number[];
			subIndividualValues: { [key: string]: (string | number)[] };
			subIndividualWeights: { [key: string]: (string | number)[] };
		};

	const responses: unknown[] = [];

	for (const appointment of tickedAppointments) {
		const res = await credentialedFedExFetch('/ship/v1/shipments', {
			method: 'POST',
			body: JSON.stringify({
				mergeLabelDocOption: 'LABELS_ONLY',
				requestedShipment: {
					totalDeclaredValue: {
						amount: subIndividualValues[appointment].reduce(
							(acc: number, curr) => acc + (isNaN(Number(curr)) ? 0 : Number(curr)),
							0
						),
						currency: 'USD'
					},
					shipper: {
						address: {
							streetLines: ['409 College Avenue'],
							city: 'Cornell University',
							postalCode: '14853',
							stateOrProvinceCode: 'NY',
							countryCode: 'US'
						},
						contact: {
							personName: 'General Manager',
							phoneNumber: '6072623005',
							companyName: 'Big Red Shipping and Storage'
						}
					},
					recipients: [
						{
							address: {
								streetLines: [output[appointment].customer.address],
								city: output[appointment].customer.city,
								postalCode: output[appointment].customer.zip,
								stateOrProvinceCode: stateAbbreviations.get(output[appointment].customer.state),
								countryCode: 'US'
							},
							contact: {
								personName: output[appointment].customer.name,
								phoneNumber: output[appointment].customer.phone.replace(/\D/g, '')
							}
						}
					],
					pickupType: 'DROPOFF_AT_FEDEX_LOCATION',
					serviceType: 'FEDEX_GROUND',
					packagingType: 'YOUR_PACKAGING',
					totalWeight: subIndividualWeights[appointment].reduce(
						(acc: number, curr) => acc + (isNaN(Number(curr)) ? 0 : Number(curr)),
						0
					),
					shippingChargesPayment: {
						paymentType: 'SENDER'
					},
					labelSpecification: {
						labelFormatType: 'COMMON2D',
						imageType: 'PDF',
						labelStockType: 'PAPER_LETTER'
					},
					requestedPackageLineItems: output[appointment].articles.map((article, i) => {
						return {
							sequenceNumber: i + 1,
							declaredValue: {
								amount: isNaN(Number(subIndividualValues[appointment][i]))
									? 0
									: Number(subIndividualValues[appointment][i]),
								currency: 'USD'
							},
							weight: {
								units: 'LB',
								value: isNaN(Number(subIndividualWeights[appointment][i]))
									? article.billedWeight
									: Number(subIndividualWeights[appointment][i])
							}
						};
					})
				},
				labelResponseOptions: 'LABEL', // sandbox broken for URL_ONLY
				accountNumber: {
					value: PRIVATE_FEDEX_ACCOUNT_NUMBER
				}
			})
		});

		if ((res as { errors: unknown[] }).errors) {
			responses.push({ success: false, errors: (res as { errors: unknown[] }).errors });
		} else {
			responses.push({ success: true, res });
		}
	}

	return json(responses);
};

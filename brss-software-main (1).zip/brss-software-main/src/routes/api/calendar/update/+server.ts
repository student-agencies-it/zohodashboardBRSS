import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import credentialedFetch from '$lib/req';
import { type RawAppointmentResponse } from '../../../../routes/orders/utils';
// import { calendar_v3, google } from 'googleapis';
import jwt from '@tsndr/cloudflare-worker-jwt';
import {
	PRIVATE_GOOGLE_CALENDAR_CALENDAR_ID,
	PRIVATE_GOOGLE_CALENDAR_SERVICE_ACCOUNT_EMAIL,
	PRIVATE_GOOGLE_CALENDAR_SERVICE_ACCOUNT_PRIVATE_KEY
	// PRIVATE_GOOGLE_CALENDAR_SERVICE_ACCOUNT_PRIVATE_KEY_ID
} from '$env/static/private';
import moment from 'moment-timezone';

const recordTimeToHours = {
	'9 AM - 11 AM': 9,
	'11 AM - 1 PM': 11,
	'1 PM - 3 PM': 13,
	'3 PM - 5 PM': 15,
	'5 PM - 7 PM': 17
};

const formattedRecordTimeToHours = {
	'9 AM - 11 AM': '09:00:00',
	'11 AM - 1 PM': '11:00:00',
	'1 PM - 3 PM': '13:00:00',
	'3 PM - 5 PM': '15:00:00',
	'5 PM - 7 PM': '17:00:00'
};

function generateJWTToken() {
	const claimSet = {
		iss: PRIVATE_GOOGLE_CALENDAR_SERVICE_ACCOUNT_EMAIL,
		aud: 'https://oauth2.googleapis.com/token',
		scope:
			'https://www.googleapis.com/auth/calendar https://www.googleapis.com/auth/calendar.events',
		exp: Math.floor(Date.now() / 1000) + 3600,
		iat: Math.floor(Date.now() / 1000)
	};

	// Sign the token
	const token = jwt.sign(
		claimSet,
		PRIVATE_GOOGLE_CALENDAR_SERVICE_ACCOUNT_PRIVATE_KEY.replace(/\\n/g, '\n'),
		{
			algorithm: 'RS256'
		}
	);

	return token;
}

async function getAccessToken(generatedJWTToken: string) {
	const tokenUrl = 'https://oauth2.googleapis.com/token';
	const payload = {
		grant_type: 'urn:ietf:params:oauth:grant-type:jwt-bearer',
		assertion: generatedJWTToken
	};
	const response = await fetch(tokenUrl, {
		method: 'POST',
		headers: {
			// 'Content-Type': 'application/x-www-form-urlencoded',
			Authorization: 'Bearer ' + generatedJWTToken
		},
		body: JSON.stringify(payload)
	});
	const data = await response.json();
	return (data as { access_token: string }).access_token;
}

async function listCalendarEvents(accessToken: string) {
	const listEventsUrl = `https://www.googleapis.com/calendar/v3/calendars/${PRIVATE_GOOGLE_CALENDAR_CALENDAR_ID}/events?singleEvents=true`;
	const response = await fetch(listEventsUrl, {
		headers: {
			Authorization: `Bearer ${accessToken}`
		}
	});
	const output = [];
	let data = (await response.json()) as {
		items: {
			summary: string;
			location: string;
			description: string;
			start: { dateTime: string; timeZone: string };
			end: { dateTime: string; timeZone: string };
			id?: string;
		}[];
		nextPageToken: string | null;
	};
	if (data.items) {
		for (const event of data.items) {
			output.push(event);
		}
	}
	while (data.nextPageToken) {
		const response = await fetch(`${listEventsUrl}&pageToken=${data.nextPageToken}`, {
			headers: {
				Authorization: `Bearer ${accessToken}`
			}
		});
		data = await response.json();
		if (data.items) {
			for (const event of data.items) {
				output.push(event);
			}
		}
	}

	return output;
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
async function deleteCalendarEvents(accessToken: string) {
	const promises = [];
	for (const event of await listCalendarEvents(accessToken)) {
		console.log('Deleting event: ', event);
		promises.push(
			fetch(
				`https://www.googleapis.com/calendar/v3/calendars/${PRIVATE_GOOGLE_CALENDAR_CALENDAR_ID}/events/${event.id}`,
				{
					method: 'DELETE',
					headers: {
						Authorization: `Bearer ${accessToken}`
					}
				}
			)
		);
	}
	await Promise.all(promises);
}

function insertCalendarEvent(
	accessToken: string,
	event: {
		summary: string;
		location: string;
		description: string;
		start: { dateTime: string; timeZone: string };
		end: { dateTime: string; timeZone: string };
	}
) {
	const insertEventUrl = `https://www.googleapis.com/calendar/v3/calendars/${PRIVATE_GOOGLE_CALENDAR_CALENDAR_ID}/events`;
	return fetch(insertEventUrl, {
		method: 'POST',
		headers: {
			Authorization: `Bearer ${accessToken}`,
			'Content-Type': 'application/json'
		},
		body: JSON.stringify(event)
	});
}

function recordToTime(record: RawAppointmentResponse): number {
	const dateHelper = new Date(record.Date__c);
	// @ts-expect-error - TS doesn't know that the key will always be in the object.
	const hours = recordTimeToHours[record.Time__c];
	dateHelper.setHours(hours);
	return dateHelper.getTime();
}

export const PUT: RequestHandler = async ({ url }) => {
	moment.tz.add('America/New_York|EST EDT|50 40|0101|1Lz50 1zb0 Op0');
	let lastCalendarDate = new Date(url.searchParams.get('lastCalendarDate') ?? '1970-01-01');

	if (lastCalendarDate > new Date()) {
		lastCalendarDate = new Date(new Date().setHours(0, 0, 0, 0));
	}

	let daysSinceLastUpdate = Math.floor(
		(new Date().getTime() - lastCalendarDate.getTime()) / (1000 * 60 * 60 * 24)
	);

	daysSinceLastUpdate += 1; // we don't know where the Salesforce servers are

	const res = (await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+CustomerName__c,+Date__c,+Time__c,+Status__c,+PhoneNumber__c,+Type__c,+Order__c,+Building__c,+Address1__c,+Address2__c,+EstimatedNumberOfItems__c,+EstimatedBoxedItems__c,+EstimatedNonBoxedItems__c,+Notes__c,+RoomNumber__c+FROM+Appointment__c+WHERE+Date__c+>=+LAST_N_DAYS:${daysSinceLastUpdate}`
	)) as { records: RawAppointmentResponse[] };

	// Spam or cancelled orders.
	res.records = res.records
		.filter((record) => record.Order__c !== null)
		.filter((record) => record.Status__c !== 'Cancelled');

	// Get rid of records where we have passed that time.
	res.records = res.records.filter((record) => recordToTime(record) >= lastCalendarDate.getTime());

	const jwtToken = await generateJWTToken();
	const accessToken = await getAccessToken(jwtToken);
	const eventsObjects = await listCalendarEvents(accessToken);
	const promises = [];

	// Delete everything from the calendar.
	// await deleteCalendarEvents(accessToken);

	const events = new Set(
		eventsObjects.map(
			(e: {
				summary?: string;
				location?: string;
				description?: string;
				start?: { dateTime: string };
				end?: { dateTime: string };
			}) =>
				(e.summary ?? '') +
				(e.location ?? '') +
				(e.description ?? '') +
				new Date(e.start?.dateTime ?? '').toISOString() +
				new Date(e.end?.dateTime ?? '').toISOString()
		)
	);

	// Add in the new records.
	for (const record of res.records) {
		// @ts-expect-error - TS doesn't know that the key will always be in the object.
		const formattedHours = formattedRecordTimeToHours[record.Time__c];

		const dateHelper = moment
			.tz(record.Date__c + ' ' + formattedHours, 'America/New_York')
			.toDate();

		const event = {
			summary: record.CustomerName__c,
			location: `${record.Building__c ? record.Building__c + (record.Address1__c ? ', ' : '') : ''}${record.Address1__c ? record.Address1__c + (record.Address2__c ? ', ' : '') : ''}${record.Address2__c ? record.Address2__c : ''}`,
			description:
				(record.Notes__c ?? '') +
				(record.EstimatedNumberOfItems__c ?? 'Unknown') +
				' estimated # of items, ' +
				record.EstimatedBoxedItems__c +
				' estimated boxed items, ' +
				record.EstimatedNonBoxedItems__c +
				' estimated non-boxed items. ',
			start: {
				dateTime: dateHelper.toISOString(),
				timeZone: 'America/New_York'
			},
			end: {
				dateTime: new Date(dateHelper.getTime() + 2 * 60 * 60 * 1000).toISOString(),
				timeZone: 'America/New_York'
			}
		};

		if (
			events.has(
				event.summary +
					event.location +
					event.description +
					event.start.dateTime +
					event.end.dateTime
			)
		) {
			// console.log('Skipping duplicate event: ', event.summary);
			continue;
		} else {
			// console.log('Actually setting: ', event.summary);
			// continue;
		}

		promises.push(
			insertCalendarEvent(accessToken, event)
				.then(() => {
					console.log('Inserted event: ', event);
				})
				.catch((e) => {
					console.error('Failed to insert event: ', event, e);
				})
		);
	}

	await Promise.all(promises);

	return json({
		hasNewData: true // no storage tracking mechanism atm
	});
};

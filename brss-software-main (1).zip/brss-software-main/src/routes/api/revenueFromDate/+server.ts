import { json } from '@sveltejs/kit';
import type { RequestHandler } from './$types';
import credentialedFetch from '$lib/req';
import { dateToYYYYMMDD } from '../../trucks/utils';

export const GET: RequestHandler = async ({ url }) => {
	const startDate = new Date(url.searchParams.get('startDate') ?? '');
	const endDate = new Date(url.searchParams.get('endDate') ?? '');
	const requestedType = url.searchParams.get('type') ?? 'customRange';

	const fetchPayments = async (start: Date, end: Date) => {
		// Handle offsets for start and end dates. (timezone offsets)
		const startString = dateToYYYYMMDD(start);
		const endString = dateToYYYYMMDD(end);
		start = new Date(startString);
		end = new Date(endString);

		// Dark magic to set the end date to the last second of the day.
		end.setHours(23, 59, 59, 999);
		end.setTime(end.getTime() - end.getTimezoneOffset() * 60000);
		end.setTime(end.getTime() + 24 * 60 * 60 * 1000);

		const query = `SELECT Amount__c, AmountDescription__c, Refund_Amount__c FROM Payment__c WHERE CreatedDate >= ${start.toISOString()} AND CreatedDate <= ${end.toISOString()} AND Amount__c > 1`;
		const res = await credentialedFetch<{ records: { Amount__c: string; AmountDescription__c: string; Refund_Amount__c: string | null; }[]; }>(
			`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=${encodeURIComponent(query)}`
		);

		return res.records;
	};

	const calculateAmount = (payments: { AmountDescription__c: string; Refund_Amount__c: string | null; }[]) => {
		return payments.reduce((acc, payment) => {
			const subtotalMatch = payment.AmountDescription__c.match(/Subtotal =\s*\$?([\d.]+)/);
			const subtotal = subtotalMatch ? parseFloat(subtotalMatch[1]) : 0;
			const refund = parseFloat(payment.Refund_Amount__c ?? '0');
			return acc + subtotal - refund;
		}, 0);
	};

	let amount = 0;
	let payments;

	switch (requestedType) {
		case 'customRange':
			payments = await fetchPayments(startDate, endDate);
			amount = calculateAmount(payments);
			return json({ customRangeAmount: amount, ytdAmount: -1, lastMonthAmount: -1, last30DaysAmount: -1, last7DaysAmount: -1 });

		case 'ytd': {
			const ytdStart = new Date(new Date().getFullYear(), 0, 1);
			payments = await fetchPayments(ytdStart, new Date());
			amount = calculateAmount(payments);
			return json({ customRangeAmount: -1, ytdAmount: amount, lastMonthAmount: -1, last30DaysAmount: -1, last7DaysAmount: -1 });
		}

		case 'lastMonth': {
			const lastMonthStart = new Date(new Date().getFullYear(), new Date().getMonth() - 1, 1);
			const lastMonthEnd = new Date(new Date().getFullYear(), new Date().getMonth(), 0);
			payments = await fetchPayments(lastMonthStart, lastMonthEnd);
			amount = calculateAmount(payments);
			return json({ customRangeAmount: -1, ytdAmount: -1, lastMonthAmount: amount, last30DaysAmount: -1, last7DaysAmount: -1 });
		}

		case 'last30Days': {
			const last30DaysStart = new Date(new Date().setDate(new Date().getDate() - 30));
			payments = await fetchPayments(last30DaysStart, new Date());
			amount = calculateAmount(payments);
			return json({ customRangeAmount: -1, ytdAmount: -1, lastMonthAmount: -1, last30DaysAmount: amount, last7DaysAmount: -1 });
		}

		default: { // last7Days
			const last7DaysStart = new Date(new Date().setDate(new Date().getDate() - 7));
			payments = await fetchPayments(last7DaysStart, new Date());
			amount = calculateAmount(payments);
			return json({ customRangeAmount: -1, ytdAmount: -1, lastMonthAmount: -1, last30DaysAmount: -1, last7DaysAmount: amount });
		}
	}
};

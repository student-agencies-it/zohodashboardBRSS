<script lang="ts">
	import * as Tabs from '$lib/components/ui/tabs/index.js';
	import * as Tooltip from '$lib/components/ui/tooltip/index.js';
	import * as Collapsible from '$lib/components/ui/collapsible';
	import { Button, buttonVariants } from '$lib/components/ui/button/index.js';
	import * as Dialog from '$lib/components/ui/dialog/index.js';
	import { Textarea } from '$lib/components/ui/textarea/index.js';

	import CalendarIcon from 'svelte-radix/Calendar.svelte';
	import Pencil1 from 'svelte-radix/Pencil1.svelte';
	import CheckCircled from 'svelte-radix/CheckCircled.svelte';
	import ExclamationTriangle from 'svelte-radix/ExclamationTriangle.svelte';
	import {
		DateFormatter,
		type DateValue,
		getLocalTimeZone,
		today,
		CalendarDate
	} from '@internationalized/date';
	import { cn } from '$lib/utils.js';
	import { Calendar } from '$lib/components/ui/calendar/index.js';
	import * as Popover from '$lib/components/ui/popover/index.js';
	import * as Table from '$lib/components/ui/table/index.js';
	import * as AlertDialog from '$lib/components/ui/alert-dialog/index.js';
	import * as Select from '$lib/components/ui/select';
	import { triggerAlert } from '$lib/stores/alert';

	import { Label } from '$lib/components/ui/label/index.js';
	import { Switch } from '$lib/components/ui/switch/index.js';

	import type { PageData } from './$types';
	import { page } from '$app/stores';
	import { invalidateAll } from '$app/navigation';

	import { dateToYYYYMMDD, isValidDateString } from './utils';

	import { db } from '$lib/firebase/client';
	import { collection, doc, getDoc, setDoc, deleteField, deleteDoc } from 'firebase/firestore';
	import type { FirebaseOrder } from '../../types/firebaseOrder';
	import type { DocumentData, DocumentSnapshot } from 'firebase/firestore';

	import type { Appointment } from '../../types/appointment';
	import jsPDF from 'jspdf';
	import autoTable from 'jspdf-autotable';

	import { Badge } from '$lib/components/ui/badge/index.js';

	import algorithm, {
		scoreGenericOutputMap,
		getGenericOutputMapProfit
	} from '$lib/algorithm/algorithm';

	import type { PossibleTime } from '../../types/possibleTime';
	import type { Worker } from '../../types/worker';

	import { onMount } from 'svelte';

	export let data: PageData;

	let peakMode = false;

	const df = new DateFormatter('en-US', {
		dateStyle: 'long'
	});

	let value: DateValue | undefined = today(getLocalTimeZone());

	const deliveryTimeTo24HrEnding = new Map([
		['9 AM - 11 AM', 11],
		['11 AM - 1 PM', 13],
		['1 PM - 3 PM', 15],
		['3 PM - 5 PM', 17],
		['5 PM - 7 PM', 19]
	]);

	// Check if there is already a date in the params.
	if ($page.url.searchParams.has('date')) {
		const date = $page.url.searchParams.get('date') as string;
		if (!isValidDateString(date)) {
			value = undefined;
		} else {
			// parse yyyy, mm, dd
			const [yyyy, mm, dd] = date.split('-').map(Number);
			value = new CalendarDate(yyyy, mm, dd);
		}
	}

	let trucks: string[] = [
		'High Roof',
		'BR Van',
		'Truck 1',
		'Truck 2',
		'Truck 3',
		'Truck 4',
		'Truck 5',
		'Truck 6',
		'Truck 7',
		'Truck 8',
		'Truck 9',
		'Truck 10'
	];

	let unassignedAndTrucks = ['Unassigned', ...trucks];

	let generatingRoutes = false;

	let forcedAssignmentValue: {
		value: string;
		label: string;
		disabled: boolean;
	} = {
		value: 'Unassigned',
		label: 'Unassigned',
		disabled: false
	};

	/**
	 * Sets the forcible truck assignment for a given order number.
	 * @param orderNumber The order number of the order to update.
	 * @param newValue The new forcible truck assignment. If null, the forcible assignment is removed.
	 */
	async function setForcedAssignment(orderNumber: string) {
		const docRef = doc(db, 'orders', orderNumber);

		if (!forcedAssignmentValue || forcedAssignmentValue.value === 'Unassigned') {
			await setDoc(docRef, { forcibleTruckAssignment: deleteField() }, { merge: true });
		} else {
			await setDoc(
				docRef,
				{ forcibleTruckAssignment: forcedAssignmentValue.value },
				{ merge: true }
			);
		}

		// Update UI
		for (let appointments of Object.values(appointmentsOrderedByTime)) {
			appointments = appointments.map((x) => {
				if (x.orderNumber === orderNumber) {
					x.truckAssignment = forcedAssignmentValue.value;
				}
				return x;
			});
		}
		appointmentsOrderedByTime = appointmentsOrderedByTime;
	}

	let outputScore: number | null = null;
	let outputProfit: number | null = null;
	let allowedDrivers: string[] = [];
	let allowedDriversText: string = '';

	onMount(async () => {
		// Get the date from the URL
		const date = $page.url.searchParams.get('date') ?? dateToYYYYMMDD(new Date());
		// Try to read in the score for that date
		const docRef = doc(db, 'routeScores', date);
		const docSnap = await getDoc(docRef);
		if (docSnap.exists()) {
			outputScore = docSnap.data().score ?? null;
			outputProfit = docSnap.data().profit ?? null;
		}

		const allowedDriversDocRef = doc(db, 'allowedDrivers', 'allowedDrivers');
		const allowedDriversDocSnap = await getDoc(allowedDriversDocRef);
		if (allowedDriversDocSnap.exists()) {
			try {
				allowedDrivers = (allowedDriversDocSnap.data().drivers.sort() as string[]).map(
					(name: string) => name.split(' ')[0] + ' ' + name.split(' ')[1][0] + '.'
				);
				allowedDriversText = allowedDriversDocSnap.data().drivers.sort().join('\n');
			} catch (e) {
				console.warn(e);
				allowedDrivers = [];
				allowedDriversText = '';
			}
		}
	});

	async function calculateRoutes() {
		// NOTE: see the Confluence document for information on how the algorithm might work.
		// NOTE: we also want to 'order' the results in the sense that the trucks know in which
		// order to perform their visitations; that's what orderInTruckAssignment is for.
		generatingRoutes = true;
		let [currentOutput, solved] = algorithm(appointmentsOrderedByTime, peakMode);
		let bestOutput: typeof currentOutput | null = null;

		// Use a timeout so we have time to render the spinny.
		setTimeout(async () => {
			for (const i in Array.from({ length: 200 })) {
				if (currentOutput.size === 0) {
					// Failed to find anything.
					continue;
				} else {
					if (
						solved &&
						scoreGenericOutputMap(currentOutput) <
							(bestOutput ? scoreGenericOutputMap(bestOutput) : 999_999_999_999)
					) {
						bestOutput = currentOutput;
					}
				}
				[currentOutput, solved] = algorithm(appointmentsOrderedByTime, peakMode);
			}

			if (!bestOutput || bestOutput.size === 0) {
				// Either it is an empty day or (legacy) it did not return a solution.
				generatingRoutes = false;
				if (!bestOutput) {
					triggerAlert(
						"Algorithm can't fully solve problem. Please try later, unset peak mode, adjust variables, and/or contact it@studentagencies.com.",
						'red',
						15
					);
				}
				return;
			} else {
				outputScore = scoreGenericOutputMap(bestOutput);
				outputProfit = getGenericOutputMapProfit(bestOutput);
				// Store the output in firestore for that day.
				// Just storing the outputScore and outputProfit.
				const date = $page.url.searchParams.get('date') ?? dateToYYYYMMDD(new Date());
				const docRef = doc(db, 'routeScores', date);
				await setDoc(docRef, { score: outputScore, profit: outputProfit }, { merge: true });
			}

			const numberToTruckMapping = new Map<string, string>();
			const numberToIDMapping = new Map<string, number>();
			// We want to make this faster — marginally parallelize the await stuff
			const promises = []; // Initialize an array to hold all promises
			for (const [truck, value] of bestOutput) {
				for (const timeAssignments of value.timeMap.values()) {
					let i = 0;
					for (const appointment of timeAssignments[1]) {
						const docRef = doc(db, 'orders', appointment[0].orderNumber);
						numberToTruckMapping.set(appointment[0].orderNumber, truck);
						numberToIDMapping.set(appointment[0].orderNumber, i);
						// Push the promise into the array instead of awaiting it
						promises.push(
							setDoc(
								docRef,
								{
									truckAssignment: truck,
									orderInTruckAssignment: i,
									forcibleTruckAssignment: deleteField() // clear forced assignments
								},
								{ merge: true }
							)
						);
						i++;
					}
				}
			}
			// Perform all of the operations.
			await Promise.all(promises);

			for (let appointments of Object.values(appointmentsOrderedByTime)) {
				appointments = appointments.map((x) => {
					x.truckAssignment = numberToTruckMapping.get(x.orderNumber) ?? undefined;
					x.orderInTruckAssignment = numberToIDMapping.get(x.orderNumber) ?? undefined;
					return x;
				});
			}
			appointmentsOrderedByTime = appointmentsOrderedByTime;
			generatingRoutes = false;

			// We also need to update the UI for the workers.
			// Don't want to make it so that it is impossible to unset a worker, and assignments will have changed anyway.
			// Delete the document for that date in the workerTruckAssignments collection.
			let date = $page.url.searchParams.get('date');
			if (!date) {
				date = dateToYYYYMMDD(new Date()) ?? null;
			}

			const deletePromises = trucks.concat('Unassigned').map(async (truck) => {
				const docRef = doc(db, 'workerTruckAssignments', date, 'trucks', truck);
				await deleteDoc(docRef);
			});

			await Promise.all(deletePromises);

			let newMap: Map<PossibleTime, Worker[]> = new Map();

			// Also update the workers object.
			for (let time of Array.from(data.workers.keys()) as PossibleTime[]) {
				newMap.set(
					time,
					data.workers.get(time)?.map((worker) => {
						worker.assigned = false;
						worker.assignedTo = null;
						return worker;
					}) ?? []
				);
			}

			// Reactivity.
			data.workers = newMap;

			triggerAlert('Routes calculated and set.', 'green');
		}, 500);
	}

	async function toggleWorkerTruckTimeAssignment(
		worker: Worker,
		truck: string,
		time: PossibleTime,
		isDriver = false
	) {
		if (worker.assigned && worker.assignedTo !== truck) {
			// Essentially not allowed.
			return;
		}

		worker.assigned = !worker.assigned;
		worker.assignedTo = worker.assigned ? truck : null;
		worker.assignedAsDriver = isDriver;
		// reactivity
		data.workers = data.workers;
		// Update firestore — update the array for the current date and time.
		// The document in workerTruckAssignments with the current date (from page url)
		// Should have the corresponding time field updated to contain the new array of workers
		// that have assigned = true.
		let date = $page.url.searchParams.get('date');
		if (!date) {
			date = dateToYYYYMMDD(new Date()) ?? null;
		}

		// Get the collection reference
		const docRef = doc(db, 'workerTruckAssignments', date, 'trucks', truck);

		// Get the document
		const docSnap = await getDoc(docRef);
		if (!docSnap.exists()) {
			// Create the new document with all the corresponding fields for all the possible times.
			const newDoc = {
				'9 AM - 11 AM': [],
				'11 AM - 1 PM': [],
				'1 PM - 3 PM': [],
				'3 PM - 5 PM': [],
				'5 PM - 7 PM': []
			} as Record<PossibleTime, { name: string; driver: boolean }[]>;
			for (let w of data.workers) {
				newDoc[w[0]] = w[1]
					.filter((worker) => worker.assigned)
					.filter((worker) => worker.assignedTo === truck)
					.map((worker) => ({ name: worker.name, driver: worker.assignedAsDriver }));
			}

			await setDoc(docRef, newDoc);
		} else {
			// Update the document
			const fbData = docSnap.data();
			fbData[time] = data.workers
				.get(time)
				?.filter((worker: Worker) => worker.assigned)
				?.filter((worker: Worker) => worker.assignedTo === truck)
				.map((worker: Worker) => ({ name: worker.name, driver: worker.assignedAsDriver }));
			await setDoc(docRef, fbData);
		}
	}

	/**
	 * Helper function that returns a type-safe array of appointments.
	 * @param appointments - The Record of appointments.
	 */
	const entrified = (
		appointments: Record<PossibleTime, (Appointment & FirebaseOrder)[]>
	): [PossibleTime, (Appointment & FirebaseOrder)[]][] => {
		if (!appointments) {
			return [];
		}
		return Object.entries(appointments) as [PossibleTime, (Appointment & FirebaseOrder)[]][];
	};

	const calculateStatus = (app: Appointment): 'pending' | 'fulfilled' | 'fulfilledLate' | null => {
		if (!app.totalAmount) {
			// Unfulfilled — either unfulfilled late or in the future.
			// This is all we need to do — frontend handles diff.
			return 'pending';
		} else {
			// Fulfilled — either fulfilled late or fulfilled on time.
			// To do this, we need to check the payment time.
			// NOTE: since supplies are pre-paid, it will not be accurate for supplies.
			// NOTE: it appears that if you ship home it does not get paid for immediately?
			// NOTE: this will only appear as expected if you are geographically located in
			// Ithaca's timezone.
			const dateified = new Date(app.paymentTimestamp ?? '');
			if (
				dateified >= new Date(app.deliveryDate ?? '') && // supplies are paid for in advance
				dateified.getHours() > (deliveryTimeTo24HrEnding.get(app.deliveryTime) ?? 0)
			) {
				return 'fulfilledLate';
			} else {
				return 'fulfilled';
			}
		}
	};

	/**
	 * Downloads a PDF of the routes for the day.
	 */
	function download() {
		const doc = new jsPDF();

		const pageHeight = doc.internal.pageSize.height || doc.internal.pageSize.getHeight();
		const margin = 20; // Define a margin for the page
		let y = margin; // Start at the top margin

		// Add in the date as a header.
		doc.setFontSize(24);
		doc.setFont('helvetica', 'italic');
		doc.text(`Routes for ${df.format(value?.toDate(getLocalTimeZone()) ?? new Date())}`, 14, y);
		// underline text — add in a line
		doc.line(14, y + 2, 200, y + 2);
		y += 14; // Move down a bit

		let triedToAddFirstPageFlag = false;

		for (let truck of unassignedAndTrucks) {
			const obj = filtered(truck, entrified(appointmentsOrderedByTime));

			if (obj.length === 0) {
				continue;
			}

			// We always want to start a new page for a new truck.
			if (!triedToAddFirstPageFlag) {
				triedToAddFirstPageFlag = true;
			} else {
				doc.addPage();
				y = margin; // Reset y to the top margin
			}

			doc.setFontSize(22);
			doc.setFont('helvetica', 'bold');
			doc.text(truck, 14, y);

			y += 12; // Move down a bit

			for (const [time, apps] of obj) {
				doc.setFontSize(16);
				doc.setFont('helvetica', 'bold');
				doc.text(time, 14, y);

				// Check if the next element will exceed the page height
				if (y + 15 > pageHeight) {
					doc.addPage();
					y = margin; // Reset y to the top margin
				}

				y += 10;

				doc.setFontSize(12);
				doc.setFont('helvetica', 'bold');
				doc.text('Drivers:', 14, y);
				doc.setFont('helvetica', 'normal');
				doc.text(
					data.workers
						.get(time)
						?.filter((worker) => worker.assigned)
						?.filter((worker) => worker.assignedTo === truck)
						?.filter((worker) => worker.assignedAsDriver)
						.map((worker) => worker.name)
						.join(', ') ?? '',
					45,
					y
				);

				// Check if the next element will exceed the page height
				if (y + 15 > pageHeight) {
					doc.addPage();
					y = margin; // Reset y to the top margin
				}

				y += 10;

				doc.setFontSize(12);
				doc.setFont('helvetica', 'bold');
				doc.text('Field Reps:', 14, y);
				doc.setFont('helvetica', 'normal');
				doc.text(
					data.workers
						.get(time)
						?.filter((worker) => worker.assigned)
						?.filter((worker) => worker.assignedTo === truck)
						?.filter((worker) => !worker.assignedAsDriver)
						.map((worker) => worker.name)
						.join(', ') ?? '',
					45,
					y
				);

				// Check if the next element will exceed the page height
				if (y + 15 > pageHeight) {
					doc.addPage();
					y = margin; // Reset y to the top margin
				}

				autoTable(doc, {
					startY: y + 5,
					head: [
						['ID', 'Customer', 'Phone #', 'Type', 'Location', 'Items', 'Room', 'Notes', 'Delivery']
					],
					body: apps.map((app) => [
						app.orderNumber,
						app.customer,
						app.phone,
						app.type,
						app.location ?? '',
						app.estimatedItems ?? '',
						app.room ?? '',
						app.notes ?? '',
						app.items ?? ''
					])
				});

				y =
					(
						doc as typeof doc & {
							autoTable: {
								previous: {
									finalY: number;
								};
							};
						}
					).autoTable.previous.finalY + 12; // Update y to the position after the table

				// Check if the next element will exceed the page height
				if (y + 15 > pageHeight) {
					doc.addPage();
					y = margin; // Reset y to the top margin
				}
			}
		}

		// You know what, just download for printing.
		doc.save(`routes-${$page.url.searchParams.get('date')}.pdf`);
	}

	// NOTE: order status is automatically inferred from payment boolean and timestamp.

	/**
	 * Reroutes the user to the trucks page with the selected date.
	 */
	async function reroute() {
		if (value) {
			const date = dateToYYYYMMDD(value.toDate(getLocalTimeZone()), false);
			if (date) {
				// add ?date=xxxx to the URL
				window.location.href = `/trucks?date=${date}`;
				await invalidateAll();
				// await goto(`/trucks?data=${date}`);
				// let res = await getOrderedAppointments();
				// appointmentsOrderedByTime = Object.fromEntries(res);
			}
		}
	}

	/**
	 * Convert a time from 12-hour to a 24-hour number. Used for checking lateness.
	 * @param time The time to convert.
	 */
	function convertTo24HrNumber(time: string) {
		const [hoursStr, period] = time.split(' ');
		const hours = parseInt(hoursStr);

		if (period === 'PM' && hours !== 12) {
			return hours + 12;
		} else if (period === 'AM' && hours === 12) {
			return 0;
		} else {
			return hours;
		}
	}

	/**
	 * Checks to see if a date is < today. i.e yesterday, day before yesterday, etc. — just checking the date.
	 *
	 * @param date The date to check.
	 */
	function dateIsInPast(date: string) {
		const [yyyy, mm, dd] = date.split('-').map(Number);
		const deliveryDate = new Date(yyyy, mm - 1, dd);
		deliveryDate.setHours(23, 59, 59, 999);
		const today = new Date();
		return deliveryDate < today;
	}

	/**
	 * Checks to see if a date is > today, i.e. tomorrow, day after tomorrow, etc. — just checking the date.
	 *
	 * @param date The date to check.
	 */
	function dateIsInFuture(date: string) {
		const [yyyy, mm, dd] = date.split('-').map(Number);
		const deliveryDate = new Date(yyyy, mm - 1, dd);
		deliveryDate.setHours(0, 0, 0, 0);
		const today = new Date();
		return deliveryDate > today;
	}

	/**
	 * Update workers to set assigned = true if a worker is in the map (i.e. still active on Homebase)
	 * and also marked as assigned in the firestore for the current date.
	 */
	async function findWorkerTruckAssignments() {
		let date = $page.url.searchParams.get('date');
		if (!date) {
			date = dateToYYYYMMDD(new Date()) ?? null;
		}

		const promises = trucks.concat('Unassigned').map(async (truck) => {
			// Get the document reference
			const docRef = doc(db, 'workerTruckAssignments', date, 'trucks', truck);

			// Get the document
			const docSnap = await getDoc(docRef);
			if (docSnap.exists()) {
				const fbData = docSnap.data();
				for (let time of Object.keys(fbData) as PossibleTime[]) {
					const workersAssigned = fbData[time];
					for (let worker of workersAssigned as { name: string; driver: boolean }[]) {
						const workerObj = data.workers.get(time)?.find((w: Worker) => w.name === worker.name);
						if (workerObj) {
							// as they may have since toggled away their availability on Homebase
							workerObj.assigned = true;
							workerObj.assignedTo = truck;
							workerObj.assignedAsDriver = worker.driver;
						}
					}
				}
			}
		});

		await Promise.all(promises);
	}

	/**
	 * Gets all appointments from Firestore and orders them by time.
	 */
	const getOrderedAppointments = async () => {
		// Read in from firebase collection to assign remaining values to everything
		// in appointmentsGroupedByTime.
		const orderNumbers = data.appointments.map((appointment) => appointment.orderNumber);

		// Create a collection reference
		const ordersRef = collection(db, 'orders');

		// Create an empty array to hold all promises
		const promises: Promise<DocumentSnapshot<DocumentData>>[] = [];

		// Loop through all keys and create a promise for each document read operation
		orderNumbers.forEach((key) => {
			promises.push(getDoc(doc(ordersRef, key)));
		});

		const snapshots = await Promise.all(promises);

		const properlyFormattedAppointments: (Appointment & FirebaseOrder)[] = [];

		// Now, snapshots is an array of DocumentSnapshot
		// You can loop through it to get the data of each document
		snapshots.forEach((snapshot) => {
			const matchingAppointment = data.appointments.find(
				(appointment) => appointment.orderNumber === snapshot.id
			) as Appointment;
			if (snapshot.exists()) {
				properlyFormattedAppointments.push({
					...matchingAppointment,
					orderNumber: snapshot.id,
					truckAssignment: snapshot.data().truckAssignment,
					forcibleTruckAssignment: snapshot.data().forcibleTruckAssignment
				});
			} else {
				properlyFormattedAppointments.push({
					...matchingAppointment,
					orderNumber: snapshot.id
				});
			}
		});

		const appointmentsGroupedByTime: Record<string, (Appointment & FirebaseOrder)[]> =
			properlyFormattedAppointments.reduce(
				(
					acc: Record<string, (Appointment & FirebaseOrder)[]>,
					appointment: Appointment & FirebaseOrder
				) => {
					const time = appointment.deliveryTime;
					if (!acc[time]) {
						acc[time] = [];
					}
					acc[time].push(appointment);
					return acc;
				},
				{}
			);

		/**
		 * Convert a time from 12-hour to 24-hour format. Used for internal ordering.
		 * @param time The time to convert.
		 */
		function convertTo24Hr(time: string) {
			const [hoursStr, period] = time.split(' ');
			const hours = parseInt(hoursStr);

			if (period === 'PM' && hours !== 12) {
				return `${hours + 12}`;
			} else if (period === 'AM' && hours === 12) {
				return `00`;
			} else if (hours >= 10) {
				return `${hours}`;
			} else {
				return `0${hours}`;
			}
		}

		const appointmentsOrderedByTime = entrified(appointmentsGroupedByTime);

		appointmentsOrderedByTime.sort((a, b) => {
			let valueOne = a[1][0]['deliveryTime'];
			let valueTwo = b[1][0]['deliveryTime'];

			valueOne = convertTo24Hr(valueOne.split(' - ')[0]);
			valueTwo = convertTo24Hr(valueTwo.split(' - ')[0]);

			return valueOne < valueTwo ? -1 : valueOne > valueTwo ? 1 : 0;
		});

		await findWorkerTruckAssignments();

		return appointmentsOrderedByTime;
	};

	let appointmentsOrderedByTime: Record<string, (Appointment & FirebaseOrder)[]> = {};
	getOrderedAppointments().then((result) => {
		appointmentsOrderedByTime = Object.fromEntries(result);
	});

	function filtered(
		truck: string,
		appointments: [PossibleTime, (Appointment & FirebaseOrder)[]][]
	) {
		const output = appointments.filter(([_, apps]) => {
			return apps.some((appointment) => {
				if (truck === 'Unassigned') {
					return !appointment.truckAssignment && !appointment.forcibleTruckAssignment;
				} else {
					return (
						appointment.forcibleTruckAssignment === truck || appointment.truckAssignment === truck
					);
				}
			});
		});

		// Filter out individual appointments in the appointments for some string key that are not for the truck.
		// If the truck is 'Unassigned', then we want to show all appointments that are not assigned to a truck.
		const appointmentsFilteredByTruck: [PossibleTime, (Appointment & FirebaseOrder)[]][] = [];

		for (const [time, subAppts] of output) {
			const filteredAppointments = subAppts.filter((app) => {
				if (truck === 'Unassigned') {
					return !app.truckAssignment && !app.forcibleTruckAssignment;
				} else {
					return (
						app.forcibleTruckAssignment === truck ||
						(!app.forcibleTruckAssignment && app.truckAssignment === truck)
					);
				}
			});
			if (filteredAppointments.length > 0) {
				appointmentsFilteredByTruck.push([time, filteredAppointments]);
			}

			// Now we want to filter filteredAppointments according to orderInTruckAssignment
			filteredAppointments.sort((a, b) => {
				if (a.orderInTruckAssignment === undefined && b.orderInTruckAssignment === undefined) {
					return 0;
				} else if (a.orderInTruckAssignment === undefined) {
					return 1;
				} else if (b.orderInTruckAssignment === undefined) {
					return -1;
				} else {
					return a.orderInTruckAssignment - b.orderInTruckAssignment;
				}
			});
		}

		return appointmentsFilteredByTruck;
	}

	let dialogOpen = false;
	async function updateAllowedDrivers() {
		try {
			allowedDrivers = allowedDriversText
				.split('\n')
				.map((name: string) => name.split(' ')[0] + ' ' + name.split(' ')[1][0] + '.');
		} catch (e) {
			alert(
				'Error parsing allowed drivers. Please check the input format, should be Firstname Lastname.'
			);
			return;
		}
		const allowedDriversRef = doc(db, 'allowedDrivers', 'allowedDrivers');
		await setDoc(allowedDriversRef, { drivers: allowedDriversText.split('\n') });
		dialogOpen = false;
	}
</script>

<svelte:head>
	<title>Trucks | BRSS Admin Software</title>
	<meta
		name="description"
		content="View upcoming deliveries for Big Red Shipping and Storage by truck. Manually reassign or simply trust the algorithm."
	/>
</svelte:head>

<div class="w-full">
	<!-- date picker -->
	<div class="mb-2 items-center lg:flex">
		<Popover.Root>
			<Popover.Trigger asChild let:builder>
				<Button
					variant="outline"
					class={cn(
						'w-[240px] justify-start text-left font-normal',
						!value && 'text-muted-foreground'
					)}
					builders={[builder]}
				>
					<CalendarIcon class="mr-2 h-4 w-4" />
					{value ? df.format(value.toDate(getLocalTimeZone())) : 'Pick a date'}
				</Button>
			</Popover.Trigger>
			<Popover.Content class="w-full p-0 lg:w-auto" align="end">
				<Calendar class="w-full" bind:value />
			</Popover.Content>
			<Button
				class="my-2 ml-0 mr-0 block w-60 lg:my-0 lg:ml-4 lg:mr-4 lg:inline lg:w-auto"
				variant="outline"
				on:click={reroute}>Go!</Button
			>
			<p class="mr-2 text-sm">
				Route (Profit – Score): <span class="font-semibold"
					>{#if outputProfit}
						~${outputProfit
							.toFixed(2)
							.toString()
							.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
					{:else}{null}{/if}</span
				>–
				<span class="font-semibold">{outputScore !== null ? outputScore.toFixed(2) : null}</span>
			</p>
			<!-- Hoverable score explanation -->
			<Tooltip.Root openDelay={100}>
				<Tooltip.Trigger
					><svg
						xmlns="http://www.w3.org/2000/svg"
						viewBox="0 0 16 16"
						fill="currentColor"
						class="-ml-1 h-4 w-4 text-gray-700"
					>
						<path
							fill-rule="evenodd"
							d="M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0Zm-6 3.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0ZM7.293 5.293a1 1 0 1 1 .99 1.667c-.459.134-1.033.566-1.033 1.29v.25a.75.75 0 1 0 1.5 0v-.115a2.5 2.5 0 1 0-2.518-4.153.75.75 0 1 0 1.061 1.06Z"
							clip-rule="evenodd"
						/>
					</svg>
				</Tooltip.Trigger>
				<Tooltip.Content class="prose w-1/4">
					<p>
						Profit is a naive approximation of revenue (fixed) - costs (rent truck + labor costs for
						2-hour periods) for the day.
					</p>
					<p>
						Score is an objective measure of how 'good' the generated routes are, as a function of
						how idle trucks are. <span class="font-semibold">Lower is better.</span>
					</p>
				</Tooltip.Content>
			</Tooltip.Root>
		</Popover.Root>
		<div class="ml-auto mr-0 flex flex-row gap-x-2">
			<div class="mr-4 flex items-center space-x-2">
				<Label for="peak-mode">Peak Mode</Label>
				<!-- Hoverable peak mode explanation -->
				<Tooltip.Root openDelay={100}>
					<Tooltip.Trigger
						><svg
							xmlns="http://www.w3.org/2000/svg"
							viewBox="0 0 16 16"
							fill="currentColor"
							class="-ml-1 h-4 w-4 text-gray-700"
						>
							<path
								fill-rule="evenodd"
								d="M15 8A7 7 0 1 1 1 8a7 7 0 0 1 14 0Zm-6 3.5a1 1 0 1 1-2 0 1 1 0 0 1 2 0ZM7.293 5.293a1 1 0 1 1 .99 1.667c-.459.134-1.033.566-1.033 1.29v.25a.75.75 0 1 0 1.5 0v-.115a2.5 2.5 0 1 0-2.518-4.153.75.75 0 1 0 1.061 1.06Z"
								clip-rule="evenodd"
							/>
						</svg>
					</Tooltip.Trigger>
					<Tooltip.Content class="prose">
						<p>
							In general, Peak Mode should be turned on for the 2nd/3rd week of May. It modifies the
							algorithm in the following ways:
						</p>
						<ul>
							<li>max of 7 pickup appointments per day for High Roof</li>
							<li>0.75x travel / fitness multiplier for size-one orders for High Roof</li>
							<li>no reuse of High Roof (can only be filled up once)</li>
							<li>BR Van just awaits manual forced assignment</li>
						</ul></Tooltip.Content
					>
				</Tooltip.Root>
				<Switch id="peak-mode" bind:checked={peakMode} />
			</div>
			<Button class="hidden md:block" variant="secondary" on:click={download}>Download</Button>
			<Button variant="default" class="w-24" disabled={generatingRoutes} on:click={calculateRoutes}>
				{#if generatingRoutes}
					<div class="lds-ring">
						<div></div>
						<div></div>
						<div></div>
						<div></div>
					</div>
				{:else}
					Routeify{/if}</Button
			>
		</div>
	</div>

	<!-- tabs -->
	<Tabs.Root value="Unassigned">
		<Tabs.List
			class="mb-80 flex flex-col justify-normal bg-gray-50 md:mb-0 md:block md:flex-grow md:!justify-center"
		>
			{#each unassignedAndTrucks as truck}
				<Tabs.Trigger class="relative w-full bg-gray-50 md:w-auto md:bg-transparent" value={truck}
					>{truck}</Tabs.Trigger
				>
			{/each}
		</Tabs.List>
		{#each unassignedAndTrucks as truck}
			<Tabs.Content value={truck}>
				{#if filtered(truck, entrified(appointmentsOrderedByTime)).length === 0}
					<div class="text-center text-gray-500">No appointments for {truck} on this day.</div>
				{/if}
				<div class="flex flex-col gap-y-4">
					{#each filtered(truck, entrified(appointmentsOrderedByTime)) as [time, appointments]}
						<div class="flex items-center gap-x-4 rounded-xl border px-2 py-4">
							<Table.Root class="w-full">
								<Table.Header>
									<Table.Row>
										<Table.Head class="w-24">ID</Table.Head>
										<Table.Head>Customer</Table.Head>
										<Table.Head class="w-20">Phone #</Table.Head>
										<Table.Head>Type</Table.Head>
										<Table.Head>Location</Table.Head>
										<Table.Head>Items</Table.Head>
										<Table.Head>Room</Table.Head>
										<Table.Head class="w-28">Notes</Table.Head>
										<Table.Head>Delivery</Table.Head>
										<Table.Head class="text-center">Status</Table.Head>
										<Table.Head>Forced?</Table.Head>
									</Table.Row>
								</Table.Header>
								<Table.Body>
									{#each appointments as appointment, i (i)}
										{@const status = calculateStatus(appointment)}
										<Table.Row>
											<Table.Cell class="font-medium">{appointment.orderNumber}</Table.Cell>
											<Table.Cell>{appointment.customer}</Table.Cell>
											<Table.Cell>{appointment.phone}</Table.Cell>
											<Table.Cell>{appointment.type}</Table.Cell>
											<Table.Cell>{appointment.location}</Table.Cell>
											<Table.Cell>{appointment.estimatedItems ?? ''}</Table.Cell>
											<Table.Cell>{appointment.room ?? ''}</Table.Cell>
											<Table.Cell
												><p class="w-28 break-words">{appointment.notes ?? ''}</p></Table.Cell
											>
											<Table.Cell>{appointment.items ?? ''}</Table.Cell>
											<Table.Cell class="mx-auto items-center justify-center">
												<!-- NOTE: there are four statuses:
													- fulfilled on time
													- fulfilled late
													- unfulfilled (on time)
													- unfulfilled (late)
												-->
												{#if appointment.type === 'Supplies'}<p class="mx-auto text-center text-xl">
														🤷
													</p>{:else if status === 'fulfilled'}
													<!-- fulfilled on time -->
													<Button variant="ghost" class="cursor-not-allowed">
														<CheckCircled class="mx-auto text-green-500" />
													</Button>
												{:else if status === 'fulfilledLate'}
													<!-- fulfilled late -->
													<Button variant="ghost" class="cursor-not-allowed">
														<ExclamationTriangle class="mx-auto text-yellow-500" />
													</Button>
												{:else if status === 'pending' || !status}
													{#if !dateIsInFuture(appointment.deliveryDate) && (dateIsInPast(appointment.deliveryDate) || new Date().getHours() >= convertTo24HrNumber(appointment.deliveryTime.split(' - ')[1]))}
														<Button variant="ghost" class="cursor-not-allowed">
															<!-- unfulfilled late -->
															<ExclamationTriangle class="mx-auto text-red-500" />
														</Button>
													{:else}
														<Button variant="ghost" class="cursor-not-allowed">
															<CheckCircled class="mx-auto text-gray-500 hover:text-gray-700" />
														</Button>
													{/if}
												{/if}
											</Table.Cell>
											<Table.Cell class="mx-auto items-center">
												<div class="flex flex-row items-center justify-center">
													{#if appointment.forcibleTruckAssignment && appointment.forcibleTruckAssignment !== 'Unassigned'}
														<span class="font-medium text-yellow-500">Y</span>
													{:else}
														<span class="font-medium">N</span>
													{/if}
													<AlertDialog.Root>
														<AlertDialog.Trigger>
															<Button variant="ghost" size="icon" class="ml-0.5 !px-2">
																<Pencil1 size="18" />
															</Button>
														</AlertDialog.Trigger>
														<AlertDialog.Content class="sm:max-w-[425px]">
															<AlertDialog.Header>
																<AlertDialog.Title>Forcibly Reassign</AlertDialog.Title>
																<AlertDialog.Description class="!mt-6">
																	Override the truck assignment{' '}{#if appointment.forcibleTruckAssignment}
																		of {appointment.forcibleTruckAssignment}{:else if appointment.truckAssignment}of
																		{appointment.truckAssignment}{/if} for this appointment.
																</AlertDialog.Description>
															</AlertDialog.Header>
															<div class="grid gap-4 pb-4">
																<div class="grid grid-cols-4 items-center gap-4">
																	<Label for="forcedAssignment" class="text-right">New Truck</Label>
																	<Select.Root bind:selected={forcedAssignmentValue}>
																		<Select.Trigger class="w-[180px]">
																			<Select.Value placeholder={appointment.truckAssignment} />
																		</Select.Trigger>
																		<Select.Content class="h-full overflow-y-scroll">
																			<Select.Label>Algorithmic</Select.Label>
																			<Select.Item value="Unassigned">Unassigned</Select.Item>
																			<Select.Label>Manual</Select.Label>
																			{#each trucks as truck}
																				<Select.Item value={truck}>{truck}</Select.Item>
																			{/each}
																		</Select.Content>
																	</Select.Root>
																</div>
															</div>
															<AlertDialog.Footer>
																<AlertDialog.Cancel type="submit">Cancel</AlertDialog.Cancel>
																<AlertDialog.Action
																	on:click={async () => {
																		await setForcedAssignment(appointment.orderNumber);
																		appointment.forcibleTruckAssignment =
																			forcedAssignmentValue?.value === 'Unassigned'
																				? undefined
																				: forcedAssignmentValue?.value;
																	}}
																	type="submit">Save</AlertDialog.Action
																>
															</AlertDialog.Footer>
														</AlertDialog.Content>
													</AlertDialog.Root>
												</div>
											</Table.Cell>
										</Table.Row>
									{/each}
								</Table.Body>
							</Table.Root>
							<div class="mx-auto w-32 border-l-2 p-2 text-center text-sm font-medium">
								{time}
							</div>
							<div class="mx-auto -ml-4 flex w-48 flex-col gap-y-4">
								<Collapsible.Root class="text-sm font-medium">
									<Collapsible.Trigger class="mx-auto flex items-center text-center"
										>Assign Drivers<svg
											xmlns="http://www.w3.org/2000/svg"
											viewBox="0 0 20 20"
											fill="currentColor"
											class="ml-1 h-5 w-5"
										>
											<path
												fill-rule="evenodd"
												d="M2.24 6.8a.75.75 0 0 0 1.06-.04l1.95-2.1v8.59a.75.75 0 0 0 1.5 0V4.66l1.95 2.1a.75.75 0 1 0 1.1-1.02l-3.25-3.5a.75.75 0 0 0-1.1 0L2.2 5.74a.75.75 0 0 0 .04 1.06Zm8 6.4a.75.75 0 0 0-.04 1.06l3.25 3.5a.75.75 0 0 0 1.1 0l3.25-3.5a.75.75 0 1 0-1.1-1.02l-1.95 2.1V6.75a.75.75 0 0 0-1.5 0v8.59l-1.95-2.1a.75.75 0 0 0-1.06-.04Z"
												clip-rule="evenodd"
											/>
										</svg>
									</Collapsible.Trigger>
									<Collapsible.Content>
										<div
											class="grid grid-flow-row gap-x-1 gap-y-2 p-2 text-center font-medium lg:grid-cols-2"
										>
											{#each (data.workers.get(time) ?? [])
												.filter((w) => w.role === 'BRSS Driver')
												.sort((a, b) => a.name.localeCompare(b.name)) as worker}
												{@const formattedWorkerName =
													worker.name + (worker.scheduled ? ' (S)' : '')}
												<button
													on:click={async () => {
														if (!allowedDrivers.includes(worker.name)) {
															return;
														}
														await toggleWorkerTruckTimeAssignment(worker, truck, time, true);
													}}
												>
													{#if !allowedDrivers.includes(worker.name)}
														<div class="w-full">
															<Tooltip.Root openDelay={50}>
																<Tooltip.Trigger class="!px-0">
																	<Badge
																		variant="secondary"
																		class="h-10 w-full cursor-not-allowed !px-0"
																		>{formattedWorkerName}</Badge
																	>
																</Tooltip.Trigger>
																<Tooltip.Content class="prose">
																	<p>{worker.name} is not allowed to drive.</p>
																</Tooltip.Content>
															</Tooltip.Root>
														</div>
													{:else if !worker.assigned}
														<!-- available, not assigned -->
														<Badge variant="outline" class="h-10 w-full cursor-pointer"
															>{formattedWorkerName}</Badge
														>
													{:else if worker.assignedTo === truck && worker.assignedAsDriver}
														<!-- assigned to this truck for this role! -->
														<Badge class="h-10 w-full cursor-pointer">{formattedWorkerName}</Badge>
													{:else}
														<Badge variant="destructive" class="h-10 w-full cursor-not-allowed"
															>{formattedWorkerName}</Badge
														>
													{/if}
												</button>
											{/each}
										</div>
									</Collapsible.Content>
								</Collapsible.Root>
								<Dialog.Root bind:open={dialogOpen}>
									<Dialog.Trigger
										class={buttonVariants({ variant: 'outline' })}
										on:click={() => (dialogOpen = true)}>Edit Allowed Drivers</Dialog.Trigger
									>
									<Dialog.Content class="sm:max-w-[425px]">
										<Dialog.Header>
											<Dialog.Title>Edit Allowed Drivers</Dialog.Title>
											<Dialog.Description class="!mt-4">
												<p>
													Update the list of allowed drivers. Please match names or nicknames <span
														class="font-semibold">exactly</span
													> with what is shown on Homebase.
												</p>
												<p class="mt-2">Names should be newline-separated.</p>
											</Dialog.Description>
										</Dialog.Header>
										<Textarea
											bind:value={allowedDriversText}
											placeholder="Enter names here..."
											rows={10}
											class="w-full"
										></Textarea>
										<Dialog.Footer>
											<Button type="submit" on:click={updateAllowedDrivers}>Save changes</Button>
										</Dialog.Footer>
									</Dialog.Content>
								</Dialog.Root>
								<Collapsible.Root class="text-sm font-medium">
									<Collapsible.Trigger class="mx-auto flex items-center text-center"
										>Assign Workers <svg
											xmlns="http://www.w3.org/2000/svg"
											viewBox="0 0 20 20"
											fill="currentColor"
											class="ml-1 h-5 w-5"
										>
											<path
												fill-rule="evenodd"
												d="M2.24 6.8a.75.75 0 0 0 1.06-.04l1.95-2.1v8.59a.75.75 0 0 0 1.5 0V4.66l1.95 2.1a.75.75 0 1 0 1.1-1.02l-3.25-3.5a.75.75 0 0 0-1.1 0L2.2 5.74a.75.75 0 0 0 .04 1.06Zm8 6.4a.75.75 0 0 0-.04 1.06l3.25 3.5a.75.75 0 0 0 1.1 0l3.25-3.5a.75.75 0 1 0-1.1-1.02l-1.95 2.1V6.75a.75.75 0 0 0-1.5 0v8.59l-1.95-2.1a.75.75 0 0 0-1.06-.04Z"
												clip-rule="evenodd"
											/>
										</svg>
									</Collapsible.Trigger>
									<Collapsible.Content>
										<div
											class="grid grid-flow-row gap-x-1 gap-y-2 p-2 text-center font-medium lg:grid-cols-2"
										>
											{#each (data.workers.get(time) ?? []).sort( (a, b) => a.name.localeCompare(b.name) ) as worker}
												{@const formattedWorkerName =
													worker.name + (worker.scheduled ? ' (S)' : '')}
												<button
													on:click={async () =>
														await toggleWorkerTruckTimeAssignment(worker, truck, time)}
												>
													{#if !worker.assigned}
														<!-- available, not assigned -->
														<Badge variant="secondary" class="h-10 w-full cursor-pointer"
															>{formattedWorkerName}</Badge
														>
													{:else if worker.assignedTo === truck && !worker.assignedAsDriver}
														<!-- assigned to this truck for this role! -->
														<Badge class="h-10 w-full cursor-pointer">{formattedWorkerName}</Badge>
													{:else}
														<Badge variant="destructive" class="h-10 w-full cursor-not-allowed"
															>{formattedWorkerName}</Badge
														>
													{/if}
												</button>
											{/each}
										</div>
									</Collapsible.Content>
								</Collapsible.Root>
							</div>
						</div>
					{/each}
				</div>
			</Tabs.Content>
		{/each}
	</Tabs.Root>
</div>

<style>
	.lds-ring,
	.lds-ring div {
		box-sizing: border-box;
	}
	.lds-ring {
		display: inline-block;
		position: relative;
		width: 20px;
		height: 20px;
	}
	.lds-ring div {
		box-sizing: border-box;
		display: block;
		position: absolute;
		width: 16px;
		height: 16px;
		margin: 2px;
		border: 2px solid currentColor;
		border-radius: 50%;
		animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
		border-color: currentColor transparent transparent transparent;
	}
	.lds-ring div:nth-child(1) {
		animation-delay: -0.45s;
	}
	.lds-ring div:nth-child(2) {
		animation-delay: -0.3s;
	}
	.lds-ring div:nth-child(3) {
		animation-delay: -0.15s;
	}
	@keyframes lds-ring {
		0% {
			transform: rotate(0deg);
		}
		100% {
			transform: rotate(360deg);
		}
	}
</style>

import type { PossibleTime } from '../../types/possibleTime';

export function isValidDateString(str: string): boolean {
	return /^\d{4}-\d{2}-\d{2}$/.test(str);
}

/**
 * Converts a date object to a string in the format of YYYY-MM-DD
 * @param date a valid date object to be passed in
 * @returns a string in the format of YYYY-MM-DD
 */
export function dateToYYYYMMDD(date: Date, handleOffset = true) {
	const offset = date.getTimezoneOffset();
	if (handleOffset) {
		date = new Date(date.getTime() - offset * 60 * 1000);
	}
	return date.toISOString().split('T')[0];
}

export type HomebaseSchedule = {
	id: number;
	timecard_id: null | number;
	open: boolean;
	role: string;
	department: string;
	first_name: string;
	last_name: string;
	job_id: number;
	user_id: number;
	wage_rate: number;
	published: boolean;
	scheduled: boolean;
	labor: {
		wage_type: string;
		scheduled_hours: number;
		scheduled_overtime: number;
		scheduled_regular: number;
		scheduled_daily_overtime: number;
		scheduled_weekly_overtime: number;
		scheduled_double_overtimes: number;
		scheduled_seventh_day_overtime_15: number;
		scheduled_seventh_day_overtime_20: number;
		scheduled_unpaid_breaks_hours: number;
		scheduled_costs: number;
		scheduled_overtime_costs: number;
		scheduled_spread_of_hours: number;
		scheduled_blue_laws_hours: number;
	};
	created_at: string;
	updated_at: string;
	start_at: string | null; // could be badly inputted
	end_at: string | null; // could be badly inputted
};

/**
 * Converts a time string to a 24-hour format.
 *
 * @param time e.g. '9 AM'
 * @returns e.g. '09:00:00' — iso representation
 */
const convertTo24Hour = (time: string): string => {
	const [hours, AMorPM] = time.split(' ');
	const hoursNum = parseInt(hours, 10);
	const hr =
		AMorPM === 'AM'
			? hoursNum === 12
				? '00'
				: hours.padStart(2, '0')
			: (hoursNum + 12).toString();
	return `${hr}:00:00`;
};

/**
 * Returns whether `workerKeyRange` is wholly contained in `isoRange`.
 * @param workerKeyRange e.g. '9 AM - 11 AM'
 * @param isoRange e.g. 09:00:00 - 17:00:00
 */
export function checkIfFullOverlap(workerKeyRange: PossibleTime, isoRange: string): boolean {
	const [start, end] = isoRange.split(' - ');
	let [workerStart, workerEnd] = workerKeyRange.split(' - ');

	workerStart = convertTo24Hour(workerStart);
	workerEnd = convertTo24Hour(workerEnd);

	return workerStart >= start && workerEnd <= end;
}

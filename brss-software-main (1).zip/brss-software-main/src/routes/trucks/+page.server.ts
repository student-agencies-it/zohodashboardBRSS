import credentialedFetch, { credentialedHomebaseFetch } from '$lib/req';
import {
	massageRecords,
	type RawAppointmentResponse,
	type RawOrderItemResponse
} from '../orders/utils';
import {
	dateToYYYYMMDD,
	isValidDateString,
	type HomebaseSchedule,
	checkIfFullOverlap
} from './utils';
import type { PossibleTime } from '../../types/possibleTime';
import type { Worker } from '../../types/worker';
import { PRIVATE_HOMEBASE_LOCATION_UUID } from '$env/static/private';

/**
 * Fetches the appointments from Salesforce and returns them to the client-side under `appointments`.
 * @returns the appointments from Salesforce
 */
export async function load({ url }) {
	// It is possible that we are already given a date. Check for the date param. Otherwise set to today.
	const date =
		url.searchParams.get('date') && isValidDateString(url.searchParams.get('date') ?? '')
			? dateToYYYYMMDD(new Date(url.searchParams.get('date') ?? ''), false)
			: dateToYYYYMMDD(new Date());

	const resWrapper = await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+CustomerName__c,+Date__c,+Time__c,+Status__c,+PhoneNumber__c,+Type__c,+Order__c,+Building__c,+Address1__c,+Address2__c,+EstimatedNumberOfItems__c,+EstimatedBoxedItems__c,+EstimatedNonBoxedItems__c,+Notes__c,+RoomNumber__c+FROM+Appointment__c+WHERE+Date__c+=+${date}`
	);

	const workersResWrapper = await credentialedHomebaseFetch(
		`https://app.joinhomebase.com/api/public/locations/${PRIVATE_HOMEBASE_LOCATION_UUID}/shifts?page=1&per_page=1000&start_date=${date}&end_date=${date}&open=false&with_note=false&date_filter=start_at`
	);

	const mappingResWrapper = await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Id,+OrderNumber,+Status,+TotalAmount+FROM+Order+WHERE+Id+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+=+${date})`
	);

	const orderItemsResWrapper = await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Product2Id,+Quantity,+OrderId+FROM+OrderItem+WHERE+OrderId+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+=+${date})`
	);

	const paymentMappingResWrapper = await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Order__c,+CreatedDate+FROM+Payment__c+WHERE+Order__c+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+=+${date})`
	);

	// Speed up through parallelization of non-dependent or first-order functions.
	// eslint-disable-next-line prefer-const
	let [res, workersRes, mappingRes, orderItemsRes, paymentMappingRes] = (await Promise.all([
		resWrapper,
		workersResWrapper,
		mappingResWrapper,
		orderItemsResWrapper,
		paymentMappingResWrapper
	])) as [
		{ records: RawAppointmentResponse[] },
		HomebaseSchedule[],
		{
			records: { Id: string; Status: string; OrderNumber: string; TotalAmount: string | number }[];
		},
		{ records: { Product2Id: string; Quantity: number; OrderId: string }[] },
		{ records: { Order__c: string; CreatedDate: string }[] }
	];

	res.records = res.records.filter((r) => r.Order__c !== null);

	const mapping = mappingRes.records.reduce(
		(acc, { Id, Status, OrderNumber, TotalAmount }) => {
			acc[Id] = {
				Status,
				OrderNumber,
				TotalAmount: isNaN(parseFloat(TotalAmount as string))
					? 0
					: parseFloat(TotalAmount as string)
						? parseFloat(TotalAmount as string)
						: 0
			};
			return acc;
		},
		{} as Record<
			string,
			{
				Status: string;
				OrderNumber: string;
				TotalAmount: number;
			}
		>
	);

	paymentMappingRes.records.map((record) => ({
		Order__c: record.Order__c,
		CreatedDate: record.CreatedDate
	}));

	const paymentMapping = paymentMappingRes.records.reduce(
		(acc, { Order__c, CreatedDate }) => {
			acc[Order__c] = CreatedDate;
			return acc;
		},
		{} as Record<string, string>
	);

	// Move this block before using orderItems
	const chunks = chunkArray(orderItemsRes.records, 250);

	const productRes = await Promise.all(
		chunks.map(async (chunk) => {
			return (await credentialedFetch(
				`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Id,+Name+FROM+Product2+WHERE+Id+IN+(${chunk.map((record) => `'${record.Product2Id}'`).join(',')})`
			)) as { records: { Id: string; Name: string }[] };
		})
	).then((res) => {
		return {
			records: res.flatMap((r) => r.records)
		};
	});

	// Create orderItems before using it
	const orderItems = orderItemsRes.records.map((record) => ({
		...record,
		Name: productRes.records.find((product) => product.Id === record.Product2Id)?.Name
	})) as RawOrderItemResponse[];

	// Now update res — map order ID to OrderNumber and update estimated items
	res.records.forEach((record) => {
		record.OrderNumber = mapping[record.Order__c].OrderNumber;
		record.TotalAmount = mapping[record.Order__c].TotalAmount;
		record.Status__c =
			mapping[record.Order__c].Status === 'Cancelled' ? 'Cancelled' : record.Status__c;
		record.PaymentDate = paymentMapping[record.Order__c]; // can be undefined

		// Get order items for this appointment
		const orderItemsForAppointment = orderItems.filter(item => item.OrderId === record.Order__c);

		// Count 'Big Red Box' and other items
		const bigRedBoxCount = orderItemsForAppointment.reduce((sum, item) =>
			item.Name === 'Big Red Box' ? sum + item.Quantity : sum, 0);
		const otherItemsCount = orderItemsForAppointment.reduce((sum, item) =>
			!['Big Red Box', 'Fee', 'Door to Door', 'Service', 'Supplies'].some(excludedItem => new RegExp(excludedItem, 'i').test(item.Name ?? '')) ? sum + item.Quantity : sum, 0);

		// Update EstimatedBoxedItems__c if it's zero or null
		if (!record.EstimatedBoxedItems__c || record.EstimatedBoxedItems__c === '0') {
			record.EstimatedBoxedItems__c = bigRedBoxCount.toString();
		}

		// Update EstimatedNonBoxedItems__c if it's zero or null
		if (!record.EstimatedNonBoxedItems__c || record.EstimatedNonBoxedItems__c === '0') {
			record.EstimatedNonBoxedItems__c = otherItemsCount.toString();
		}
	});

	// We need to chunk this because otherwise the request can get too large.
	function chunkArray<T>(array: T[], chunkSize: number): T[][] {
		const chunks = [];
		for (let i = 0; i < array.length; i += chunkSize) {
			chunks.push(array.slice(i, i + chunkSize));
		}
		return chunks;
	}

	// NOTE: the firestore will still only have available workers, we dynamically match it
	// (aka no storing of *availability* of workers in firestore as that is subject to change)
	const workers = new Map<PossibleTime, Worker[]>([
		['9 AM - 11 AM', []],
		['11 AM - 1 PM', []],
		['1 PM - 3 PM', []],
		['3 PM - 5 PM', []],
		['5 PM - 7 PM', []]
	]);

	workersRes = workersRes
		.filter((worker) => worker.department === 'BRSS')
		.filter((worker) => worker.start_at && worker.end_at)
		.filter((worker) => worker.role !== 'BRSS Warehouse');

	// Now we assign to workers using the start_at and end_at parameters of a HomebaseSchedule which looks like
	//     start_at: '2024-05-15T09:00:00-04:00',
	// end_at: '2024-05-15T15:00:00-04:00'
	// (we ignore any offset)

	workersRes.forEach((worker) => {
		const start = worker.start_at?.split('T')[1].split('-')[0];
		const end = worker.end_at?.split('T')[1].split('-')[0];
		const time = `${start} - ${end}`;

		// time might now look like e.g. 09:00:00 - 17:00:00 or 09:00:00 - 13:00:00
		for (const [key] of workers) {
			if (checkIfFullOverlap(key, time)) {
				workers.get(key)?.push({
					name: worker.first_name + ' ' + worker.last_name.slice(0, 1) + '.',
					scheduled: worker.scheduled,
					assigned: false,
					assignedTo: null,
					role: worker.role,
					assignedAsDriver: false
				});
			}
		}
	});

	return {
		appointments: massageRecords(res.records, orderItems),
		workers
	};
}

<script lang="ts">
	import * as Card from '$lib/components/ui/card/index';
	import CalendarIcon from 'svelte-radix/Calendar.svelte';
	import {
		CalendarDate,
		DateFormatter,
		type DateValue,
		getLocalTimeZone
	} from '@internationalized/date';
	import { cn } from '$lib/utils.js';
	import { Button } from '$lib/components/ui/button/index.js';
	import { Badge } from '$lib/components/ui/badge/index.js';
	import { RangeCalendar } from '$lib/components/ui/range-calendar/index.js';
	import * as Popover from '$lib/components/ui/popover/index.js';
	import type { PageData } from './$types';
	import { page } from '$app/stores';
	import { isValidDateString, dateToYYYYMMDD } from './trucks/utils';
	import { invalidateAll } from '$app/navigation';
	import { onMount } from 'svelte';

	export let data: PageData;

	const df = new DateFormatter('en-US', {
		dateStyle: 'medium'
	});

	let end = new CalendarDate(
		new Date().getFullYear(),
		new Date().getMonth() + 1,
		new Date().getDate()
	);
	let start = end.subtract({ days: 21 });

	// Check if there are already dates in the params.
	if ($page.url.searchParams.has('startDate') || $page.url.searchParams.has('endDate')) {
		const startDate = $page.url.searchParams.get('startDate') as string;
		if (isValidDateString(startDate)) {
			// parse yyyy, mm, dd
			const [yyyy, mm, dd] = startDate.split('-').map(Number);
			start = new CalendarDate(yyyy, mm, dd);
		}

		const endDate = $page.url.searchParams.get('endDate') as string;
		if (isValidDateString(endDate)) {
			// parse yyyy, mm, dd
			const [yyyy, mm, dd] = endDate.split('-').map(Number);
			end = new CalendarDate(yyyy, mm, dd);
		}
	}

	let value = {
		start,
		end
	};

	let copyValue = { ...value };

	let startValue: DateValue | undefined = undefined;

	/**
	 * Reroutes the user to the dashboard page with the selected date range.
	 */
	async function applyRange() {
		if (value) {
			const startDate = dateToYYYYMMDD(copyValue.start.toDate(getLocalTimeZone()), false);
			const endDate = dateToYYYYMMDD(copyValue.end.toDate(getLocalTimeZone()), false);

			if (startDate && endDate) {
				window.location.href = `/?startDate=${startDate}&endDate=${endDate}`;
				await invalidateAll();
			}
		}
	}

	async function fetchStripeData() {
		const types = ['customRange', 'ytd', 'lastMonth', 'last30Days', 'last7Days'];
		const promises = types.map((t) =>
			fetch(
				`/api/revenueFromDate?startDate=${dateToYYYYMMDD(start.toDate(getLocalTimeZone()), false)}&endDate=${dateToYYYYMMDD(end.toDate(getLocalTimeZone()), false)}&type=${t}`
			)
				.then((response) => response.json() as Promise<Record<string, number>>)
				.then((d: Record<string, number>) => {
					// Process the data immediately after the promise resolves
					for (const key in d) {
						if (d[key] !== -1) {
							// @ts-ignore
							data[key] = d[key];
						}
					}
					return data; // Return data for further processing if needed
				})
				.catch((error) => {
					// Handle any errors from the fetch operation
					console.error(`Error fetching data for ${t}:`, error);
				})
		);

		// Wait for all promises to complete
		await Promise.all(promises);
		// All data has been processed at this point
	}

	onMount(() => fetchStripeData());
</script>

<svelte:head>
	<title>Dashboard | BRSS Admin Software</title>
	<meta
		name="description"
		content="View statistics about revenue and orders for Big Red Shipping and Storage."
	/>
</svelte:head>

<div class="flex flex-col gap-y-4">
	<div
		class="mb-2 flex flex-col items-center gap-y-2 border-b pb-6 md:flex-row md:gap-x-2 md:gap-y-0"
	>
		<p>
			Dashboard for <span class="font-semibold"
				>{new Date().toLocaleDateString('en-us', {
					weekday: 'long',
					year: 'numeric',
					month: 'long',
					day: 'numeric'
				})}</span
			>.
		</p>
		<div class="flex-1" />
		<div class="grid gap-2">
			<Popover.Root openFocus>
				<Popover.Trigger asChild let:builder>
					<Button
						variant="outline"
						class={cn(
							'w-[300px] justify-start text-left font-normal',
							!value && 'text-muted-foreground'
						)}
						builders={[builder]}
					>
						<CalendarIcon class="mr-2 h-4 w-4" />
						{#if value && value.start}
							{#if value.end}
								{df.format(value.start.toDate(getLocalTimeZone()))} - {df.format(
									value.end.toDate(getLocalTimeZone())
								)}
							{:else}
								{df.format(value.start.toDate(getLocalTimeZone()))}
							{/if}
						{:else if startValue}
							{df.format(startValue.toDate(getLocalTimeZone()))}
						{:else}
							Pick a date
						{/if}
					</Button>
				</Popover.Trigger>
				<Popover.Content class="w-auto p-0" align="start">
					<RangeCalendar
						bind:value={copyValue}
						bind:startValue
						placeholder={value?.start}
						initialFocus
						numberOfMonths={2}
					/>
				</Popover.Content>
			</Popover.Root>
		</div>
		<Button on:click={applyRange}>Apply</Button>
	</div>

	<div class="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
		<Card.Root>
			<Card.Header class="flex flex-row items-center justify-between space-y-0 pb-2">
				<Card.Title class="text-sm font-medium">Revenue YTD</Card.Title>
			</Card.Header>
			<Card.Content class="text-lg font-bold">
				{#if data.ytdAmount >= 0}
					${data.ytdAmount
						.toFixed(2)
						.toString()
						.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
				{:else}
					<div class="lds-ring">
						<div></div>
						<div></div>
						<div></div>
						<div></div>
					</div>
				{/if}
			</Card.Content>
		</Card.Root>
		<Card.Root>
			<Card.Header class="flex flex-row items-center justify-between space-y-0 pb-2">
				<Card.Title class="text-sm font-medium">Revenue Last Month</Card.Title>
			</Card.Header>
			<Card.Content class="text-lg font-bold">
				{#if data.lastMonthAmount >= 0}
					${data.lastMonthAmount
						.toFixed(2)
						.toString()
						.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
				{:else}
					<div class="lds-ring">
						<div></div>
						<div></div>
						<div></div>
						<div></div>
					</div>
				{/if}
			</Card.Content>
		</Card.Root>
		<Card.Root>
			<Card.Header class="flex flex-row items-center justify-between space-y-0 pb-2">
				<Card.Title class="text-sm font-medium">Revenue Last 30 Days</Card.Title>
			</Card.Header>
			<Card.Content class="text-lg font-bold">
				{#if data.last30DaysAmount >= 0}
					${data.last30DaysAmount
						.toFixed(2)
						.toString()
						.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
				{:else}
					<div class="lds-ring">
						<div></div>
						<div></div>
						<div></div>
						<div></div>
					</div>
				{/if}
			</Card.Content>
		</Card.Root>
		<Card.Root>
			<Card.Header class="flex flex-row items-center justify-between space-y-0 pb-2">
				<Card.Title class="text-sm font-medium">Revenue Last 7 Days</Card.Title>
			</Card.Header>
			<Card.Content class="text-lg font-bold">
				{#if data.last7DaysAmount >= 0}
					${data.last7DaysAmount
						.toFixed(2)
						.toString()
						.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
				{:else}
					<div class="lds-ring">
						<div></div>
						<div></div>
						<div></div>
						<div></div>
					</div>
				{/if}
			</Card.Content>
		</Card.Root>
	</div>

	<div class="grid gap-4 md:grid-cols-2">
		<Card.Root>
			<Card.Header class="flex flex-row items-center justify-between space-y-0 pb-2">
				<Card.Title class="text-sm font-medium"># of Appointments for Next 7 Days</Card.Title>
			</Card.Header>
			<Card.Content>
				<div class="text-2xl font-bold">{data.next7DayOrderCount}</div>
			</Card.Content>
		</Card.Root>
		<Card.Root>
			<Card.Header class="flex flex-row items-center justify-between space-y-0 pb-2">
				<Card.Title class="text-sm font-medium">Custom Range Revenue</Card.Title>
			</Card.Header>
			<Card.Content>
				<div class="text-2xl font-bold">
					{#if data.customRangeAmount >= 0}
						${data.customRangeAmount
							.toFixed(2)
							.toString()
							.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
					{:else}
						<div class="lds-ring">
							<div></div>
							<div></div>
							<div></div>
							<div></div>
						</div>
					{/if}
				</div>
			</Card.Content>
		</Card.Root>
	</div>
	<div class="grid gap-4 md:grid-cols-2">
		<Card.Root>
			<Card.Header class="flex flex-row items-center justify-between space-y-0 pb-2">
				<Card.Title class="text-sm font-medium">Workers Available Today</Card.Title>
			</Card.Header>
			<Card.Content class="mt-1 flex flex-wrap gap-2">
				{#each data.workers as worker}
					<Badge variant="outline">{worker}</Badge>
				{/each}
				{#if data.workers.length === 0}
					<p class="text-sm text-muted-foreground">
						No workers set availability in Homebase today.
					</p>
				{/if}
			</Card.Content>
		</Card.Root>
		<Card.Root
			><Card.Header class="flex flex-row items-center justify-between space-y-0 pb-2">
				<Card.Title class="text-sm font-medium">BRSS Labor Costs Today</Card.Title>
			</Card.Header>
			<Card.Content>
				<div class="text-2xl font-bold">
					${data.todayBRSSLaborCosts
						.toFixed(2)
						.toString()
						.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
				</div>
			</Card.Content></Card.Root
		>
	</div>
</div>

<style lang="postcss">
	.lds-ring {
		display: inline-block;
		position: relative;
		width: 30px;
		height: 30px;
	}
	.lds-ring div {
		box-sizing: border-box;
		display: block;
		position: absolute;
		width: 34px;
		height: 34px;
		margin: 4px;
		border: 4px solid #666;
		border-radius: 50%;
		animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
		border-color: #666 transparent transparent transparent;
	}
	.lds-ring div:nth-child(1) {
		animation-delay: -0.45s;
	}
	.lds-ring div:nth-child(2) {
		animation-delay: -0.3s;
	}
	.lds-ring div:nth-child(3) {
		animation-delay: -0.15s;
	}
	@keyframes lds-ring {
		0% {
			transform: rotate(0deg);
		}
		100% {
			transform: rotate(360deg);
		}
	}
</style>

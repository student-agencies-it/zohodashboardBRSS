import credentialedFetch, { credentialedHomebaseFetch } from '$lib/req';
import { dateToYYYYMMDD, isValidDateString, type HomebaseSchedule } from './trucks/utils';
import { PRIVATE_HOMEBASE_LOCATION_UUID } from '$env/static/private';

export async function load({ url }) {
	const endDate =
		url.searchParams.get('endDate') && isValidDateString(url.searchParams.get('endDate') ?? '')
			? new Date(url.searchParams.get('endDate') ?? '')
			: new Date(); // Use current date and time

	endDate.setHours(23, 59, 59, 999);

	const todayDate = dateToYYYYMMDD(new Date());
	const workers = Array.from(
		new Set((
			(await credentialedHomebaseFetch(
				`https://app.joinhomebase.com/api/public/locations/${PRIVATE_HOMEBASE_LOCATION_UUID}/shifts?page=1&per_page=1000&start_date=${todayDate}&end_date=${todayDate}&open=false&with_note=false&date_filter=start_at`
			)) as HomebaseSchedule[])
			.filter((worker) => worker.department === 'BRSS')
			.map((worker) => worker.first_name + ' ' + worker.last_name)
		)
	);


	const todayBRSSLaborCosts = (
		(await credentialedHomebaseFetch(
			`https://app.joinhomebase.com/api/public/locations/${PRIVATE_HOMEBASE_LOCATION_UUID}/labor/by_role?start_date=${todayDate}&end_date=${todayDate}`
		)) as { role_name: string; labor: { costs: number; }; }[]
	)
		.filter((x) => x.role_name.includes('BRSS'))
		.map((x) => x.labor.costs)
		.reduce((acc, curr) => acc + curr, 0);

	// Get info about # of orders for the next seven days + today.
	const next7DayOrderCount = (
		(await credentialedFetch(
			"https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Id,+Status,+OrderNumber+FROM+Order+WHERE+Id+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+>=+LAST_N_DAYS:0+AND+Date__c+<=NEXT_N_DAYS:7+AND+Status__c<>'Cancelled')+AND+Status<>'Cancelled'"
		)) as { records: { Id: string; Status: string; OrderNumber: string; }[]; }
	).records.length;

	return {
		workers,
		todayBRSSLaborCosts,
		customRangeAmount: -1,
		ytdAmount: -1,
		lastMonthAmount: -1,
		last30DaysAmount: -1,
		last7DaysAmount: -1,
		next7DayOrderCount
	};
}

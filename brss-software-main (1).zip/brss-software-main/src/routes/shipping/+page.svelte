<script lang="ts">
	import * as Table from '$lib/components/ui/table/index.js';
	import { Input } from '$lib/components/ui/input';
	import { Checkbox } from '$lib/components/ui/checkbox';

	import { today, CalendarDate, getLocalTimeZone } from '@internationalized/date';
	import { RangeCalendar } from '$lib/components/ui/range-calendar/index.js';
	import { Button } from '$lib/components/ui/button/index.js';

	import { invalidateAll } from '$app/navigation';
	import { dateToYYYYMMDD, isValidDateString } from '../trucks/utils';
	import { triggerAlert } from '$lib/stores/alert';

	import { onMount } from 'svelte';
	import { browser } from '$app/environment';

	import { page } from '$app/stores';
	import type { PageData } from './$types';

	import { PDFDocument } from 'pdf-lib';

	export let data: PageData;

	let calculating = false;

	let end = today(getLocalTimeZone());
	let start = end.subtract({ days: 13 });

	// Check if there are already dates in the params.
	if ($page.url.searchParams.has('startDate') || $page.url.searchParams.has('endDate')) {
		const startDate = $page.url.searchParams.get('startDate') as string;
		if (isValidDateString(startDate)) {
			// parse yyyy, mm, dd
			const [yyyy, mm, dd] = startDate.split('-').map(Number);
			start = new CalendarDate(yyyy, mm, dd);
		}

		const endDate = $page.url.searchParams.get('endDate') as string;
		if (isValidDateString(endDate)) {
			// parse yyyy, mm, dd
			const [yyyy, mm, dd] = endDate.split('-').map(Number);
			end = new CalendarDate(yyyy, mm, dd);
		}
	}

	let value = {
		start,
		end
	};

	let copyValue = { ...value };

	/**
	 * Reroutes the user to the shipping page with the selected date range.
	 */
	async function applyRange() {
		if (value) {
			const startDate = dateToYYYYMMDD(copyValue.start.toDate(getLocalTimeZone()), false);
			const endDate = dateToYYYYMMDD(copyValue.end.toDate(getLocalTimeZone()), false);

			if (startDate && endDate) {
				window.location.href = `/shipping?startDate=${startDate}&endDate=${endDate}`;
				await invalidateAll();
			}
		}
	}

	// In firebase, it is stored like: workerTruckAssignments > date > trucks > truckName >
	// object à la { 1 - 3 PM: [worker1, worker2], 3 - 5 PM: [worker3, worker4], ... }
	const allDaysInRange: Date[] = [];
	const currDate = start.toDate(getLocalTimeZone());
	while (currDate <= end.toDate(getLocalTimeZone())) {
		allDaysInRange.push(new Date(currDate));
		currDate.setDate(currDate.getDate() + 1);
	}

	// New reactive variable to keep track of ticked appointments
	let tickedAppointments: number[] = [];

	// Function to handle checkbox changes
	function handleCheckboxChange(index: number, event: unknown) {
		setTimeout(() => {
			if ((event as any).detail.currentTarget?.getAttribute('aria-checked') === 'true') {
				tickedAppointments = [...tickedAppointments, index];
			} else {
				tickedAppointments = tickedAppointments.filter((i) => i !== index);
			}
		}, 150);
	}

	// subIndividualWeights is whatever the billableWeight is by default.
	let subIndividualWeights: { [key: string]: (string | number)[] } = Object.fromEntries(
		data.output.map((_, i) => [i, Array(data.output[i].articles.length).fill(0)])
	);

	onMount(() => {
		// For some reason there are some reactivity issues or IDK.
		for (let i = 0; i < data.output.length; i++) {
			for (let j = 0; j < data.output[i].articles.length; j++) {
				subIndividualWeights[i][j] = data.output[i].articles[j].billedWeight;
				subIndividualValues[i][j] = 100;
			}
		}
	});

	let subIndividualValues: { [key: string]: (string | number)[] } = Object.fromEntries(
		data.output.map((_, i) => [i, Array(data.output[i].articles.length).fill(100)])
	);

	async function generateFedExLabels() {
		calculating = true;
		const res = await fetch('/api/shipping/generateFedExLabels', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json'
			},
			body: JSON.stringify({
				output: data.output,
				tickedAppointments,
				subIndividualValues,
				subIndividualWeights
			})
		});

		const json = (await res.json()) as any[];

		let showedBadFlag = false;
		let shipmentLabels: { base64Labels: string[]; filename: string }[] = [];

		for (const item of json) {
			if (!item.success && !showedBadFlag) {
				triggerAlert('Unable to generate FedEx labels for some appointments!', 'red');
				showedBadFlag = true;
			} else if (item.success) {
				try {
					// Get master tracking number for the shipment
					const masterTrackingNumber = item.res.output.transactionShipments[0].masterTrackingNumber;
					const pieceResponses = item.res.output.transactionShipments[0].pieceResponses;

					// Collect all labels for this shipment
					const labels = pieceResponses.map(
						(piece: { packageDocuments: { encodedLabel: string }[] }) =>
							piece.packageDocuments[0].encodedLabel
					);

					shipmentLabels.push({
						base64Labels: labels,
						filename: `fedex_shipment_${masterTrackingNumber}.pdf`
					});
				} catch (e) {
					console.error('Error extracting label data:', e);
				}
			}
		}

		calculating = false;

		if (shipmentLabels.length > 0) {
			triggerAlert('FedEx labels generated successfully, downloading...');

			// Download each shipment's PDF
			for (const shipment of shipmentLabels) {
				if (browser) {
					try {
						// Create a new PDF document
						const mergedPdf = await PDFDocument.create();

						// For each base64 label
						for (const base64Label of shipment.base64Labels) {
							// Convert base64 to Uint8Array
							const labelBytes = Uint8Array.from(atob(base64Label), c => c.charCodeAt(0));
							
							// Load the label PDF
							const labelPdf = await PDFDocument.load(labelBytes);
							
							// Copy all pages from the label PDF to the merged PDF
							const copiedPages = await mergedPdf.copyPages(labelPdf, labelPdf.getPageIndices());
							copiedPages.forEach(page => mergedPdf.addPage(page));
						}

						// Save the merged PDF
						const mergedPdfBytes = await mergedPdf.save();

						// Create and trigger download
						const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
						const link = document.createElement('a');
						link.href = URL.createObjectURL(blob);
						link.download = shipment.filename;
						document.body.appendChild(link);
						link.click();
						document.body.removeChild(link);
						URL.revokeObjectURL(link.href);
					} catch (error) {
						console.error('Error merging PDFs:', error);
						triggerAlert('Error merging PDF labels', 'red');
					}
				}
			}
		}
	}
</script>

<svelte:head>
	<title>Shipping | BRSS Admin Software</title>
	<meta
		name="description"
		content="Automatically generate FedEx shipping labels for BRSS' shipping orders in some given time period."
	/>
</svelte:head>

<!-- NOTE: don't need to handle mobile view for this imo -->
<div
	class="flex w-full flex-row gap-x-6 {data.output.reduce(
		(acc, curr) => acc + curr.articles.length,
		0
	) >= 7
		? 'mt-20'
		: ''}"
>
	<div class="flex flex-col md:flex-row">
		<div class="mx-auto mb-8 w-auto md:mb-0">
			<RangeCalendar bind:value={copyValue} class="mx-auto w-auto rounded-md border shadow" />
			<Button class="mt-4 w-full" on:click={applyRange}>Apply</Button>
			<p class="mt-2 text-center">
				Range is <span class="font-bold">inclusive on both ends</span>.
			</p>
		</div>
	</div>
	<div class="w-full">
		<div class="w-full">
			<Button
				on:click={generateFedExLabels}
				class="float-right -mt-14 ml-auto mr-0"
				disabled={calculating}
				>Generate Labels
				{#if calculating}<div class="lds-ring ml-2">
						<div></div>
						<div></div>
						<div></div>
						<div></div>
					</div>{/if}</Button
			>
			<div class="flex flex-col gap-y-4">
				{#each data.output.sort( (a, b) => a.date.localeCompare(b.date) ) as consolidatedAppointment, i (i)}
					<div
						class="flex items-center gap-x-4 rounded-xl border px-2 py-4 {tickedAppointments.includes(
							i
						)
							? 'border border-black'
							: ''}"
					>
						<Table.Root class="w-full">
							<Table.Header>
								<Table.Row>
									<Table.Head>Order #</Table.Head>
									<Table.Head class="w-28">Customer</Table.Head>
									<Table.Head class="w-28">Date</Table.Head>
									<Table.Head class="w-36">Article</Table.Head>
									<Table.Head class="w-28">Billed Weight</Table.Head>
									<Table.Head class="w-24">Weight</Table.Head>
									<Table.Head class="w-24">TD Value</Table.Head>
								</Table.Row>
							</Table.Header>
							<Table.Body>
								{#each consolidatedAppointment.articles as article, j (j)}
									<Table.Row>
										<Table.Cell class="font-medium"
											>{consolidatedAppointment.orderNumber}</Table.Cell
										>
										<Table.Cell>{consolidatedAppointment.customer.name}</Table.Cell>
										<Table.Cell>{consolidatedAppointment.date}</Table.Cell>
										<Table.Cell>{article.id} / {article.name}</Table.Cell>
										<Table.Cell>{article.billedWeight} lb</Table.Cell>
										<Table.Cell class="items-center gap-x-2">
											<div class="flex items-center gap-x-2">
												<Input
													type="number"
													class="w-16"
													min="1"
													bind:value={subIndividualWeights[i][j]}
												/> lb
											</div></Table.Cell
										>
										<Table.Cell class="items-center gap-x-2">
											<div class="flex items-center gap-x-2">
												<Input
													type="number"
													class="w-16"
													min="0"
													bind:value={subIndividualValues[i][j]}
												/> USD
											</div>
										</Table.Cell>
									</Table.Row>
								{/each}
							</Table.Body>
						</Table.Root>
						<div
							class="mx-auto flex w-16 flex-col items-center gap-y-4 border-l-2 p-2 text-center text-sm font-medium"
						>
							<Checkbox on:click={(e) => handleCheckboxChange(i, e)} />
						</div>
					</div>
				{/each}
				{#if data.output.length === 0}
					<div class="flex w-full flex-col items-center justify-center">
						<p class="text-lg font-light italic text-gray-600">
							No appointments requiring labels were found for the selected date range.
						</p>
					</div>
				{/if}
			</div>
		</div>
	</div>
</div>

<style>
	.lds-ring,
	.lds-ring div {
		box-sizing: border-box;
	}
	.lds-ring {
		display: inline-block;
		position: relative;
		width: 20px;
		height: 20px;
	}
	.lds-ring div {
		box-sizing: border-box;
		display: block;
		position: absolute;
		width: 16px;
		height: 16px;
		margin: 2px;
		border: 2px solid currentColor;
		border-radius: 50%;
		animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
		border-color: currentColor transparent transparent transparent;
	}
	.lds-ring div:nth-child(1) {
		animation-delay: -0.45s;
	}
	.lds-ring div:nth-child(2) {
		animation-delay: -0.3s;
	}
	.lds-ring div:nth-child(3) {
		animation-delay: -0.15s;
	}
	@keyframes lds-ring {
		0% {
			transform: rotate(0deg);
		}
		100% {
			transform: rotate(360deg);
		}
	}
</style>

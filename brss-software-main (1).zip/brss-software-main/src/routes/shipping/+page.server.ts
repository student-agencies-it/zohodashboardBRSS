import credentialedFetch from '$lib/req';
import { today, fromDate, getLocalTimeZone } from '@internationalized/date';
import { isValidDateString } from '../trucks/utils';
import { deltaDaysFromToday } from '../tips/utils';
import type { ShipToHomeAppointmentDetails } from '../../types/shipping';

/**
 * Fetches the appointments from Salesforce and returns them to the client-side under `appointments`.
 * @returns the appointments from Salesforce
 */
export async function load({ url }) {
	// It is possible that we are already given a date. Check for the date param. Otherwise set to today.
	const endDate =
		url.searchParams.get('endDate') && isValidDateString(url.searchParams.get('endDate') ?? '')
			? new Date(url.searchParams.get('endDate') ?? '')
			: today(getLocalTimeZone()).toDate(getLocalTimeZone());

	const startDate =
		url.searchParams.get('startDate') && isValidDateString(url.searchParams.get('startDate') ?? '')
			? new Date(url.searchParams.get('startDate') ?? '')
			: fromDate(endDate, getLocalTimeZone()).subtract({ days: 13 }).toDate();

	// For testing purposes.
	// endDate.setMonth(endDate.getMonth() + 3);
	// startDate.setMonth(0);

	const startString =
		deltaDaysFromToday(startDate) * -1 >= 0
			? `N_DAYS_AGO:${deltaDaysFromToday(startDate) * -1}`
			: `NEXT_N_DAYS:${deltaDaysFromToday(startDate)}`; // future will be zero anyway (for tips!)
	const endString =
		deltaDaysFromToday(endDate) * -1 >= 0
			? `N_DAYS_AGO:${deltaDaysFromToday(endDate) * -1}`
			: `NEXT_N_DAYS:${deltaDaysFromToday(endDate)}`; // future will be zero anyway (for tips!)

	// Preliminary work to connect a date + time for the tip object array as cannot be read in directly from that table.
	const res = (await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Date__c,+Order__c,+Status__c+FROM+Appointment__c+WHERE+Date__c+>=+${startString}+AND+Date__c+<=+${endString}+AND+Status__c!='Cancelled'`
	)) as {
		records: {
			Date__c: string;
			Order__c: string;
			Status__c: string;
		}[];
	};

	// Anti-spam.
	res.records = res.records.filter((r) => r.Order__c !== null);

	const mappingRes = (await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Id,+Status,+OrderNumber,+ShipHomePhoneNumber__c,+ShipHomeAddressedTo__c,+ShipHomeAddress1__c,+ShipHomeCity__c,+ShipHomeZip__c,+ShipHomeState__c,++ShippingAddress+FROM+Order+WHERE+Type__c+includes+('Ship+to+Home')+AND+Id+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+>=+${startString}+AND+Date__c+<=+${endString}+AND+Status__c!='Cancelled')`
	)) as {
		records: {
			Id: string;
			Status: string;
			OrderNumber: string;
			ShipHomePhoneNumber__c: string;
			ShipHomeAddressedTo__c: string;
			ShipHomeAddress1__c: string;
			ShipHomeCity__c: string;
			ShipHomeZip__c: string;
			ShipHomeState__c: string;
			ShippingAddress: string; // kind of useless I think?
		}[];
	};

	const mapping = mappingRes.records.reduce(
		(
			acc,
			{
				Id,
				Status,
				OrderNumber,
				ShipHomePhoneNumber__c,
				ShipHomeAddressedTo__c,
				ShipHomeAddress1__c,
				ShipHomeCity__c,
				ShipHomeZip__c,
				ShipHomeState__c,
				ShippingAddress
			}
		) => {
			acc[Id] = {
				Status,
				OrderNumber,
				ShipHomePhoneNumber__c,
				ShipHomeAddressedTo__c,
				ShipHomeAddress1__c,
				ShipHomeCity__c,
				ShipHomeZip__c,
				ShipHomeState__c,
				ShippingAddress
			};
			return acc;
		},
		{} as Record<
			string,
			{
				Status: string;
				OrderNumber: string;
				ShipHomePhoneNumber__c: string;
				ShipHomeAddressedTo__c: string;
				ShipHomeAddress1__c: string;
				ShipHomeCity__c: string;
				ShipHomeZip__c: string;
				ShipHomeState__c: string;
				ShippingAddress: string;
			}
		>
	);

	// For some reason I struggle to comprehend there is a many-to-many relationship between Order and Article.

	const articleHelperRes = mappingRes.records.length > 0 ? ((await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Order__c,+Article__c+FROM+OrderArticle__c+WHERE+Order__c+IN+(${mappingRes.records
			.map((r) => `'${r.Id}'`)
			.join(',')})`
	)) as {
		records: {
			Order__c: string;
			Article__c: string;
		}[];
	}) ?? {
		records: []
	}
		: {
			records: []
		};

	const articleToOrderMapping = articleHelperRes.records.reduce(
		(acc, { Order__c, Article__c }) => {
			if (acc[Article__c]) {
				console.log('This should never be displayed.');
			}
			acc[Article__c] = Order__c;
			return acc;
		},
		{} as Record<string, string>
	);

	const articleIDRes = articleHelperRes.records.length > 0 ? ((await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Id,+BillableWeight__c,+Name,+Type__c+FROM+Article__c+WHERE+Id+IN+(${articleHelperRes.records
			.map((r) => `'${r.Article__c}'`)
			.join(',')})`
	)) as {
		records: {
			Id: string;
			BillableWeight__c: number;
			Name: string;
			Type__c: string;
		}[];
	}) ?? {
		records: []
	}
		: {
			records: []
		};

	const articleMapping = articleIDRes.records.reduce(
		(acc, { Id, BillableWeight__c, Name, Type__c }) => {
			if (!acc[articleToOrderMapping[Id]]) {
				acc[articleToOrderMapping[Id]] = [{ BillableWeight__c, Name, Type: Type__c }];
			} else {
				acc[articleToOrderMapping[Id]].push({ BillableWeight__c, Name, Type: Type__c });
			}
			return acc;
		},
		{} as Record<
			string,
			{
				BillableWeight__c: number;
				Name: string;
				Type: string;
			}[]
		>
	);

	let output: ShipToHomeAppointmentDetails[] = [];

	// - Auto-read: Customer Name, Order #, Order Article, Date, Billed Weight,
	// - Inputted Manually / Read from DB: weight, total order value
	// - (+ probably some more info to send to FedEx.)

	// Update res — map order ID to OrderNumber
	res.records.forEach((record) => {
		output.push({
			date: record.Date__c,
			orderNumber: mapping[record.Order__c]?.OrderNumber,
			customer: {
				name: mapping[record.Order__c]?.ShipHomeAddressedTo__c,
				phone: mapping[record.Order__c]?.ShipHomePhoneNumber__c,
				address: mapping[record.Order__c]?.ShipHomeAddress1__c,
				city: mapping[record.Order__c]?.ShipHomeCity__c,
				state: mapping[record.Order__c]?.ShipHomeState__c,
				zip: mapping[record.Order__c]?.ShipHomeZip__c
			},
			articles: articleMapping[record.Order__c]?.map((article) => ({
				id: article.Name,
				name: article.Type,
				billedWeight: article.BillableWeight__c,
				weight: null
			})),
			totalDeclaredValue: null
		});
	});

	// This is highly necessary though to get rid of the a) non-ship2home orders and b) cancelled / missed / test orders.
	output = output.filter((r) => r.orderNumber !== undefined && r.articles && r.articles.length > 0);

	return {
		output
	};
}

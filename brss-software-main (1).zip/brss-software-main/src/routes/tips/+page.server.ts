import credentialedFetch from '$lib/req';
import { getLocalTimeZone, today, fromDate } from '@internationalized/date';
import { isValidDateString } from '../trucks/utils';
import {
	massageRecords,
	type RawAppointmentResponse,
	type RawOrderItemResponse
} from '../orders/utils';
import { deltaDaysFromToday } from './utils';

/**
 * Fetches the tips from Salesforce and returns them to the client-side under `tips`.
 * @returns the tips from Salesforce
 */
export async function load({ url }) {
	// NOTE: the algorithm is inclusive on both ends.
	// It is possible that we are already given a date. Check for the date param. Otherwise set to today.
	const endDate =
		url.searchParams.get('endDate') && isValidDateString(url.searchParams.get('endDate') ?? '')
			? new Date(url.searchParams.get('endDate') ?? '')
			: today(getLocalTimeZone()).toDate(getLocalTimeZone());

	const startDate =
		url.searchParams.get('startDate') && isValidDateString(url.searchParams.get('startDate') ?? '')
			? new Date(url.searchParams.get('startDate') ?? '')
			: fromDate(endDate, getLocalTimeZone()).subtract({ days: 13 }).toDate();

	const startString =
		deltaDaysFromToday(startDate) * -1 >= 0
			? `N_DAYS_AGO:${deltaDaysFromToday(startDate) * -1}`
			: `NEXT_N_DAYS:${deltaDaysFromToday(startDate)}`; // future will be zero anyway (for tips!)
	const endString =
		deltaDaysFromToday(endDate) * -1 >= 0
			? `N_DAYS_AGO:${deltaDaysFromToday(endDate) * -1}`
			: `NEXT_N_DAYS:${deltaDaysFromToday(endDate)}`; // future will be zero anyway (for tips!)

	// Preliminary work to connect a date + time for the tip object array as cannot be read in directly from that table.
	const res = (await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Date__c,+Time__c,+Status__c,+PhoneNumber__c,+Type__c,+Order__c,+Building__c,+Address1__c,+Address2__c,+EstimatedNumberOfItems__c,+EstimatedBoxedItems__c,+EstimatedNonBoxedItems__c,+Notes__c,+RoomNumber__c+FROM+Appointment__c+WHERE+Date__c+>=+${startString}+AND+Date__c+<=+${endString}`
	)) as { records: RawAppointmentResponse[]; };

	// Anti-spam.
	res.records = res.records.filter((r) => r.Order__c !== null);

	const mappingRes = (await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Id,+Status,+OrderNumber+FROM+Order+WHERE+Id+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+>=+${startString}+AND+Date__c+<=+${endString})`
	)) as { records: { Id: string; Status: string; OrderNumber: string; }[]; };

	const mapping = mappingRes.records.reduce(
		(acc, { Id, Status, OrderNumber }) => {
			acc[Id] = { Status, OrderNumber };
			return acc;
		},
		{} as Record<
			string,
			{
				Status: string;
				OrderNumber: string;
			}
		>
	);

	// Update res — map order ID to OrderNumber
	res.records.forEach((record) => {
		record.OrderNumber = mapping[record.Order__c]?.OrderNumber;
		record.Status__c =
			mapping[record.Order__c]?.Status === 'Cancelled' ? 'Cancelled' : record.Status__c;
	});

	const orderItemsRes = (await credentialedFetch(
		`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Product2Id,+Quantity,+OrderId+FROM+OrderItem+WHERE+OrderId+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+>=+${startString}+AND+Date__c+<=+${endString})`
	)) as { records: { Product2Id: string; Quantity: number; OrderId: string; }[]; };

	// create a new map that adds in name to orderItemsRes
	const orderItems = orderItemsRes.records.map((record) => ({
		...record,
		Name: undefined // we don't care
	})) as RawOrderItemResponse[];

	const massagedForUnification = massageRecords(res.records, orderItems).sort((a, b) => {
		if (a.deliveryDate === b.deliveryDate) {
			return a.deliveryTime.localeCompare(b.deliveryTime);
		} else {
			return a.deliveryDate.localeCompare(b.deliveryDate);
		}
	});

	const tipRes = (
		(await credentialedFetch(
			`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+TipAmount__c,+OrderNumber+FROM+Order+WHERE+Id+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+>=+${startString}+AND+Date__c+<=+${endString})`
		)) as { records: { TipAmount__c: string; OrderNumber: string; attributes: object; }[]; }
	).records.map((record) => ({
		tipValue: parseFloat(record.TipAmount__c),
		orderNumber: record.OrderNumber
	}));

	let tips: {
		orderNumber: string;
		deliveryDate: string;
		deliveryTime: string;
		tipValue: number;
	}[] = [];

	// Merge the tip values into the massaged records.
	massagedForUnification.forEach((record) => {
		const tipRecord = tipRes.find((tip) => tip.orderNumber === record.orderNumber);
		if (tipRecord) {
			tips.push({
				deliveryDate: record.deliveryDate,
				deliveryTime: record.deliveryTime,
				orderNumber: record.orderNumber,
				tipValue: tipRecord.tipValue
			});
		}
	});

	// Let's keep things simple and only deal with those tips that have a non-zero value.
	tips = tips.filter((tip) => tip.tipValue > 0);

	return {
		tips
	};
}

<script lang="ts">
	import * as Table from '$lib/components/ui/table/index.js';
	import * as Alert from '$lib/components/ui/alert/index.js';
	import { today, CalendarDate, getLocalTimeZone } from '@internationalized/date';
	import { RangeCalendar } from '$lib/components/ui/range-calendar/index.js';
	import { Button } from '$lib/components/ui/button/index.js';

	import { invalidateAll } from '$app/navigation';
	import { dateToYYYYMMDD, isValidDateString } from '../trucks/utils';

	import { page } from '$app/stores';
	import type { PageData } from './$types';
	import { db } from '$lib/firebase/client';
	import { doc, getDoc } from 'firebase/firestore';
	import { onMount } from 'svelte';

	export let data: PageData;

	// NOTE: the algorithm will be inclusive on both ends.
	let end = today(getLocalTimeZone());

	let start = end.subtract({ days: 13 });

	// Check if there are already dates in the params.
	if ($page.url.searchParams.has('startDate') || $page.url.searchParams.has('endDate')) {
		const startDate = $page.url.searchParams.get('startDate') as string;
		if (isValidDateString(startDate)) {
			// parse yyyy, mm, dd
			const [yyyy, mm, dd] = startDate.split('-').map(Number);
			start = new CalendarDate(yyyy, mm, dd);
		}

		const endDate = $page.url.searchParams.get('endDate') as string;
		if (isValidDateString(endDate)) {
			// parse yyyy, mm, dd
			const [yyyy, mm, dd] = endDate.split('-').map(Number);
			end = new CalendarDate(yyyy, mm, dd);
		}
	}

	let workerInfos = new Map<string, number>();

	let value = {
		start,
		end
	};

	let copyValue = { ...value };

	/**
	 * Reroutes the user to the tips page with the selected date range.
	 */
	async function applyRange() {
		if (value) {
			const startDate = dateToYYYYMMDD(copyValue.start.toDate(getLocalTimeZone()), false);
			const endDate = dateToYYYYMMDD(copyValue.end.toDate(getLocalTimeZone()), false);

			if (startDate && endDate) {
				window.location.href = `/tips?startDate=${startDate}&endDate=${endDate}`;
				await invalidateAll();
			}
		}
	}

	// In firebase, it is stored like: workerTruckAssignments > date > trucks > truckName >
	// object à la { 1 - 3 PM: [worker1, worker2], 3 - 5 PM: [worker3, worker4], ... }
	const allDaysInRange: Date[] = [];
	const currDate = start.toDate(getLocalTimeZone());
	while (currDate <= end.toDate(getLocalTimeZone())) {
		allDaysInRange.push(new Date(currDate));
		currDate.setDate(currDate.getDate() + 1);
	}

	const namesToCheck = [
		'Unassigned',
		'High Roof',
		'BR Van',
		'Truck 1',
		'Truck 2',
		'Truck 3',
		'Truck 4',
		'Truck 5',
		'Truck 6',
		'Truck 7',
		'Truck 8',
		'Truck 9',
		'Truck 10'
	];

	const dateTruckWorkerInfo = new Map<
		string,
		Map<string, { period: string; workers: { name: string; driver: boolean }[] }[]>
	>();

	const assignmentPromises = allDaysInRange.map(async (date) => {
		const dateString = date.toISOString().split('T')[0];

		// get everything in the collection for that date
		for (const name of namesToCheck) {
			const docRef = doc(db, 'workerTruckAssignments', dateString, 'trucks', name);
			const docSnap = await getDoc(docRef);
			if (docSnap.exists()) {
				const data = docSnap.data();
				if (data) {
					const periods = Object.keys(data);
					const workerInfo = periods.map((period) => {
						return {
							period,
							workers: data[period]
						};
					});

					if (!dateTruckWorkerInfo.has(dateString)) {
						dateTruckWorkerInfo.set(dateString, new Map());
					}

					dateTruckWorkerInfo.get(dateString)?.set(name, workerInfo);
				}
			}
		}
	});

	let complicatedTips: {
		orderNumber: string;
		deliveryDate: string;
		deliveryTime: string;
		tipValue: number;
		truckName?: string;
	}[] = [];

	const orderPromises = data.tips.map(async (tip) => {
		const docRef = doc(db, 'orders', tip.orderNumber);
		const docSnap = await getDoc(docRef);
		if (docSnap.exists()) {
			const data = docSnap.data();
			if (data) {
				const truckAssignment: string | null = data.truckAssignment;
				if (truckAssignment) {
					complicatedTips.push({ ...tip, truckName: truckAssignment });
				} else {
					complicatedTips.push(tip);
				}
			}
		} else {
			complicatedTips.push(tip);
		}
	});

	let totalUnfoundValue = 0.0;
	let calculated = false;

	async function updateWorkerInfos() {
		for (const tip of complicatedTips) {
			let flag = false;
			if (tip.truckName && dateTruckWorkerInfo.has(tip.deliveryDate)) {
				const workers = dateTruckWorkerInfo
					.get(tip.deliveryDate)
					?.get(tip.truckName)
					?.find((workerInfo) => workerInfo.period === tip.deliveryTime)?.workers;

				for (const worker of workers ?? []) {
					if (!flag) {
						flag = true;
					}
					if (workerInfos.has(worker.name)) {
						workerInfos.set(
							worker.name,
							workerInfos.get(worker.name)! + tip.tipValue / (workers ?? [worker]).length
						);
					} else {
						workerInfos.set(worker.name, tip.tipValue / (workers ?? [worker]).length);
					}
				}
			}

			if (!flag) {
				totalUnfoundValue += tip.tipValue;
			}
		}

		// Don't want to show nonsense or the initial loader.
		for (const [name, tip] of workerInfos) {
			if (name === 'Loading worker info...' || tip === 0.0) {
				workerInfos.delete(name);
			}
		}
	}

	onMount(async () => {
		await Promise.all(assignmentPromises);
		await Promise.all(orderPromises);
		await updateWorkerInfos();
		calculated = true;
	});
</script>

<svelte:head>
	<title>Tips | BRSS Admin Software</title>
	<meta
		name="description"
		content="Select a date range and let BRSS Admin Software do the rest in terms of calculating tips for field representatives."
	/>
</svelte:head>

<div class="flex flex-col">
	<p class="mx-auto mb-4 text-center">
		A total of <span class="font-bold">{data.tips.length} tips</span> were given totaling
		<span class="font-bold"
			>${data.tips
				.reduce((acc, tip) => acc + tip.tipValue, 0)
				.toFixed(2)
				.toString() // we want comma-separated thousands
				.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}
		</span>
	</p>
	{#if calculated && totalUnfoundValue > 0}
		<Alert.Root variant="destructive">
			<!-- <Alert.Title>Unmatched tips</Alert.Title> -->
			<Alert.Description
				>A total of <span class="font-bold"
					>${totalUnfoundValue
						.toFixed(2)
						.toString() // we want comma-separated thousands
						.replace(/\B(?=(\d{3})+(?!\d))/g, ',')}</span
				> in tips are not matched to workers!</Alert.Description
			>
		</Alert.Root>
	{/if}
	<p class="mx-auto mb-4 text-center"></p>
	<div class="flex flex-col md:flex-row">
		<div class="mx-auto mb-8 w-auto md:mb-0">
			<RangeCalendar bind:value={copyValue} class="mx-auto w-auto rounded-md border shadow" />
			<Button class="mt-4 w-full" on:click={applyRange}>Apply</Button>
			<p class="mt-2 text-center">
				Tipping dates are <span class="font-bold">both inclusive</span>.
			</p>
		</div>

		<Table.Root class="mx-8 w-[350px]">
			<Table.Caption>A list of workers and their tips.</Table.Caption>
			<Table.Header>
				<Table.Row>
					<Table.Head>Name</Table.Head>
					<Table.Head>Tip</Table.Head>
				</Table.Row>
			</Table.Header>
			<Table.Body>
				{#if !calculated}
					<Table.Row class="mt-1">
						<Table.Cell
							><div class="lds-ring">
								<div></div>
								<div></div>
								<div></div>
								<div></div>
							</div></Table.Cell
						>
						<Table.Cell
							><div class="lds-ring">
								<div></div>
								<div></div>
								<div></div>
								<div></div>
							</div></Table.Cell
						>
					</Table.Row>
				{:else}
					{#each workerInfos as [key, value] (key)}
						<Table.Row>
							<Table.Cell class="font-medium">{key}</Table.Cell>
							<Table.Cell>${value.toFixed(2)}</Table.Cell>
						</Table.Row>
					{/each}
				{/if}
			</Table.Body>
		</Table.Root>
	</div>
</div>

<style>
	.lds-ring {
		width: 20px;
		height: 20px;
	}
	.lds-ring div {
		box-sizing: border-box;
		display: block;
		position: absolute;
		width: 24px;
		height: 24px;
		margin: 2px;
		border: 2px solid #666;
		border-radius: 50%;
		animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
		border-color: #666 transparent transparent transparent;
	}
	.lds-ring div:nth-child(1) {
		animation-delay: -0.45s;
	}
	.lds-ring div:nth-child(2) {
		animation-delay: -0.3s;
	}
	.lds-ring div:nth-child(3) {
		animation-delay: -0.15s;
	}
	@keyframes lds-ring {
		0% {
			transform: rotate(0deg);
		}
		100% {
			transform: rotate(360deg);
		}
	}
</style>

/**
 * A helper function to calculate the number of days from today to the dateForComparison.
 * @param dateForComparison the date to compare to today
 * @returns the number of days from today to the dateForComparison
 */
export function deltaDaysFromToday(dateForComparison: Date) {
	const today = new Date();
	const delta = dateForComparison.getTime() - today.getTime();
	if (delta >= 0) {
		return Math.floor(delta / (1000 * 3600 * 24));
	} else {
		return Math.ceil(delta / (1000 * 3600 * 24));
	}
}

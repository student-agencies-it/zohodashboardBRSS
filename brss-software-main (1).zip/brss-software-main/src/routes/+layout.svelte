<script lang="ts">
	import '../app.pcss';
	import { user } from '$lib/stores/user';
	import Button from '$lib/components/ui/button/button.svelte';

	import ExclamationTriangle from 'svelte-radix/ExclamationTriangle.svelte';
	import InfoCircled from 'svelte-radix/InfoCircled.svelte';
	import Dashboard from 'svelte-radix/Dashboard.svelte';
	import Calendar from 'svelte-radix/Calendar.svelte';
	import CardStack from 'svelte-radix/CardStack.svelte';
	import Move from 'svelte-radix/Move.svelte';
	import Heart from 'svelte-radix/Heart.svelte';
	import Cube from 'svelte-radix/Cube.svelte';

	import brssLogo from '$lib/assets/brss_logo.png';
	import { page } from '$app/stores';
	import { goto } from '$app/navigation';
	import { onMount } from 'svelte';

	import * as Alert from '$lib/components/ui/alert/index.js';

	import { signOut } from 'firebase/auth';
	import { app, auth } from '$lib/firebase/client';
	import { getAnalytics } from 'firebase/analytics';

	onMount(() => {
		getAnalytics(app);
	});

	import { showAlert, alertMessage, alertColor } from '$lib/stores/alert';

	async function performSignOut() {
		try {
			await signOut(auth);
		} catch (error) {
			console.error('Error signing out:', error);
		}
	}

	// NOTE: this is still not good enough.
	// On a slow connection, the user will see the page for a split second before being redirected.
	// This is because we *first* run the .server.ts file, and render the html from the server, and
	// only later perform this check on the browser.
	// NOTE: this can cause a small flicker.

	// *To solve this*, we can use session cookies: https://firebase.google.com/docs/auth/admin/manage-cookies
	$: if ($user) {
		// Either 'anonymous' or a user object
		// NOTE: this is effectively our navigation guard
		if ($page.url.pathname !== '/auth' && $user === 'anonymous') {
			// redirect to login page
			goto('/auth');
		}
	}
</script>

{#if $showAlert}
	<Alert.Root
		variant={$alertColor === 'red' ? 'destructive' : 'default'}
		class="border-{$alertColor}-500 bg-{$alertColor}-100 fixed bottom-12 right-4 w-96"
	>
		<div class="flex items-center gap-x-4">
			{#if $alertColor === 'red'}
				<ExclamationTriangle size="20" />
			{:else}
				<InfoCircled size="20" />
			{/if}
			<span class="hidden border-green-500 border-red-500 bg-green-100 bg-red-100" />
			<Alert.Description class="w-96">{$alertMessage}</Alert.Description>
		</div>
	</Alert.Root>
{/if}

{#if !$user}
	<div class="center-screen">
		<div class="lds-ring">
			<div></div>
			<div></div>
			<div></div>
			<div></div>
		</div>
	</div>
{:else}
	<div class="forced-max-width flex flex-col justify-between">
		<div>
			<!-- navigation bar -->
			<div class="z-50 flex pt-4">
				{#if $user === 'anonymous'}
					<Button class="fixed right-4 float-right inline-block" variant="secondary" href="/auth"
						>Sign Up</Button
					>
				{:else if $user !== null}
					<Button
						class="fixed right-4 float-right inline-block"
						variant="secondary"
						style="z-index: 51;"
						on:click={performSignOut}>Sign out</Button
					>
				{/if}
			</div>
			<!-- sidebar -->
			{#if $user && $user !== 'anonymous'}
				<div class="z-50 mt-5 flex items-center md:fixed md:-mt-9 md:h-screen md:justify-between">
					<div class="flex flex-col gap-y-2 py-4 md:border-r-2 md:py-10">
						<Button class="mr-4 flex justify-start text-base" variant="ghost" href="/"
							><Dashboard class="mr-2 h-5 w-5" /> Dashboard</Button
						>
						<Button class="mr-4 flex justify-start text-base" variant="ghost" href="/calendar"
							><Calendar class="mr-2 h-5 w-5" /> Calendar</Button
						>
						<Button class="mr-4 flex justify-start text-base" variant="ghost" href="/orders"
							><CardStack class="mr-2 h-5 w-5" />Orders</Button
						>
						<Button class="mr-4 flex justify-start text-base" variant="ghost" href="/trucks"
							><Move class="mr-2 h-5 w-5" /> Trucks</Button
						>
						<Button class="mr-4 flex justify-start text-base" variant="ghost" href="/tips"
							><Heart class="mr-2 h-5 w-5" />Tips</Button
						>
						<Button class="mr-4 flex justify-start text-base" variant="ghost" href="/shipping"
							><Cube class="mr-2 h-5 w-5" />Shipping</Button
						>
					</div>
				</div>
			{/if}
			<div
				class="mb-4 {$user && $user !== 'anonymous' ? 'md:ml-44' : ''} flex {$page.url.pathname ===
				'/trucks'
					? 'mt-10'
					: 'md:items-center'} screen-min-height justify-center px-6 py-4 md:py-10"
			>
				<slot />
			</div>
		</div>
		<!-- footer -->
		<div class="w-full font-medium">
			<div class="flex justify-between text-sm">
				<p>
					© <a href="https://www.studentagencies.com/" target="_blank">Student Agencies</a>
					{new Date().getUTCFullYear()}
				</p>
				<a href="/"> <img src={brssLogo} alt="brss logo" class="-mt-10 hidden h-20 md:block" /></a>
				<a class="hover:underline" href="mailto:it@studentagencies.com" target="_blank"
					>it@studentagencies.com</a
				>
			</div>
		</div>
	</div>
{/if}

<style lang="postcss">
	:global(.forced-max-width) {
		@apply mx-auto flex-grow px-4 sm:max-w-xl md:max-w-full lg:max-w-screen-2xl;
	}

	.center-screen {
		position: fixed;
		top: 0;
		left: 0;
		width: 100%;
		height: 100%;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.lds-ring {
		display: inline-block;
		position: relative;
		width: 40px;
		height: 40px;
	}
	.lds-ring div {
		box-sizing: border-box;
		display: block;
		position: absolute;
		width: 44px;
		height: 44px;
		margin: 4px;
		border: 4px solid #666;
		border-radius: 50%;
		animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
		border-color: #666 transparent transparent transparent;
	}
	.lds-ring div:nth-child(1) {
		animation-delay: -0.45s;
	}
	.lds-ring div:nth-child(2) {
		animation-delay: -0.3s;
	}
	.lds-ring div:nth-child(3) {
		animation-delay: -0.15s;
	}
	@keyframes lds-ring {
		0% {
			transform: rotate(0deg);
		}
		100% {
			transform: rotate(360deg);
		}
	}

	@media (max-width: 767px) {
		.screen-min-height {
			min-height: 63vh;
		}
	}

	@media (min-width: 768px) {
		.screen-min-height {
			min-height: 91vh;
		}
	}
</style>

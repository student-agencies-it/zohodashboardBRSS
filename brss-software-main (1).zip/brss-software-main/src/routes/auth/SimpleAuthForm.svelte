<script lang="ts">
	import { Input } from '$lib/components/ui/input';
	import Label from '$lib/components/ui/label/label.svelte';
	import Button from '$lib/components/ui/button/button.svelte';
	import { goto } from '$app/navigation';
	import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
	import { auth } from '$lib/firebase/client';
	import { user } from '$lib/stores/user';

	let email = '';
	let password = '';

	export let isLogin = false;

	let validationErrors: string[] = [];

	const validate = () => {
		validationErrors = [];
		if (!email || !email.includes('@')) {
			validationErrors.push('Please input a valid email.');
		}
		if (!password) {
			validationErrors.push('Password is required.');
		}
		if (password.length < 6) {
			validationErrors.push('Password must be at least 6 characters.');
		}
	};

	async function signInWithSimpleAuth() {
		validate();

		if (validationErrors.length > 0) {
			return;
		}

		try {
			if (isLogin) {
				await signInWithEmailAndPassword(auth, email, password);
				if ($user && $user !== 'anonymous') {
					await goto('/');
				}
			} else {
				await createUserWithEmailAndPassword(auth, email, password);
				if ($user && $user !== 'anonymous') {
					await goto('/');
				}
			}
		} catch (error) {
			alert('An error occurred. Please try again.');
			console.error(error);
		}
	}
</script>

<div class="mt-2">
	<Label>Email</Label>
	<Input bind:value={email} type="email" />
</div>
<div class="mt-2">
	<Label>Password</Label>
	<Input bind:value={password} type="password" />
</div>
<Button class="mb-1 mt-4 w-full" on:click={signInWithSimpleAuth}>Submit</Button>
{#each validationErrors as issue}
	<p class="mt-1 text-sm text-red-500">{issue}</p>
{/each}

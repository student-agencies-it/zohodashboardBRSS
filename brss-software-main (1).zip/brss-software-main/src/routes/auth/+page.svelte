<script lang="ts">
	import { GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
	import { auth } from '$lib/firebase/client';
	import Button from '$lib/components/ui/button/button.svelte';
	import * as Tabs from '$lib/components/ui/tabs';
	import { goto } from '$app/navigation';
	import SimpleAuthForm from './SimpleAuthForm.svelte';
	import { user } from '$lib/stores/user';

	const provider = new GoogleAuthProvider();

	async function signInWithGoogle() {
		try {
			await signInWithPopup(auth, provider);
			// We are performing this check because it is possible that the user tried to sign in
			// using an email that is not on the pre-approved list, in which case they would be
			// forcibly set to be 'anonymous'.
			if ($user && $user !== 'anonymous') {
				await goto('/');
			}
		} catch (error) {
			alert('An error occurred. Please try again later.');
			console.error(error);
		}
	}
</script>

<svelte:head>
	<title>Authenticate | BRSS Admin Software</title>
	<meta
		name="description"
		content="Sign up or log in to the BRSS Admin Software. Requires authentication via an admin-preapproved email account."
	/>
</svelte:head>

<div class="-mb-10 -mt-10 flex w-full items-center justify-center">
	<Tabs.Root value="signup" class="mx-auto w-[400px]">
		<Tabs.List>
			<Tabs.Trigger value="signup">Sign up</Tabs.Trigger>
			<Tabs.Trigger value="login">Log in</Tabs.Trigger>
		</Tabs.List>
		<Tabs.Content value="signup">
			<div>
				<div class="rounded border border-slate-300 p-6">
					<p class="text-sm text-gray-500">Don't have an account? Register one now!</p>

					<SimpleAuthForm />

					<div class="mt-4 flex items-center gap-x-4">
						<hr class="flex-1 border border-slate-300" />
						<p class="text-sm text-gray-500">OR</p>
						<hr class="flex-1 border border-slate-300" />
					</div>

					<div class="flex flex-col gap-y-2 pt-4">
						<Button variant="outline" on:click={signInWithGoogle}>Sign up with Google</Button>
					</div>
				</div>
			</div>
		</Tabs.Content>
		<Tabs.Content value="login">
			<div>
				<div class="rounded border border-slate-300 p-6">
					<p class="text-sm text-gray-500">Already use our service? Let's log you in.</p>

					<SimpleAuthForm isLogin={true} />

					<div class="mt-4 flex items-center gap-x-4">
						<hr class="flex-1 border border-slate-300" />
						<p class="text-sm text-gray-500">OR</p>
						<hr class="flex-1 border border-slate-300" />
					</div>

					<div class="flex flex-col gap-y-2 pt-4">
						<Button variant="outline" on:click={signInWithGoogle}>Sign in with Google</Button>
					</div>
				</div>
			</div>
		</Tabs.Content>
	</Tabs.Root>
</div>

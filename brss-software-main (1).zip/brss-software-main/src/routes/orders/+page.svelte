<script lang="ts">
	import * as Table from '$lib/components/ui/table/index.js';
	import { Input } from '$lib/components/ui/input/index.js';
	import type { PageData } from './$types';
	import type { Appointment } from '../../types/appointment';

	export let data: PageData;

	let searchFilter: string = '';

	/**
	 * Filter appointments based on the search filter. Matches on any field.
	 * @param appointments The appointments to filter.
	 */
	function filterAppointments(appointments: Appointment[]) {
		if (!searchFilter.trim()) {
			return appointments;
		}

		return appointments.filter((appointment) => {
			return Object.values(appointment).some((value) => {
				return String(value).toLowerCase().includes(searchFilter.toLowerCase());
			});
		});
	}

	let filteredAppointments = data.appointments;

	function setupFilter() {
		filteredAppointments = filterAppointments(data.appointments);
	}

	$: searchFilter, setupFilter();

	let sortColumn: keyof Appointment = 'deliveryDate';
	let sortDirection: 'asc' | 'desc' = 'asc';

	/**
	 * Convert a time from 12-hour to 24-hour format. Used for internal ordering.
	 * @param time The time to convert.
	 */
	function convertTo24Hr(time: string) {
		const [hoursStr, period] = time.split(' ');
		const hours = parseInt(hoursStr);

		if (period === 'PM' && hours !== 12) {
			return `${hours + 12}`;
		} else if (period === 'AM' && hours === 12) {
			return `00`;
		} else if (hours >= 10) {
			return `${hours}`;
		} else {
			return `0${hours}`;
		}
	}

	function sortAppointments() {
		filteredAppointments.sort((a, b) => {
			let valueOne = a[sortColumn] ?? '-1';
			let valueTwo = b[sortColumn] ?? '-1';

			// Special logic:
			// - if it is a phone number, strip out everything that is not a number.
			if (sortColumn === 'phone') {
				valueOne = valueOne.toString().replace(/\D/g, '');
				valueTwo = valueTwo.toString().replace(/\D/g, '');
			}
			// - if it is a time, which is formatted as e.g. 1 PM - 3 PM, take the first time
			//	 and convert it so that AM is always before PM. In effect, get a 24-hour time.
			else if (sortColumn === 'deliveryTime') {
				valueOne = convertTo24Hr(valueOne.toString().split(' - ')[0]);
				valueTwo = convertTo24Hr(valueTwo.toString().split(' - ')[0]);
			}

			if (valueOne < valueTwo) {
				return sortDirection === 'asc' ? -1 : 1;
			}
			if (valueOne > valueTwo) {
				return sortDirection === 'asc' ? 1 : -1;
			}
			return 0;
		});

		filteredAppointments = filteredAppointments; // reactivity
	}

	function onHeaderClick(column: keyof Appointment) {
		if (sortColumn === column) {
			sortDirection = sortDirection === 'asc' ? 'desc' : 'asc';
		} else {
			sortColumn = column;
			sortDirection = 'asc';
		}
		sortAppointments();
	}

	$: sortColumn, sortAppointments;
	$: sortDirection, sortAppointments;
</script>

<svelte:head>
	<title>Orders | BRSS Admin Software</title>
	<meta
		name="description"
		content="View, filter through, and overall just manage all BRSS appointments and orders here."
	/>
</svelte:head>

<!-- NOTE: potentially add in some button on the top right that is 'fedex-prepare all unprepared paid orders' -->
<div class="w-full">
	<Input
		type="text"
		bind:value={searchFilter}
		placeholder="Search for anything..."
		class="w-full md:mt-20"
	/>
	<hr class="mb-2 mt-4 border-2" />

	<Table.Root class="w-full">
		<Table.Header>
			<Table.Row>
				<Table.Head class="w-24">
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('orderNumber')}>
						ID
						{#if sortColumn === 'orderNumber'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head>
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('customer')}>
						Customer
						{#if sortColumn === 'customer'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head class="w-24">
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('deliveryDate')}>
						Date
						{#if sortColumn === 'deliveryDate'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head class="w-24">
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('deliveryTime')}>
						Time
						{#if sortColumn === 'deliveryTime'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head>
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('phone')}>
						Phone #
						{#if sortColumn === 'phone'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head>
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('type')}>
						Type
						{#if sortColumn === 'type'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head>
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('location')}>
						Location
						{#if sortColumn === 'location'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head>
					<button
						class="cursor-pointer select-none"
						on:click={() => onHeaderClick('estimatedItems')}
					>
						Items
						{#if sortColumn === 'estimatedItems'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head>
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('room')}>
						Room
						{#if sortColumn === 'room'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head class="w-28">
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('notes')}>
						Notes
						{#if sortColumn === 'notes'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
				<Table.Head>
					<button class="cursor-pointer select-none" on:click={() => onHeaderClick('items')}>
						Delivery
						{#if sortColumn === 'items'}
							{sortDirection === 'asc' ? '▲' : '▼'}
						{/if}
					</button>
				</Table.Head>
			</Table.Row>
		</Table.Header>
		<Table.Body>
			{#each filteredAppointments as appointment, i (i)}
				<Table.Row>
					<Table.Cell class="font-medium">{appointment.orderNumber}</Table.Cell>
					<Table.Cell>{appointment.customer}</Table.Cell>
					<Table.Cell>{appointment.deliveryDate}</Table.Cell>
					<Table.Cell>{appointment.deliveryTime}</Table.Cell>
					<Table.Cell>{appointment.phone}</Table.Cell>
					<Table.Cell>{appointment.type}</Table.Cell>
					<Table.Cell>{appointment.location}</Table.Cell>
					<Table.Cell>{appointment.estimatedItems ?? ''}</Table.Cell>
					<Table.Cell>{appointment.room ?? ''}</Table.Cell>
					<Table.Cell>{appointment.notes ?? ''}</Table.Cell>
					<Table.Cell>{appointment.items ?? ''}</Table.Cell>
				</Table.Row>
			{/each}
		</Table.Body>
	</Table.Root>
</div>

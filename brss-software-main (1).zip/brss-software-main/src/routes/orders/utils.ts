import type { Appointment } from '../../types/appointment';

/**
 * The response from Salesforce for the appointments query
 */
export type RawAppointmentResponse = {
	attributes: object;
	CustomerName__c: string;
	Date__c: string;
	Time__c: string;
	Status__c: string;
	PhoneNumber__c: string;
	Type__c: 'Pickup' | 'Supplies' | 'Delivery';
	Order__c: string;
	OrderNumber: string;
	EstimatedNumberOfItems__c: string;
	EstimatedBoxedItems__c?: string;
	EstimatedNonBoxedItems__c?: string;
	Building__c?: string;
	Address1__c?: string;
	Address2__c?: string;
	Notes__c?: string;
	RoomNumber__c?: string;
	// The below two are technically not part of the raw response, but are added in later
	TotalAmount?: number;
	PaymentDate?: string;
};

/**
 * The product of a couple joins in Salesforce for adding in supplies information to appointments.
 */
export type RawOrderItemResponse = {
	attributes: object;
	Name?: string;
	Product2Id: string;
	Quantity: number;
	OrderId: string;
};

/**
 * Formats the location of an appointment into a single string.
 * @param building the building name
 * @param address1 the first line of the address
 * @param address2 the second line of the address
 * @returns the formatted location
 */
export function formatLocation(building?: string, address1?: string, address2?: string) {
	if (building && address1 && address2) {
		return `${building}, ${address1}, ${address2}`;
	} else if (building && address1) {
		return `${building}, ${address1}`;
	} else if (building) {
		return building;
	} else if (address1 && address2) {
		return `${address1}, ${address2}`;
	} else if (address1) {
		return address1;
	} else if (address2) {
		return address2;
	} else {
		return '';
	}
}

function formatItem(item: RawOrderItemResponse) {
	// want to comma separate the name and quantity
	return item.Quantity + 'x ' + item.Name?.replace(' (Supplies)', '');
}

/**
 * Maps appointment records to appointment records with a formatted location field.
 * @param records the raw appointment records
 * @returns the formatted appointment records using the shared global `Appointment` type
 */
export function massageRecords(
	records: RawAppointmentResponse[],
	items: RawOrderItemResponse[]
): Appointment[] {
	return records
		.filter((record) => record.Status__c !== 'Cancelled') // this would cause bugs and is useless anyhow
		.map((record) => ({
			customer: record.CustomerName__c,
			deliveryDate: record.Date__c,
			deliveryTime: record.Time__c,
			phone: record.PhoneNumber__c,
			type: record.Type__c,
			orderNumber: record.OrderNumber,
			estimatedItems:
				record.EstimatedNumberOfItems__c ??
				(record.EstimatedBoxedItems__c ?? '0') +
					' boxed, ' +
					(record.EstimatedNonBoxedItems__c ?? '0') +
					' non-boxed',
			room: record.RoomNumber__c,
			location: formatLocation(record.Building__c, record.Address1__c, record.Address2__c),
			notes: record.Notes__c,
			items:
				record.Type__c === 'Supplies'
					? items
							.filter((item) => item.OrderId === record.Order__c)
							.filter((item) => item.Name !== '* Supplies Delivery')
							.map(formatItem)
							.join(', ')
					: 'N/A',
			totalAmount: record.TotalAmount,
			paymentTimestamp: record.PaymentDate
		}))
		.filter((record) => record.orderNumber !== undefined); // don't know why this would even happen!
}

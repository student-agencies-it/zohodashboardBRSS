import credentialedFetch from '$lib/req';
import { massageRecords, type RawAppointmentResponse, type RawOrderItemResponse } from './utils';

/**
 * Fetches the appointments from Salesforce and returns them to the client-side under `appointments`.
 * @returns the appointments from Salesforce
 */
export async function load() {
	const res = (await credentialedFetch(
		'https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+CustomerName__c,+Date__c,+Time__c,+Status__c,+PhoneNumber__c,+Type__c,+Order__c,+Building__c,+Address1__c,+Address2__c,+EstimatedNumberOfItems__c,+EstimatedBoxedItems__c,+EstimatedNonBoxedItems__c,+Notes__c,+RoomNumber__c+FROM+Appointment__c+WHERE+Date__c+>=+LAST_N_DAYS:0'
	)) as { records: RawAppointmentResponse[]; };

	// Spam orders.
	res.records = res.records.filter((record) => record.Order__c !== null);

	const mappingRes = (await credentialedFetch(
		'https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Id,+Status,+OrderNumber+FROM+Order+WHERE+Id+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+>=+LAST_N_DAYS:0)'
	)) as { records: { Id: string; Status: string; OrderNumber: string; }[]; };

	const mapping = mappingRes.records.reduce(
		(acc, { Id, Status, OrderNumber }) => {
			acc[Id] = { Status, OrderNumber };
			return acc;
		},
		{} as Record<
			string,
			{
				Status: string;
				OrderNumber: string;
			}
		>
	);

	// Move orderItemsRes fetch and processing here
	const orderItemsRes = (await credentialedFetch(
		'https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Product2Id,+Quantity,+OrderId+FROM+OrderItem+WHERE+OrderId+IN+(SELECT+Order__c+FROM+Appointment__c+WHERE+Date__c+>=+LAST_N_DAYS:0)'
	)) as { records: { Product2Id: string; Quantity: number; OrderId: string; }[]; };

	// We need to chunk this because otherwise the request can get too large.
	function chunkArray<T>(array: T[], chunkSize: number): T[][] {
		const chunks = [];
		for (let i = 0; i < array.length; i += chunkSize) {
			chunks.push(array.slice(i, i + chunkSize));
		}
		return chunks;
	}

	const chunks = chunkArray(orderItemsRes.records, 250);

	const productRes = await Promise.all(
		chunks.map(async (chunk) => {
			return (await credentialedFetch(
				`https://d61000000jlzveao.my.salesforce.com/services/data/v60.0/query?q=SELECT+Id,+Name+FROM+Product2+WHERE+Id+IN+(${chunk.map((record) => `'${record.Product2Id}'`).join(',')})`
			)) as { records: { Id: string; Name: string; }[]; };
		})
	).then((res) => {
		return {
			records: res.flatMap((r) => r.records)
		};
	});

	// Create orderItems before using it
	const orderItems = orderItemsRes.records.map((record) => ({
		...record,
		Name: productRes.records.find((product) => product.Id === record.Product2Id)?.Name
	})) as RawOrderItemResponse[];

	// Now update res — map order ID to OrderNumber and update estimated items
	res.records.forEach((record) => {
		record.OrderNumber = mapping[record.Order__c]?.OrderNumber;
		record.Status__c =
			mapping[record.Order__c]?.Status === 'Cancelled' ? 'Cancelled' : record.Status__c;

		// Get order items for this appointment
		const orderItemsForAppointment = orderItems.filter(item => item.OrderId === record.Order__c);

		// Count 'Big Red Box' and other items
		const bigRedBoxCount = orderItemsForAppointment.reduce((sum, item) =>
			item.Name === 'Big Red Box' ? sum + item.Quantity : sum, 0);
		const otherItemsCount = orderItemsForAppointment.reduce((sum, item) =>
			!['Big Red Box', 'Fee', 'Door to Door', 'Service', 'Supplies'].some(excludedItem => new RegExp(excludedItem, 'i').test(item.Name ?? '')) ? sum + item.Quantity : sum, 0);

		// Update EstimatedBoxedItems__c if it's zero or null
		if (!record.EstimatedBoxedItems__c || record.EstimatedBoxedItems__c === '0') {
			record.EstimatedBoxedItems__c = bigRedBoxCount.toString();
		}

		// Update EstimatedNonBoxedItems__c if it's zero or null
		if (!record.EstimatedNonBoxedItems__c || record.EstimatedNonBoxedItems__c === '0') {
			record.EstimatedNonBoxedItems__c = otherItemsCount.toString();
		}
	});

	return {
		appointments: massageRecords(res.records, orderItems).sort((a, b) => {
			if (a.deliveryDate === b.deliveryDate) {
				return a.deliveryTime.localeCompare(b.deliveryTime);
			} else {
				return a.deliveryDate.localeCompare(b.deliveryDate);
			}
		})
	};
}

// for reference on how salesforce auth works: https://help.salesforce.com/s/articleView?id=sf.remoteaccess_oauth_jwt_flow.htm&type=5

/**
 * An Appointment is a massaged Salesforce record with a formatted location field.
 */
export type Appointment = {
	customer: string;
	deliveryDate: string;
	deliveryTime: string;
	phone: string;
	type: 'Pickup' | 'Supplies' | 'Delivery';
	orderNumber: string;
	estimatedItems: string;
	room?: string;
	location?: string;
	notes?: string;
	items?: string; // extracted & joined together with comma separations
	totalAmount?: number;
	paymentTimestamp?: string;
};

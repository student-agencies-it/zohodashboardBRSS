/**
 * Stores extra information about a BRSS order in Firebase.
 */
export type FirebaseOrder = {
	orderNumber: string; // order id number-string, e.g. '00014533'
	truckAssignment?: string; // the automatic assignment
	orderInTruckAssignment?: number; // effectively so that trucks know what things are together
	// forcibleTimeAssignment?: string;
	forcibleTruckAssignment?: string;
};

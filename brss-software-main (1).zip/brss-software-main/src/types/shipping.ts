export type ShipToHomeAppointmentDetails = {
	date: string;
	orderNumber: string;
	customer: {
		name: string;
		phone: string; // gonna be needed later, ship2home
		address: string;
		city: string;
		state: string;
		zip: string;
	};
	articles: {
		id: string;
		name: string;
		billedWeight: number;
		weight: number | null; // inputted manually
	}[];
	totalDeclaredValue: number | null; // inputted manually
};

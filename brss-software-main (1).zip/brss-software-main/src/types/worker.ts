export type Worker = {
	name: string;
	scheduled: boolean;
	assigned?: boolean;
	assignedTo: string | null; // only relevant if `assigned` is true
	role: string;
	assignedAsDriver: boolean; // only possible if `role` is "BRSS Driver"
};

/**
 * Possible time slots for a truck to arrive / perform a pickup.
 */
export type PossibleTime =
	| '9 AM - 11 AM'
	| '11 AM - 1 PM'
	| '1 PM - 3 PM'
	| '3 PM - 5 PM'
	| '5 PM - 7 PM';
